-- ============================================
-- RESPALDO BASE DE DATOS: sistema_csi
-- Fecha: 2026-04-23 11:07:34
-- Tipo: completo
-- ============================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- --------------------------------------------------
-- Estructura de la tabla: Adjuntos
-- --------------------------------------------------
DROP TABLE IF EXISTS `Adjuntos`;
CREATE TABLE `Adjuntos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `nombre_archivo` varchar(255) NOT NULL,
  `ruta_archivo` varchar(500) NOT NULL,
  `tipo_archivo` varchar(100) DEFAULT NULL,
  `tamanio` int(11) DEFAULT NULL,
  `fecha_subida` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  CONSTRAINT `Adjuntos_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `Tickets` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------
-- Estructura de la tabla: AreasSoporte
-- --------------------------------------------------
DROP TABLE IF EXISTS `AreasSoporte`;
CREATE TABLE `AreasSoporte` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `activa` tinyint(1) DEFAULT 1,
  `todosven` tinyint(1) DEFAULT 1 COMMENT '0 = solo admin, 1 = todos ven',
  `orden` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Datos de la tabla: AreasSoporte
INSERT INTO `AreasSoporte` VALUES ('1', 'Apoyo Logístico DAR', 'Servicios de apoyo logístico para eventos y videoconferencias', '1', '1', '1');
INSERT INTO `AreasSoporte` VALUES ('2', 'Soporte a Servidores', 'Mantenimiento, configuración y respaldo de servidores', '1', '0', '2');
INSERT INTO `AreasSoporte` VALUES ('3', 'Gestión DAR', 'Gestión administrativa y elaboración de informes', '1', '0', '3');
INSERT INTO `AreasSoporte` VALUES ('4', 'Telefonía', 'Instalación, configuración y mantenimiento de sistemas telefónicos', '1', '1', '4');
INSERT INTO `AreasSoporte` VALUES ('5', 'RED', 'Configuración y mantenimiento de redes y equipos de red', '1', '1', '5');
INSERT INTO `AreasSoporte` VALUES ('6', 'Sistemas y Aplicaciones', 'Instalación y soporte de sistemas y aplicaciones informáticas', '1', '1', '6');
INSERT INTO `AreasSoporte` VALUES ('7', 'Soporte al usuario', 'Atención directa a usuarios, hardware y software', '1', '1', '7');
INSERT INTO `AreasSoporte` VALUES ('8', 'Soporte Taller', 'Reparación y mantenimiento de equipos e impresoras', '1', '1', '8');
INSERT INTO `AreasSoporte` VALUES ('9', 'Seguridad', 'Seguridad', '1', '1', '9');

-- --------------------------------------------------
-- Estructura de la tabla: BackupConfig
-- --------------------------------------------------
DROP TABLE IF EXISTS `BackupConfig`;
CREATE TABLE `BackupConfig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_backup` enum('completo','estructura') DEFAULT 'completo',
  `frecuencia` enum('diaria','semanal','mensual') DEFAULT 'diaria',
  `hora_ejecucion` time DEFAULT '02:00:00',
  `dia_semana` varchar(10) DEFAULT 'lunes',
  `retencion_dias` int(11) DEFAULT 30,
  `ultima_ejecucion` datetime DEFAULT NULL,
  `proxima_ejecucion` datetime DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `ruta_personalizada` varchar(500) DEFAULT NULL,
  `incluir_adjuntos` tinyint(1) DEFAULT 0,
  `email_notificacion` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------
-- Estructura de la tabla: Dependencias
-- --------------------------------------------------
DROP TABLE IF EXISTS `Dependencias`;
CREATE TABLE `Dependencias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `nombre_corto` varchar(35) DEFAULT NULL,
  `responsable` varchar(100) DEFAULT NULL,
  `email_responsable` varchar(100) DEFAULT NULL,
  `activa` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=209 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Datos de la tabla: Dependencias
INSERT INTO `Dependencias` VALUES ('1', 'AGRARIO MERIDA', 'AGRARIO MERIDA', 'STERLICCHI MATHEUS, JEANETTE DEL ROSARIO ', NULL, '1');
INSERT INTO `Dependencias` VALUES ('24', 'DIRECCION ADMINISTRATIVA REGIONAL DEL ESTADO MERIDA', 'DAR MERIDA', 'RINCON RIVAS, FREDDY ALEJANDRO', NULL, '1');
INSERT INTO `Dependencias` VALUES ('37', 'JUZGADO PRIMERO DE PRIMERA INSTANCIA CIVIL, MERCANTIL Y DEL TRANSITO DE LA CIRCUNSCRIPCION JUICIAL DEL ESTADO MERIDA', 'PRIMERO-DE-PRIMERA-INSTANCIA-MERIDA', 'HERNANDEZ , ROLANDO', NULL, '1');
INSERT INTO `Dependencias` VALUES ('162', 'CIRCUITO JUDICIAL PENAL DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'CJP MERIDA', 'RONDON , WENDY LOVELY', NULL, '1');
INSERT INTO `Dependencias` VALUES ('163', 'CIRCUITO JUDICIAL SECCION DE RESPONSABILIDAD PENAL ADOLESCENTES MERIDA', 'PENAL ADOLESCENTE MERIDA', 'ARANDA MÉNDEZ, HUMBERTO JOSE', 'Prueba@gmail.com', '1');
INSERT INTO `Dependencias` VALUES ('164', 'CIRCUITO JUDICIAL CON COMPETENCIA EN DELITOS DE VIOLENCIA CONTRA LA MUJER SEDE MERIDA', 'CVG MERIDA', 'TORRES ROSARIO, YEGNIN', NULL, '1');
INSERT INTO `Dependencias` VALUES ('165', 'CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA, EXTENSION EL VIGIA.', 'CJP EL VIGIA.', 'MARTINEZ PARRA, MAILES ROSANGELA', NULL, '1');
INSERT INTO `Dependencias` VALUES ('166', 'OFICINA DE DESARROLLO INFORMATICO DE LA DEM', 'ODI', 'JOSE ESCOBAR', NULL, '1');
INSERT INTO `Dependencias` VALUES ('167', 'OFICINA DE PARTICIPACION CIUDADANA DAR MERIDA.', 'OARPC MERIDA', 'SUAREZ DE HULL , DARSY COROMOTO', NULL, '1');
INSERT INTO `Dependencias` VALUES ('168', 'SEGURIDAD REGIONAL DE LA D.A.R. DEL ESTADO MERIDA', 'SEGURIDAD MERIDA', 'VELASQUEZ PATIÑO, ASDRUBAL JOSE', NULL, '1');
INSERT INTO `Dependencias` VALUES ('169', 'RECTORIA MERIDA', 'RECTORIA MERIDA', 'MORY DUQUE, LUIS FERNANDO JESUS', NULL, '1');
INSERT INTO `Dependencias` VALUES ('170', 'JUZGADO SUPERIOR PRIMERO CIVIL, MERCANTIL Y TRANSITO DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'SUPERIOR-PRIMERO-MERIDA', 'DÁVILA OCHOA, YOSANNY CRISTINA', NULL, '1');
INSERT INTO `Dependencias` VALUES ('171', 'JUZGADO SUPERIOR SEGUNDO CIVIL, MERCANTIL Y DEL TRANSITO DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'SUPERIOR-SEGUNDO-MERIDA', 'MORY DUQUE, LUIS FERNANDO JESUS', NULL, '1');
INSERT INTO `Dependencias` VALUES ('172', 'JUZGADO SEGUNDO DE PRIMERA INSTANCIA CIVIL, MERCANTIL Y DEL TRANSITO DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'SEGUNDO-DE-PRIMERA-INSTANCIA-MERIDA', 'MONSALVE RIVAS, MIGUEL ANGEL', NULL, '1');
INSERT INTO `Dependencias` VALUES ('173', 'JUZGADO TERCERO DE PRIMERA INSTANCIA CIVIL, MERCANTIL Y DEL TRANSITO DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'TERCERO-DE-PRIMERA-INSTANCIA-MERIDA', 'CALDERÓN, CARLOS ARTURO', NULL, '1');
INSERT INTO `Dependencias` VALUES ('174', 'JUZGADO CUARTO DE PRIMERA INSTANCIA CIVIL, MERCANTIL Y TRANSITO DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'CUARTO-DE-1RA-INSTANCIA-TOVAR', 'CONTRERAS GUERRERO, SANDRA LILIANA', NULL, '1');
INSERT INTO `Dependencias` VALUES ('175', 'JUZGADO SUPERIOR ESTADAL CONTENCIOSO ADMINISTRATIVO DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA, SEDE MERIDA', 'CONTENCIOSO', 'MORENO CAMACHO, SILVIA ELISA', NULL, '1');
INSERT INTO `Dependencias` VALUES ('176', 'JUZGADO DE PRIMERA INSTANCIA EN LO CIVIL, MERCANTIL Y TRANSITO DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA, EXTENSION EL VIGIA', 'PRIMERA-INSTANCIA-EL-VIGIA', 'RUIZ TORRES, LII ELENA', NULL, '1');
INSERT INTO `Dependencias` VALUES ('177', 'CIRCUITO JUDICIAL LABORAL SEDE MERIDA', 'LABORAL MERIDA', 'MONTOYA GUERRERO, DOUGLAS ARNOLDO', NULL, '1');
INSERT INTO `Dependencias` VALUES ('178', 'CIRCUITO JUDICIAL LABORAL SEDE EL VIGIA', 'LABORAL EL VIGIA', 'MONSALVE QUINTERO, FREDDY REINALDO', NULL, '1');
INSERT INTO `Dependencias` VALUES ('179', 'TRIBUNAL SEGUNDO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS CAMPO ELIAS Y ARICAGUA DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'TRIBUNAL-2DO-DE-MUNICIPIO-EJIDO', 'VAZQUEZ AÑEZ, ALBA DEL CARMEN', NULL, '1');
INSERT INTO `Dependencias` VALUES ('180', 'TRIBUNAL PRIMERO DE MUNCIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DEL MUNICIPIO ANTONIO PINTO SALINAS DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA, CON SEDE EN LA CIUDAD DE SANTA CRUZ', 'TRIBUNAL-1RO-MUNICIPIO-SANTA-CRUZ', 'UZCATEGUI UZCATEGUI, JOSLEDY ALICIA', NULL, '1');
INSERT INTO `Dependencias` VALUES ('181', 'TRIBUNAL SEGUNDO DE MUNCIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DEL MUNICIPIO SUCRE DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA, CON SEDE EN LA CIUDAD DE LAGUNILLAS', 'TRIBUNAL-2DO-MUNICIPIO-LAGUNILLAS', 'DUGARTE CONTRERAS, JHONNY CARMELO', NULL, '1');
INSERT INTO `Dependencias` VALUES ('182', 'TRIBUNAL PRIMERO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS ALBERTO ADRIANI, ANDRES BELLO, OBISPO RAMOS DE LORA Y CARACCIOLO PARRA OLMEDO DE LA C.J. DEL EDO MERIDA', 'TRIBUNAL-1RO-MUNICIPIO-EL-VIGIA', 'ESTREMOR OSMA, MARIA EUGENIA', NULL, '1');
INSERT INTO `Dependencias` VALUES ('183', 'TRIBUNAL PRIMERO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS LIBERTADOR Y SANTOS MARQUINA DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'TRIBUNAL-1RO-MUNICIPIO-LIBERTADOR', 'MORY DUQUE, LUIS FERNANDO JESUS', NULL, '1');
INSERT INTO `Dependencias` VALUES ('184', 'TRIBUNAL PRIMERO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS JUSTO BRICEÑO, TULIO FEBRES CORDERO Y JULIO CESAR SALAS DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'TRIBUNAL-1RO-MUNICIPIO-NUEV-BOLIVIA', 'MORENO CUBARRUBIA, MIRELIS COROMOTO', NULL, '1');
INSERT INTO `Dependencias` VALUES ('185', 'TRIBUNAL PRIMERO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS MIRANDA Y PUEBLO LLANO DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'TRIBUNAL-1RO-MUNICIPIO-TIMOTES', 'VILLARREAL LAGUNA, DEFIGENIO', NULL, '1');
INSERT INTO `Dependencias` VALUES ('186', 'TRIBUNAL PRIMERO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS RANGEL Y CARDENAL QUINTERO DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'TRIBUNAL-1RO-MUNICIPIO-MUCUCHIES', 'VILLARREAL LAGUNA, DEFIGENIO', NULL, '1');
INSERT INTO `Dependencias` VALUES ('187', 'TRIBUNAL PRIMERO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS TOVAR, ZEA, GUARAQUE Y ARZOBISPO CHACON DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'TRIBUNAL-1RO-MUNICIPIO-TOVAR', 'BARRIOS HERNANDEZ, KARINA YUSVELY', NULL, '1');
INSERT INTO `Dependencias` VALUES ('188', 'CIRCUITO JUDICIAL SECCION DE RESPONSABILIDAD PENAL ADOLESCENTES SEDE EXT. EL VIGIA', 'PENAL-ADOLESCENTE-EL-VIGIA', 'MARTINEZ PARRA, MAILES ROSANGELA', NULL, '1');
INSERT INTO `Dependencias` VALUES ('189', 'TRIBUNAL PRIMERO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS CAMPO ELIAS Y ARICAGUA DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'TRIBUNAL-1RO-DE-MUNICIPIO-EJIDO', 'OVIEDO SOTO, YORGI ALFONSO', NULL, '1');
INSERT INTO `Dependencias` VALUES ('192', 'TRIBUNAL SEGUNDO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS ALBERTO ADRIANI, ANDRES BELLO, OBISPO RAMOS DE LORA Y CARACCIOLO PARRA OLMEDO DE LA C.J. DEL EDO MERIDA', 'TRIBUNAL-2DO-MUNICIPIO-EL-VIGIA', '', NULL, '1');
INSERT INTO `Dependencias` VALUES ('193', 'TRIBUNAL TERCERO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS CAMPO ELIAS Y ARICAGUA DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'TRIBUNAL-3RO-MUNICIPIO-EL-VIGIA', '', NULL, '1');
INSERT INTO `Dependencias` VALUES ('194', 'TRIBUNAL CUARTO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS CAMPO ELIAS Y ARICAGUA DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'TRIBUNAL-4TO-MUNICIPIO-EL-VIGIA', '', NULL, '1');
INSERT INTO `Dependencias` VALUES ('195', 'TRIBUNAL QUINTO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS CAMPO ELIAS Y ARICAGUA DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'TRIBUNAL-5TO-MUNICIPIO-EL-VIGIA', '', NULL, '1');
INSERT INTO `Dependencias` VALUES ('196', 'TRIBUNAL SEGUNDO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS TOVAR, ZEA, GUARAQUE Y ARZOBISPO CHACON DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'TRIBUNAL-2DO-MUNICIPIO-TOVAR', '', NULL, '1');
INSERT INTO `Dependencias` VALUES ('197', 'TRIBUNAL TERCERO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS TOVAR, ZEA, GUARAQUE Y ARZOBISPO CHACON DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'TRIBUNAL-3RO-MUNICIPIO-TOVAR', '', NULL, '1');
INSERT INTO `Dependencias` VALUES ('198', 'TRIBUNAL PRIMERO DE MUNCIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DEL MUNICIPIO SUCRE DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA, CON SEDE EN LA CIUDAD DE LAGUNILLAS', 'TRIBUNAL-1RO-MUNCIPIO-LAGUNILLAS', '', NULL, '1');
INSERT INTO `Dependencias` VALUES ('199', 'TRIBUNAL SEGUNDO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS MIRANDA Y PUEBLO LLANO DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'TRIBUNAL-2DO-MUNICIPIO-TIMOTES', '', NULL, '1');
INSERT INTO `Dependencias` VALUES ('200', 'TRIBUNAL SEGUNDO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS LIBERTADOR Y SANTOS MARQUINA DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'TRIBUNAL-2DO-MUNICIPIO-LIBERTADOR', '', NULL, '1');
INSERT INTO `Dependencias` VALUES ('201', 'TRIBUNAL TERCERO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS LIBERTADOR Y SANTOS MARQUINA DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'TRIBUNAL-3RO-MUNICIPIO-LIBERTADOR', '', NULL, '1');
INSERT INTO `Dependencias` VALUES ('202', 'TRIBUNAL CUARTO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS LIBERTADOR Y SANTOS MARQUINA DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'TRIBUNAL-4TO-MUNICIPIO-LIBERTADOR', '', NULL, '1');
INSERT INTO `Dependencias` VALUES ('203', 'TRIBUNAL QUINTO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS LIBERTADOR Y SANTOS MARQUINA DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'TRIBUNAL-5TO-MUNICIPIO-LIBERTADOR', '', NULL, '1');
INSERT INTO `Dependencias` VALUES ('204', 'TRIBUNAL SEGUNDO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS JUSTO BRICEÑO, TULIO FEBRES CORDERO Y JULIO CESAR SALAS DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'TRIBUNAL-2DO-MUNICIPIO-NUEV-BOLIVIA', '', NULL, '1');
INSERT INTO `Dependencias` VALUES ('205', 'CIRCUITO JUDICIAL DE PROTECCIÓN DE NIÑOS, NIÑAS Y ADOLESCENTES DE LA CIRCUITO JUDICIAL DEL ESTADO MÉRIDA', 'LOPNNA-MERIDA', 'MONTOYA GUERRERO, DOUGLAS ARNOLDO', NULL, '1');
INSERT INTO `Dependencias` VALUES ('206', 'AGRARIO EL VIGIA', 'AGRARIO-EL-VIGIA', 'AGRARIO EL VIGIA', NULL, '1');
INSERT INTO `Dependencias` VALUES ('207', 'RECTORIA CIVIL DE LA CIRCUNSCRIPCION JUDICIAL DEL ESTADO MERIDA', 'RECTORIA-CIVIL', 'MORY DUQUE, LUIS FERNANDO JESUS', NULL, '1');
INSERT INTO `Dependencias` VALUES ('208', 'Apoyo Institucional', 'APOYO-INSTITUCIONAL', 'Diferentes entes', NULL, '1');

-- --------------------------------------------------
-- Estructura de la tabla: HistorialTickets
-- --------------------------------------------------
DROP TABLE IF EXISTS `HistorialTickets`;
CREATE TABLE `HistorialTickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `accion` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `HistorialTickets_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `Tickets` (`id`),
  CONSTRAINT `HistorialTickets_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Datos de la tabla: HistorialTickets
INSERT INTO `HistorialTickets` VALUES ('30', '28', '53', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-02-11 11:33:55');
INSERT INTO `HistorialTickets` VALUES ('31', '30', '50', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-02-12 13:38:12');
INSERT INTO `HistorialTickets` VALUES ('32', '35', '53', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-02-26 10:39:17');
INSERT INTO `HistorialTickets` VALUES ('33', '31', '34', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-03-11 15:54:47');
INSERT INTO `HistorialTickets` VALUES ('35', '38', '38', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-03-12 12:14:18');
INSERT INTO `HistorialTickets` VALUES ('36', '41', '38', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-03-12 12:23:47');
INSERT INTO `HistorialTickets` VALUES ('37', '40', '53', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-03-12 13:14:59');
INSERT INTO `HistorialTickets` VALUES ('38', '40', '53', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-03-12 13:52:13');
INSERT INTO `HistorialTickets` VALUES ('39', '39', '53', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-03-13 10:10:54');
INSERT INTO `HistorialTickets` VALUES ('40', '36', '53', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-03-16 09:48:57');
INSERT INTO `HistorialTickets` VALUES ('41', '49', '38', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-03-16 11:06:10');
INSERT INTO `HistorialTickets` VALUES ('45', '31', '7', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-03-24 11:36:34');
INSERT INTO `HistorialTickets` VALUES ('47', '55', '53', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-03-25 11:08:11');
INSERT INTO `HistorialTickets` VALUES ('48', '55', '53', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-03-25 11:44:26');
INSERT INTO `HistorialTickets` VALUES ('49', '56', '53', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-03-25 11:56:27');
INSERT INTO `HistorialTickets` VALUES ('50', '57', '53', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-03-25 15:07:29');
INSERT INTO `HistorialTickets` VALUES ('51', '57', '53', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente. Se adjuntaron 1 archivo(s).', '2026-03-25 15:09:10');
INSERT INTO `HistorialTickets` VALUES ('52', '59', '38', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-03-26 15:47:04');
INSERT INTO `HistorialTickets` VALUES ('53', '32', '50', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-03-26 15:47:54');
INSERT INTO `HistorialTickets` VALUES ('54', '58', '50', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-03-26 15:55:14');
INSERT INTO `HistorialTickets` VALUES ('55', '60', '47', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-03-26 16:07:55');
INSERT INTO `HistorialTickets` VALUES ('56', '61', '38', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-03-26 16:18:11');
INSERT INTO `HistorialTickets` VALUES ('57', '67', '37', 'cierre', 'Ticket cerrado como: Cerrado No Exitoso', '2026-03-27 11:16:46');
INSERT INTO `HistorialTickets` VALUES ('58', '68', '50', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-03-27 12:48:17');
INSERT INTO `HistorialTickets` VALUES ('59', '58', '50', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-03-27 12:48:58');
INSERT INTO `HistorialTickets` VALUES ('60', '45', '7', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-03-27 15:16:33');
INSERT INTO `HistorialTickets` VALUES ('61', '71', '37', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-03-27 15:46:32');
INSERT INTO `HistorialTickets` VALUES ('62', '59', '38', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-03-27 16:21:06');
INSERT INTO `HistorialTickets` VALUES ('63', '79', '37', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-04-06 09:41:21');
INSERT INTO `HistorialTickets` VALUES ('64', '79', '37', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-06 10:07:33');
INSERT INTO `HistorialTickets` VALUES ('65', '81', '50', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-04-06 10:11:33');
INSERT INTO `HistorialTickets` VALUES ('66', '82', '53', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-04-06 12:02:37');
INSERT INTO `HistorialTickets` VALUES ('67', '82', '53', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-06 12:04:11');
INSERT INTO `HistorialTickets` VALUES ('68', '83', '53', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-04-06 12:06:25');
INSERT INTO `HistorialTickets` VALUES ('69', '83', '53', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-06 12:15:28');
INSERT INTO `HistorialTickets` VALUES ('71', '85', '53', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-04-06 12:36:43');
INSERT INTO `HistorialTickets` VALUES ('72', '85', '53', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-06 12:37:58');
INSERT INTO `HistorialTickets` VALUES ('73', '86', '53', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-04-06 12:39:33');
INSERT INTO `HistorialTickets` VALUES ('74', '86', '53', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-06 12:40:23');
INSERT INTO `HistorialTickets` VALUES ('75', '87', '53', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-04-06 12:42:41');
INSERT INTO `HistorialTickets` VALUES ('76', '87', '53', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-06 12:44:04');
INSERT INTO `HistorialTickets` VALUES ('77', '89', '53', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-04-06 14:33:16');
INSERT INTO `HistorialTickets` VALUES ('78', '80', '37', 'cierre', 'Ticket cerrado como: Cerrado No Exitoso', '2026-04-06 15:22:22');
INSERT INTO `HistorialTickets` VALUES ('79', '42', '45', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-07 08:54:00');
INSERT INTO `HistorialTickets` VALUES ('80', '93', '38', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-04-07 08:54:24');
INSERT INTO `HistorialTickets` VALUES ('81', '101', '53', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-04-07 13:49:27');
INSERT INTO `HistorialTickets` VALUES ('82', '102', '53', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-04-07 13:53:22');
INSERT INTO `HistorialTickets` VALUES ('83', '104', '53', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-04-07 14:11:13');
INSERT INTO `HistorialTickets` VALUES ('84', '105', '38', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-07 15:36:18');
INSERT INTO `HistorialTickets` VALUES ('85', '92', '38', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-07 15:38:47');
INSERT INTO `HistorialTickets` VALUES ('86', '88', '50', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-07 15:58:26');
INSERT INTO `HistorialTickets` VALUES ('87', '103', '7', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-07 16:05:04');
INSERT INTO `HistorialTickets` VALUES ('88', '108', '50', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-04-07 16:17:36');
INSERT INTO `HistorialTickets` VALUES ('89', '106', '38', 'cierre', 'Ticket cerrado como: Cerrado No Exitoso. Se adjuntaron 1 archivo(s).', '2026-04-07 16:19:58');
INSERT INTO `HistorialTickets` VALUES ('90', '78', '80', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-08 09:26:37');
INSERT INTO `HistorialTickets` VALUES ('91', '109', '80', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-08 09:28:40');
INSERT INTO `HistorialTickets` VALUES ('92', '48', '35', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-08 10:44:16');
INSERT INTO `HistorialTickets` VALUES ('93', '110', '51', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-08 11:23:16');
INSERT INTO `HistorialTickets` VALUES ('94', '111', '35', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-08 11:42:17');
INSERT INTO `HistorialTickets` VALUES ('95', '112', '37', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-08 11:44:38');
INSERT INTO `HistorialTickets` VALUES ('96', '124', '38', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-04-09 11:57:55');
INSERT INTO `HistorialTickets` VALUES ('97', '126', '50', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-09 16:12:47');
INSERT INTO `HistorialTickets` VALUES ('98', '127', '50', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-09 16:15:15');
INSERT INTO `HistorialTickets` VALUES ('99', '128', '50', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-09 16:19:35');
INSERT INTO `HistorialTickets` VALUES ('100', '130', '38', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-10 10:17:29');
INSERT INTO `HistorialTickets` VALUES ('101', '131', '38', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-10 10:21:22');
INSERT INTO `HistorialTickets` VALUES ('102', '132', '38', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-10 10:39:01');
INSERT INTO `HistorialTickets` VALUES ('103', '133', '38', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-10 10:48:12');
INSERT INTO `HistorialTickets` VALUES ('104', '134', '38', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-10 10:51:25');
INSERT INTO `HistorialTickets` VALUES ('105', '120', '53', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-10 10:52:10');
INSERT INTO `HistorialTickets` VALUES ('106', '101', '53', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-10 10:55:52');
INSERT INTO `HistorialTickets` VALUES ('107', '56', '53', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-10 10:58:40');
INSERT INTO `HistorialTickets` VALUES ('108', '136', '38', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-10 11:04:45');
INSERT INTO `HistorialTickets` VALUES ('109', '137', '35', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-04-10 11:06:05');
INSERT INTO `HistorialTickets` VALUES ('110', '140', '7', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-10 12:19:47');
INSERT INTO `HistorialTickets` VALUES ('111', '149', '37', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-13 10:06:32');
INSERT INTO `HistorialTickets` VALUES ('112', '150', '7', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-13 10:13:02');
INSERT INTO `HistorialTickets` VALUES ('113', '152', '37', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-13 11:02:40');
INSERT INTO `HistorialTickets` VALUES ('114', '147', '37', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-13 13:52:32');
INSERT INTO `HistorialTickets` VALUES ('115', '160', '7', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-13 14:29:59');
INSERT INTO `HistorialTickets` VALUES ('116', '159', '7', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-13 14:36:15');
INSERT INTO `HistorialTickets` VALUES ('117', '163', '7', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-13 15:55:30');
INSERT INTO `HistorialTickets` VALUES ('118', '164', '7', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-13 16:10:41');
INSERT INTO `HistorialTickets` VALUES ('119', '174', '7', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-14 11:36:34');
INSERT INTO `HistorialTickets` VALUES ('120', '173', '7', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-14 11:37:32');
INSERT INTO `HistorialTickets` VALUES ('121', '180', '45', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-14 14:37:37');
INSERT INTO `HistorialTickets` VALUES ('122', '193', '45', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-15 09:24:21');
INSERT INTO `HistorialTickets` VALUES ('123', '195', '38', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-04-15 09:36:16');
INSERT INTO `HistorialTickets` VALUES ('124', '191', '7', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-15 09:50:18');
INSERT INTO `HistorialTickets` VALUES ('125', '205', '45', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-15 14:44:00');
INSERT INTO `HistorialTickets` VALUES ('126', '207', '47', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-16 09:12:34');
INSERT INTO `HistorialTickets` VALUES ('127', '208', '47', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-16 09:14:43');
INSERT INTO `HistorialTickets` VALUES ('128', '209', '37', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-16 14:01:49');
INSERT INTO `HistorialTickets` VALUES ('129', '220', '45', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-17 10:12:17');
INSERT INTO `HistorialTickets` VALUES ('130', '221', '45', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-17 10:14:16');
INSERT INTO `HistorialTickets` VALUES ('131', '219', '37', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-17 11:14:46');
INSERT INTO `HistorialTickets` VALUES ('132', '211', '46', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-17 16:34:54');
INSERT INTO `HistorialTickets` VALUES ('133', '216', '46', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-17 16:37:21');
INSERT INTO `HistorialTickets` VALUES ('134', '230', '45', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-20 09:59:52');
INSERT INTO `HistorialTickets` VALUES ('135', '228', '37', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-04-20 11:17:35');
INSERT INTO `HistorialTickets` VALUES ('136', '229', '7', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-20 11:34:40');
INSERT INTO `HistorialTickets` VALUES ('137', '228', '37', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-20 14:05:47');
INSERT INTO `HistorialTickets` VALUES ('138', '236', '50', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-04-20 14:53:00');
INSERT INTO `HistorialTickets` VALUES ('139', '235', '53', 'cambio_estado', 'Estado cambiado de ''Asignado'' a ''En Proceso''', '2026-04-21 09:08:51');
INSERT INTO `HistorialTickets` VALUES ('140', '241', '45', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-21 09:11:59');
INSERT INTO `HistorialTickets` VALUES ('141', '235', '53', 'cierre', 'Ticket cerrado como: Cerrado Exitosamente', '2026-04-21 11:03:39');

-- --------------------------------------------------
-- Estructura de la tabla: Logs
-- --------------------------------------------------
DROP TABLE IF EXISTS `Logs`;
CREATE TABLE `Logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `accion` varchar(50) NOT NULL,
  `descripcion` text NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `detalles` text DEFAULT NULL,
  `ticket_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_usuario` (`usuario_id`),
  KEY `idx_fecha` (`fecha`)
) ENGINE=InnoDB AUTO_INCREMENT=417 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Datos de la tabla: Logs
INSERT INTO `Logs` VALUES ('1', '3', 'ACTUALIZAR_PERFIL', 'Perfil actualizado', '2026-01-20 12:17:45', NULL, NULL, NULL, NULL);
INSERT INTO `Logs` VALUES ('2', '7', 'ACTUALIZAR_PERFIL', 'Perfil actualizado', '2026-01-21 15:21:11', NULL, NULL, NULL, NULL);
INSERT INTO `Logs` VALUES ('3', '53', 'CERRAR_TICKET', 'Ticket #CSI2026032527982 cerrado como: Cerrado Exitosamente - Solución: Mantenimiento Físico Interno: Se realizó limpieza profunda mediante soplado interno para extraer e', '2026-03-25 11:44:26', '172.27.195.179', 'Mozilla/5.0 (X11; Linux i686; rv:98.0) Gecko/20100101 Firefox/98.0', NULL, '55');
INSERT INTO `Logs` VALUES ('4', '34', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Milana Maria Medina Ramirez - Privilegio: admin', '2026-03-25 12:13:14', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('5', '53', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Tomas Elias Valera Torrealba - Privilegio: tecnico', '2026-03-25 14:31:41', '172.27.195.179', 'Mozilla/5.0 (X11; Linux i686; rv:98.0) Gecko/20100101 Firefox/98.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('6', '53', 'CERRAR_TICKET', 'Ticket #CSI2026032532170 cerrado como: Cerrado Exitosamente - Solución: se ingresa a la red magistratura y se le coloca el acceso a las carpetas compartidas correspondiente', '2026-03-25 15:09:10', '172.27.195.179', 'Mozilla/5.0 (X11; Linux i686; rv:98.0) Gecko/20100101 Firefox/98.0', NULL, '57');
INSERT INTO `Logs` VALUES ('7', '55', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Freddy Alejandro Rincon Rivas - Privilegio: admin', '2026-03-25 15:59:06', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('8', '81', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Mayela Roa - Privilegio: usuario', '2026-03-25 16:01:00', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('9', '55', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Freddy Alejandro Rincon Rivas - Privilegio: admin', '2026-03-25 16:04:32', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('10', '55', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Freddy Alejandro Rincon Rivas - Privilegio: usuario', '2026-03-25 16:06:09', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('11', '53', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Tomas Elias Valera Torrealba - Privilegio: tecnico', '2026-03-25 16:18:38', '172.27.195.179', 'Mozilla/5.0 (X11; Linux i686; rv:98.0) Gecko/20100101 Firefox/98.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('12', '85', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Tecnico Prueba - Privilegio: tecnico', '2026-03-26 08:52:00', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('13', '34', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Milana Maria Medina Ramirez - Privilegio: admin', '2026-03-26 14:05:27', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('14', '84', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Usuario Prueba - Privilegio: usuario', '2026-03-26 15:32:55', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('15', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-03-26 15:44:41', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('16', '38', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Eladio Antonio Torres Peña - Privilegio: tecnico', '2026-03-26 15:45:13', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('17', '50', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Orangel Davila - Privilegio: tecnico', '2026-03-26 15:46:59', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('18', '86', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Ramon Muñoz - Privilegio: tecnico', '2026-03-26 15:55:49', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('19', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-03-26 16:02:38', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('20', '47', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Mauro Imar Diaz Dugarte - Privilegio: tecnico', '2026-03-26 16:04:14', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('21', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-03-26 16:11:27', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('22', '51', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Rafael Augusto Molina Ruiz - Privilegio: tecnico', '2026-03-26 16:12:40', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('23', '38', 'CERRAR_TICKET', 'Ticket #CSI2026032618128 cerrado como: Cerrado Exitosamente - Solución: Actualización realizada exitosamete', '2026-03-26 16:18:11', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '61');
INSERT INTO `Logs` VALUES ('24', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-03-27 09:47:17', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('25', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-03-27 09:48:39', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:77.0) Gecko/20100101 Firefox/77.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('26', '74', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Sandra Carrero - Privilegio: usuario', '2026-03-27 09:59:40', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('27', '85', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Tecnico Prueba - Privilegio: tecnico', '2026-03-27 10:10:18', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('28', '74', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Sandra Carrero - Privilegio: usuario', '2026-03-27 10:12:32', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('29', '84', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Usuario Prueba - Privilegio: usuario', '2026-03-27 10:21:34', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('30', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-03-27 10:34:09', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('31', '82', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Jorge Avila - Privilegio: usuario', '2026-03-27 10:35:21', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('32', '34', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Milana Maria Medina Ramirez - Privilegio: admin', '2026-03-27 10:47:53', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:77.0) Gecko/20100101 Firefox/77.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('33', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-03-27 10:58:12', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:77.0) Gecko/20100101 Firefox/77.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('34', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-03-27 11:09:08', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:77.0) Gecko/20100101 Firefox/77.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('35', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-03-27 11:12:18', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:77.0) Gecko/20100101 Firefox/77.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('36', '37', 'CERRAR_TICKET', 'Ticket #CSI2026032733168 cerrado como: Cerrado No Exitoso - Solución: se reviso el equipo el cual presenta sectores dañados en el disco duro, por tal motivo no se realiz', '2026-03-27 11:16:46', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:77.0) Gecko/20100101 Firefox/77.0', NULL, '67');
INSERT INTO `Logs` VALUES ('37', '93', 'LOGIN', 'Inicio de sesión exitoso - Usuario: RONDÓN RANGEL, IRIS MIGDALY - Privilegio: usuario', '2026-03-27 11:24:46', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:140.0) Gecko/20100101 Firefox/140.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('38', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-03-27 11:27:25', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:77.0) Gecko/20100101 Firefox/77.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('39', '93', 'LOGIN', 'Inicio de sesión exitoso - Usuario: RONDÓN RANGEL, IRIS MIGDALY - Privilegio: usuario', '2026-03-27 11:36:47', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:140.0) Gecko/20100101 Firefox/140.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('40', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-03-27 11:40:16', '172.27.160.160', 'Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('41', '93', 'LOGIN', 'Inicio de sesión exitoso - Usuario: RONDÓN RANGEL, IRIS MIGDALY - Privilegio: usuario', '2026-03-27 11:43:20', '172.27.195.34', 'Mozilla/5.0 (Windows NT 10.0; rv:140.0) Gecko/20100101 Firefox/140.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('42', '93', 'LOGIN', 'Inicio de sesión exitoso - Usuario: RONDÓN RANGEL, IRIS MIGDALY - Privilegio: usuario', '2026-03-27 11:44:58', '172.27.195.34', 'Mozilla/5.0 (Windows NT 10.0; rv:140.0) Gecko/20100101 Firefox/140.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('43', '93', 'LOGIN', 'Inicio de sesión exitoso - Usuario: RONDÓN RANGEL, IRIS MIGDALY - Privilegio: usuario', '2026-03-27 11:49:21', '172.27.195.34', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36 Edg/136.0.0.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('44', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-03-27 11:49:31', '172.27.160.160', 'Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('45', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-03-27 11:51:51', '172.27.160.160', 'Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('46', '93', 'LOGIN', 'Inicio de sesión exitoso - Usuario: RONDÓN RANGEL, IRIS MIGDALY - Privilegio: usuario', '2026-03-27 11:54:40', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:140.0) Gecko/20100101 Firefox/140.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('47', '93', 'LOGIN', 'Inicio de sesión exitoso - Usuario: RONDÓN RANGEL, IRIS MIGDALY - Privilegio: usuario', '2026-03-27 12:02:51', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:140.0) Gecko/20100101 Firefox/140.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('48', '34', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Milana Maria Medina Ramirez - Privilegio: admin', '2026-03-27 12:05:07', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:140.0) Gecko/20100101 Firefox/140.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('49', '93', 'LOGIN', 'Inicio de sesión exitoso - Usuario: RONDÓN RANGEL, IRIS MIGDALY - Privilegio: usuario', '2026-03-27 12:07:53', '172.27.195.34', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36 Edg/136.0.0.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('50', '92', 'LOGIN', 'Inicio de sesión exitoso - Usuario: CONTRERAS GUERRERO, MARLENI SULAY - Privilegio: usuario', '2026-03-27 12:21:42', '172.27.160.160', 'Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('51', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-03-27 12:29:29', '172.27.160.160', 'Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('52', '92', 'LOGIN', 'Inicio de sesión exitoso - Usuario: CONTRERAS GUERRERO, MARLENI SULAY - Privilegio: usuario', '2026-03-27 12:31:30', '172.27.160.160', 'Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('53', '91', 'LOGIN', 'Inicio de sesión exitoso - Usuario: GAVIDIA RIVAS, NEIDA - Privilegio: usuario', '2026-03-27 12:36:04', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('54', '34', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Milana Maria Medina Ramirez - Privilegio: admin', '2026-03-27 12:44:21', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('55', '50', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Orangel Davila - Privilegio: tecnico', '2026-03-27 12:45:17', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('56', '50', 'CERRAR_TICKET', 'Ticket #CSI2026032748837 cerrado como: Cerrado Exitosamente - Solución: EL USUARIO QUE ESTABA CONSULTANDO ESTABA BLOQUEADO', '2026-03-27 12:48:17', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, '68');
INSERT INTO `Logs` VALUES ('57', '50', 'CERRAR_TICKET', 'Ticket #CSI2026032668445 cerrado como: Cerrado Exitosamente - Solución: REINICIO DE CABLE', '2026-03-27 12:48:58', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, '58');
INSERT INTO `Logs` VALUES ('58', '91', 'LOGIN', 'Inicio de sesión exitoso - Usuario: GAVIDIA RIVAS, NEIDA - Privilegio: usuario', '2026-03-27 12:59:06', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('59', '34', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Milana Maria Medina Ramirez - Privilegio: admin', '2026-03-27 14:08:54', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('60', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-03-27 14:09:32', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:77.0) Gecko/20100101 Firefox/77.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('61', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-03-27 14:41:12', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:77.0) Gecko/20100101 Firefox/77.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('62', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-03-27 15:14:27', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('63', '7', 'CERRAR_TICKET', 'Ticket #CSI2026031231549 cerrado como: Cerrado Exitosamente - Solución: quedo  Operativo esta  en el comedor', '2026-03-27 15:16:33', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, '45');
INSERT INTO `Logs` VALUES ('64', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-03-27 15:26:27', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('65', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-03-27 15:45:04', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('66', '37', 'CERRAR_TICKET', 'Ticket #CSI2026032724801 cerrado como: Cerrado Exitosamente - Solución: trabajo éxito', '2026-03-27 15:46:32', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0', NULL, '71');
INSERT INTO `Logs` VALUES ('67', '34', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Milana Maria Medina Ramirez - Privilegio: admin', '2026-03-27 16:06:39', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('68', '35', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Cesar Herney Chourio Ruiz - Privilegio: tecnico', '2026-03-27 16:08:17', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('69', '38', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Eladio Antonio Torres Peña - Privilegio: tecnico', '2026-03-27 16:20:33', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('70', '38', 'CERRAR_TICKET', 'Ticket #CSI2026032681056 cerrado como: Cerrado Exitosamente - Solución: Proceso realizado exitosamente', '2026-03-27 16:21:06', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '59');
INSERT INTO `Logs` VALUES ('71', '38', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Eladio Antonio Torres Peña - Privilegio: tecnico', '2026-03-27 16:21:20', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('72', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-06 08:41:16', '172.27.160.160', 'Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('73', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-06 09:07:23', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('74', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-06 09:36:19', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:77.0) Gecko/20100101 Firefox/77.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('75', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-06 10:04:33', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('76', '91', 'LOGIN', 'Inicio de sesión exitoso - Usuario: GAVIDIA RIVAS, NEIDA - Privilegio: usuario', '2026-04-06 10:04:40', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('77', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-06 10:05:19', '172.27.195.96', 'Mozilla/5.0 (Windows NT 6.1; rv:77.0) Gecko/20100101 Firefox/77.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('78', '37', 'CERRAR_TICKET', 'Ticket #CSI2026040615710 cerrado como: Cerrado Exitosamente - Solución: se reviso la tarjeta madre , se instalo sistema operativo y sus herramientas de trabajo', '2026-04-06 10:07:33', '172.27.195.96', 'Mozilla/5.0 (Windows NT 6.1; rv:77.0) Gecko/20100101 Firefox/77.0', NULL, '79');
INSERT INTO `Logs` VALUES ('79', '50', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Orangel Davila - Privilegio: tecnico', '2026-04-06 10:08:34', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('80', '51', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Rafael Augusto Molina Ruiz - Privilegio: tecnico', '2026-04-06 10:08:36', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('81', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-06 10:14:55', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('82', '53', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Tomas Elias Valera Torrealba - Privilegio: tecnico', '2026-04-06 10:17:51', '172.27.195.179', 'Mozilla/5.0 (X11; Linux i686; rv:98.0) Gecko/20100101 Firefox/98.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('83', '93', 'LOGIN', 'Inicio de sesión exitoso - Usuario: RONDÓN RANGEL, IRIS MIGDALY - Privilegio: usuario', '2026-04-06 11:02:40', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:140.0) Gecko/20100101 Firefox/140.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('84', '53', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Tomas Elias Valera Torrealba - Privilegio: tecnico', '2026-04-06 11:57:46', '172.27.195.179', 'Mozilla/5.0 (X11; Linux i686; rv:98.0) Gecko/20100101 Firefox/98.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('85', '53', 'CERRAR_TICKET', 'Ticket #CSI2026040659506 cerrado como: Cerrado Exitosamente - Solución: SE INSTALA ACCESO A LA IMPRESORA QUE ESTA EN EL DESPACHO DEL JUEZ', '2026-04-06 12:04:11', '172.27.195.179', 'Mozilla/5.0 (X11; Linux i686; rv:98.0) Gecko/20100101 Firefox/98.0', NULL, '82');
INSERT INTO `Logs` VALUES ('86', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-06 12:07:59', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('87', '53', 'CERRAR_TICKET', 'Ticket #CSI2026040698981 cerrado como: Cerrado Exitosamente - Solución: se instala acceso a impresora del despacho y de instala la herramienta AdbeRdr910_es_ES para solucio', '2026-04-06 12:15:28', '172.27.195.179', 'Mozilla/5.0 (X11; Linux i686; rv:98.0) Gecko/20100101 Firefox/98.0', NULL, '83');
INSERT INTO `Logs` VALUES ('88', '91', 'LOGIN', 'Inicio de sesión exitoso - Usuario: GAVIDIA RIVAS, NEIDA - Privilegio: usuario', '2026-04-06 12:18:41', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('89', '53', 'CERRAR_TICKET', 'Ticket #CSI2026040690951 cerrado como: Cerrado Exitosamente - Solución: se configuro impresora con el IP 172.27.195.46', '2026-04-06 12:37:58', '172.27.195.179', 'Mozilla/5.0 (X11; Linux i686; rv:98.0) Gecko/20100101 Firefox/98.0', NULL, '85');
INSERT INTO `Logs` VALUES ('90', '53', 'CERRAR_TICKET', 'Ticket #CSI2026040664873 cerrado como: Cerrado Exitosamente - Solución: SE CONFIGURA Y ACTUALIZA LA HORA Y FECHA', '2026-04-06 12:40:23', '172.27.195.179', 'Mozilla/5.0 (X11; Linux i686; rv:98.0) Gecko/20100101 Firefox/98.0', NULL, '86');
INSERT INTO `Logs` VALUES ('91', '53', 'CERRAR_TICKET', 'Ticket #CSI2026040676371 cerrado como: Cerrado Exitosamente - Solución: SE REINSTALA EL EXPLORADOR MOZILLA FIREFOX', '2026-04-06 12:44:04', '172.27.195.179', 'Mozilla/5.0 (X11; Linux i686; rv:98.0) Gecko/20100101 Firefox/98.0', NULL, '87');
INSERT INTO `Logs` VALUES ('92', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-06 12:46:40', '172.27.195.34', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36 Edg/136.0.0.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('93', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-06 12:58:21', '172.27.160.160', 'Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('94', '51', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Rafael Augusto Molina Ruiz - Privilegio: tecnico', '2026-04-06 13:46:48', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('95', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-06 13:49:41', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('96', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-06 13:50:36', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('97', '53', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Tomas Elias Valera Torrealba - Privilegio: tecnico', '2026-04-06 14:26:40', '172.27.195.179', 'Mozilla/5.0 (X11; Linux i686; rv:98.0) Gecko/20100101 Firefox/98.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('98', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-06 15:03:29', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('99', '36', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Dionny Toro - Privilegio: tecnico', '2026-04-06 15:05:09', '172.27.211.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('100', '51', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Rafael Augusto Molina Ruiz - Privilegio: tecnico', '2026-04-06 15:11:05', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('101', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-06 15:20:05', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('102', '37', 'CERRAR_TICKET', 'Ticket #CSI2026040634613 cerrado como: Cerrado No Exitoso - Solución: se recomienda cambiar el disco duro, ya que el del equipo se encuentra dañado.', '2026-04-06 15:22:22', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0', NULL, '80');
INSERT INTO `Logs` VALUES ('103', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-06 15:26:18', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('104', '51', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Rafael Augusto Molina Ruiz - Privilegio: tecnico', '2026-04-06 15:26:50', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('105', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-06 15:52:52', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('106', '50', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Orangel Davila - Privilegio: tecnico', '2026-04-06 16:21:35', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('107', '54', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Victor manuel Cedeño Vega - Privilegio: tecnico', '2026-04-06 16:43:36', '172.27.211.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('108', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-07 08:36:22', '172.27.160.160', 'Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('109', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-07 08:47:53', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('110', '45', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Karen Yelena Vergara Toro - Privilegio: tecnico', '2026-04-07 08:50:49', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('111', '38', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Eladio Antonio Torres Peña - Privilegio: tecnico', '2026-04-07 08:51:23', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('112', '45', 'CERRAR_TICKET', 'Ticket #CSI2026031266634 cerrado como: Cerrado Exitosamente - Solución: se instalo nuevamente sistema operativo', '2026-04-07 08:54:00', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, '42');
INSERT INTO `Logs` VALUES ('113', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-07 09:10:32', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('114', '36', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Dionny Toro - Privilegio: tecnico', '2026-04-07 09:11:22', '172.27.211.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('115', '38', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Eladio Antonio Torres Peña - Privilegio: tecnico', '2026-04-07 09:11:40', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('116', '91', 'LOGIN', 'Inicio de sesión exitoso - Usuario: GAVIDIA RIVAS, NEIDA - Privilegio: usuario', '2026-04-07 13:30:12', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('117', '53', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Tomas Elias Valera Torrealba - Privilegio: tecnico', '2026-04-07 13:34:50', '172.27.195.179', 'Mozilla/5.0 (X11; Linux i686; rv:98.0) Gecko/20100101 Firefox/98.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('118', '44', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Jean Paul Toro Rojo - Privilegio: tecnico', '2026-04-07 13:35:34', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('119', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-07 13:45:14', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('120', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-07 13:46:14', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('121', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-07 13:54:28', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('122', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-07 13:55:51', '172.27.160.160', 'Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('123', '46', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Martha Laguado de Albarran - Privilegio: tecnico', '2026-04-07 14:41:10', '172.27.211.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('124', '36', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Dionny Toro - Privilegio: tecnico', '2026-04-07 14:43:43', '172.27.211.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('125', '44', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Jean Paul Toro Rojo - Privilegio: tecnico', '2026-04-07 14:45:20', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('126', '41', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Hector Eduardo Iscala Ramirez - Privilegio: tecnico', '2026-04-07 14:48:49', '172.27.211.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('127', '48', 'LOGIN', 'Inicio de sesión exitoso - Usuario: MILJAIR JOSUE PEÑA ALAÑA - Privilegio: tecnico', '2026-04-07 14:52:35', '172.27.211.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('128', '39', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Ernesto Cherminy Guevara Vielma - Privilegio: tecnico', '2026-04-07 14:54:04', '172.27.211.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('129', '36', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Dionny Toro - Privilegio: tecnico', '2026-04-07 14:54:48', '172.27.211.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('130', '46', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Martha Laguado de Albarran - Privilegio: tecnico', '2026-04-07 15:05:50', '172.27.211.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('131', '41', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Hector Eduardo Iscala Ramirez - Privilegio: tecnico', '2026-04-07 15:15:05', '172.27.211.16', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('132', '46', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Martha Laguado de Albarran - Privilegio: tecnico', '2026-04-07 15:22:11', '172.27.211.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('133', '38', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Eladio Antonio Torres Peña - Privilegio: tecnico', '2026-04-07 15:32:28', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('134', '38', 'CERRAR_TICKET', 'Ticket #CSI2026040796054 cerrado como: Cerrado Exitosamente - Solución: Se cambia cable vga, por el equipo mini pc, a este ultimo se le coloca su cable hdmi, quedando opera', '2026-04-07 15:36:18', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '105');
INSERT INTO `Logs` VALUES ('135', '38', 'CERRAR_TICKET', 'Ticket #CSI2026040780139 cerrado como: Cerrado Exitosamente - Solución: Se realiza analisis con Karpesky antivirus encontrando virus en el mismo, se reemplaza en mcaffe del', '2026-04-07 15:38:47', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '92');
INSERT INTO `Logs` VALUES ('136', '36', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Dionny Toro - Privilegio: tecnico', '2026-04-07 15:49:50', '172.27.211.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('137', '50', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Orangel Davila - Privilegio: tecnico', '2026-04-07 15:56:22', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('138', '50', 'CERRAR_TICKET', 'Ticket #CSI2026040691065 cerrado como: Cerrado Exitosamente - Solución: se creo un acceso directo a la carpeta', '2026-04-07 15:58:26', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '88');
INSERT INTO `Logs` VALUES ('139', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-07 16:02:18', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('140', '7', 'CERRAR_TICKET', 'Ticket #CSI2026040778919 cerrado como: Cerrado Exitosamente - Solución: ajuste de memoria', '2026-04-07 16:05:04', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '103');
INSERT INTO `Logs` VALUES ('141', '50', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Orangel Davila - Privilegio: tecnico', '2026-04-07 16:05:31', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('142', '38', 'CERRAR_TICKET', 'Ticket #CSI2026040795741 cerrado como: Cerrado No Exitoso - Solución: a la espera de remplazo del ssd', '2026-04-07 16:19:58', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '106');
INSERT INTO `Logs` VALUES ('143', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-08 08:41:10', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('144', '47', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Mauro Imar Diaz Dugarte - Privilegio: tecnico', '2026-04-08 09:07:25', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('145', '51', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Rafael Augusto Molina Ruiz - Privilegio: tecnico', '2026-04-08 09:08:23', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('146', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-08 09:11:31', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('147', '44', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Jean Paul Toro Rojo - Privilegio: tecnico', '2026-04-08 09:21:00', '172.27.195.7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('148', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-08 09:21:15', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('149', '86', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Ramon Muñoz - Privilegio: tecnico', '2026-04-08 09:21:16', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('150', '45', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Karen Yelena Vergara Toro - Privilegio: tecnico', '2026-04-08 09:24:10', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('151', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-08 09:24:19', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('152', '80', 'LOGIN', 'Inicio de sesión exitoso - Usuario: APONTE  PUENTES, MELWIN ENRIQUE - Privilegio: tecnico', '2026-04-08 09:25:30', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('153', '80', 'CERRAR_TICKET', 'Ticket #CSI2026040673232 cerrado como: Cerrado Exitosamente - Solución: AL  asistir el regulador  estaba  funcionando.  no se  reslizo nada', '2026-04-08 09:26:37', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, '78');
INSERT INTO `Logs` VALUES ('154', '80', 'CERRAR_TICKET', 'Ticket #CSI2026040851088 cerrado como: Cerrado Exitosamente - Solución: Ya  se  hizo la  recarga 7 de  marzo 2026  se  le  entrego a la  Jede  de  Servicios  Judiciales', '2026-04-08 09:28:40', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, '109');
INSERT INTO `Logs` VALUES ('155', '53', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Tomas Elias Valera Torrealba - Privilegio: tecnico', '2026-04-08 09:56:23', '172.27.195.179', 'Mozilla/5.0 (X11; Linux i686; rv:98.0) Gecko/20100101 Firefox/98.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('156', '35', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Cesar Herney Chourio Ruiz - Privilegio: tecnico', '2026-04-08 10:19:12', '172.27.195.243', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('157', '51', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Rafael Augusto Molina Ruiz - Privilegio: tecnico', '2026-04-08 10:34:33', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('158', '35', 'CERRAR_TICKET', 'Ticket #CSI2026031329530 cerrado como: Cerrado Exitosamente - Solución: Informe entregado a Ing. Milana Medina', '2026-04-08 10:44:16', '172.27.195.243', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, '48');
INSERT INTO `Logs` VALUES ('159', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-08 11:16:15', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('160', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-08 11:16:57', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('161', '51', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Rafael Augusto Molina Ruiz - Privilegio: tecnico', '2026-04-08 11:19:04', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('162', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-08 11:19:34', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('163', '51', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Rafael Augusto Molina Ruiz - Privilegio: tecnico', '2026-04-08 11:20:11', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('164', '35', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Cesar Herney Chourio Ruiz - Privilegio: tecnico', '2026-04-08 11:21:05', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('165', '51', 'CERRAR_TICKET', 'Ticket #CSI2026040829490 cerrado como: Cerrado Exitosamente - Solución: Reparado etc etc etc etc', '2026-04-08 11:23:16', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, '110');
INSERT INTO `Logs` VALUES ('166', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-08 11:25:46', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('167', '60', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Marbel Andreina Riera Castillo - Privilegio: usuario', '2026-04-08 11:26:43', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('168', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-08 11:31:30', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('169', '47', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Mauro Imar Diaz Dugarte - Privilegio: tecnico', '2026-04-08 11:32:06', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('170', '51', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Rafael Augusto Molina Ruiz - Privilegio: tecnico', '2026-04-08 11:32:59', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('171', '47', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Mauro Imar Diaz Dugarte - Privilegio: tecnico', '2026-04-08 11:33:43', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('172', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-08 11:34:27', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('173', '35', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Cesar Herney Chourio Ruiz - Privilegio: tecnico', '2026-04-08 11:35:21', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('174', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-08 11:39:14', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('175', '35', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Cesar Herney Chourio Ruiz - Privilegio: tecnico', '2026-04-08 11:39:37', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('176', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-08 11:40:28', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('177', '35', 'CERRAR_TICKET', 'Ticket #CSI2026040869273 cerrado como: Cerrado Exitosamente - Solución: Quedo Operativo', '2026-04-08 11:42:17', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '111');
INSERT INTO `Logs` VALUES ('178', '37', 'CERRAR_TICKET', 'Ticket #CSI2026040836154 cerrado como: Cerrado Exitosamente - Solución: se verifico que la impresora estuviera instalada con sus respectivos controladores', '2026-04-08 11:44:38', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '112');
INSERT INTO `Logs` VALUES ('179', '51', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Rafael Augusto Molina Ruiz - Privilegio: tecnico', '2026-04-08 13:33:22', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('180', '45', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Karen Yelena Vergara Toro - Privilegio: tecnico', '2026-04-08 13:40:23', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('181', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-08 14:15:25', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('182', '44', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Jean Paul Toro Rojo - Privilegio: tecnico', '2026-04-08 14:39:06', '172.27.192.228', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('183', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-08 14:42:51', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('184', '53', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Tomas Elias Valera Torrealba - Privilegio: tecnico', '2026-04-08 14:44:04', '172.27.195.179', 'Mozilla/5.0 (X11; Linux i686; rv:98.0) Gecko/20100101 Firefox/98.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('185', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-08 14:49:11', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('186', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-08 14:49:51', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('187', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-08 14:54:35', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('188', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-08 15:00:15', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('189', '38', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Eladio Antonio Torres Peña - Privilegio: tecnico', '2026-04-08 15:01:41', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('190', '35', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Cesar Herney Chourio Ruiz - Privilegio: tecnico', '2026-04-08 15:06:58', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('191', '56', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Darsy Coromoto Suarez de Hull - Privilegio: usuario', '2026-04-08 15:23:15', '172.27.195.206', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('192', '38', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Eladio Antonio Torres Peña - Privilegio: tecnico', '2026-04-08 15:44:50', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('193', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-08 15:50:11', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('194', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-08 16:02:17', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('195', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-08 16:03:49', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('196', '44', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Jean Paul Toro Rojo - Privilegio: tecnico', '2026-04-09 09:20:47', '172.27.195.7', 'Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('197', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-09 09:32:41', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('198', '44', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Jean Paul Toro Rojo - Privilegio: tecnico', '2026-04-09 09:32:58', '172.27.195.7', 'Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('199', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-09 09:37:09', '172.27.160.160', 'Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('200', '38', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Eladio Antonio Torres Peña - Privilegio: tecnico', '2026-04-09 09:46:45', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('201', '45', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Karen Yelena Vergara Toro - Privilegio: tecnico', '2026-04-09 09:58:34', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('202', '44', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Jean Paul Toro Rojo - Privilegio: tecnico', '2026-04-09 09:59:48', '172.27.195.7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('203', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-09 10:26:13', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('204', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-09 10:27:55', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('205', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-09 10:36:16', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('206', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-09 10:43:25', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('207', '44', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Jean Paul Toro Rojo - Privilegio: tecnico', '2026-04-09 10:51:54', '172.27.196.7', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('208', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-09 10:55:36', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('209', '53', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Tomas Elias Valera Torrealba - Privilegio: tecnico', '2026-04-09 11:04:33', '172.27.160.160', 'Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('210', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-09 11:20:26', '172.27.195.80', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('211', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-09 11:26:44', '172.27.160.160', 'Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('212', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-09 11:43:26', '172.27.195.80', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('213', '38', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Eladio Antonio Torres Peña - Privilegio: tecnico', '2026-04-09 12:02:46', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('214', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-09 12:17:54', '172.27.160.160', 'Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('215', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-09 14:38:31', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('216', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-09 15:07:57', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('217', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-09 15:13:09', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('218', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-09 15:15:13', '172.27.195.243', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('219', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-09 15:17:10', '172.27.195.243', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('220', '36', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Dionny Toro - Privilegio: tecnico', '2026-04-09 15:46:55', '172.27.211.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('221', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-09 15:55:32', '172.27.160.160', 'Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('222', '50', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Orangel Davila - Privilegio: tecnico', '2026-04-09 16:10:59', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('223', '50', 'CERRAR_TICKET', 'Ticket #CSI2026040920594 cerrado como: Cerrado Exitosamente - Solución: instalacion de equipo a la auxiliar de asistente de coordinacion y creacion de nombre en magistratur', '2026-04-09 16:12:47', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '126');
INSERT INTO `Logs` VALUES ('224', '50', 'CERRAR_TICKET', 'Ticket #CSI2026040917525 cerrado como: Cerrado Exitosamente - Solución: instalacion de pc nueva a la doctora carmen y pasar el respectivo respaldo de usuario', '2026-04-09 16:15:15', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '127');
INSERT INTO `Logs` VALUES ('225', '50', 'CERRAR_TICKET', 'Ticket #CSI2026040915249 cerrado como: Cerrado Exitosamente - Solución: no resuelto hacerse el pendejo', '2026-04-09 16:19:35', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '128');
INSERT INTO `Logs` VALUES ('226', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-10 08:44:20', '172.27.195.243', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('227', '50', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Orangel Davila - Privilegio: tecnico', '2026-04-10 08:45:00', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('228', '35', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Cesar Herney Chourio Ruiz - Privilegio: tecnico', '2026-04-10 08:49:31', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('229', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-10 09:19:45', '172.27.160.160', 'Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('230', '60', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Marbel Andreina Riera Castillo - Privilegio: usuario', '2026-04-10 09:22:12', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('231', '35', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Cesar Herney Chourio Ruiz - Privilegio: tecnico', '2026-04-10 09:33:02', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('232', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-10 10:05:15', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('233', '74', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Sandra Carrero - Privilegio: usuario', '2026-04-10 10:09:41', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('234', '38', 'CERRAR_TICKET', 'Ticket #CSI2026041032119 cerrado como: Cerrado Exitosamente - Solución: Solucitudes atendidas y enviadas la dem central', '2026-04-10 10:17:29', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '130');
INSERT INTO `Logs` VALUES ('235', '38', 'CERRAR_TICKET', 'Ticket #CSI2026041024277 cerrado como: Cerrado Exitosamente - Solución: Caso aTendido satisfactoriamente', '2026-04-10 10:21:22', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '131');
INSERT INTO `Logs` VALUES ('236', '38', 'CERRAR_TICKET', 'Ticket #CSI2026041069476 cerrado como: Cerrado Exitosamente - Solución: Solicitud remitida a seguridad informatica de la odi', '2026-04-10 10:39:01', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '132');
INSERT INTO `Logs` VALUES ('237', '53', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Tomas Elias Valera Torrealba - Privilegio: tecnico', '2026-04-10 10:42:56', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('238', '38', 'CERRAR_TICKET', 'Ticket #CSI2026041075095 cerrado como: Cerrado Exitosamente - Solución: Respaldo de juris lopnna se ejecuta a 10.46am de 10-04-26 para cumplir con error del dia anterior
R', '2026-04-10 10:48:12', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '133');
INSERT INTO `Logs` VALUES ('239', '38', 'CERRAR_TICKET', 'Ticket #CSI2026041053083 cerrado como: Cerrado Exitosamente - Solución: Se instala abby finereader en su version 10', '2026-04-10 10:51:25', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '134');
INSERT INTO `Logs` VALUES ('240', '45', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Karen Yelena Vergara Toro - Privilegio: tecnico', '2026-04-10 10:51:50', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('241', '53', 'CERRAR_TICKET', 'Ticket #CSI2026040957845 cerrado como: Cerrado Exitosamente - Solución: SE REINSTALA SISTEMA OPERATIVO W10 64BITS CON SUS APLICACIONES Y HERRAMIENTAS NECESARIAS PARA EL BUE', '2026-04-10 10:52:10', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, '120');
INSERT INTO `Logs` VALUES ('242', '53', 'CERRAR_TICKET', 'Ticket #CSI2026040787605 cerrado como: Cerrado Exitosamente - Solución: SE REINSTALA SISTEMA OPERATIVO XP CON SUS APLICACIONES Y HERRAMIENTAS NECESARIAS PARA EL FUNCIONAMIE', '2026-04-10 10:55:52', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, '101');
INSERT INTO `Logs` VALUES ('243', '53', 'CERRAR_TICKET', 'Ticket #CSI2026032588718 cerrado como: Cerrado Exitosamente - Solución: EL FUNCIONARIO RAFAEL MOLINA  DEL TALLER OATI, ME INDICA QUE EL MONITOR TIENE PANTALLA PARTIDA Y PLA', '2026-04-10 10:58:40', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, '56');
INSERT INTO `Logs` VALUES ('244', '35', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Cesar Herney Chourio Ruiz - Privilegio: tecnico', '2026-04-10 11:00:53', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('245', '38', 'CERRAR_TICKET', 'Ticket #CSI2026041065378 cerrado como: Cerrado Exitosamente - Solución: Solicitud enviada a la den y tsj en ccs', '2026-04-10 11:04:45', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '136');
INSERT INTO `Logs` VALUES ('246', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-10 11:14:46', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('247', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-10 11:23:42', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('248', '53', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Tomas Elias Valera Torrealba - Privilegio: tecnico', '2026-04-10 11:23:43', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:77.0) Gecko/20100101 Firefox/77.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('249', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-10 11:36:39', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('250', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-10 12:16:30', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('251', '7', 'CERRAR_TICKET', 'Ticket #CSI2026041079723 cerrado como: Cerrado Exitosamente - Solución: Cerrado con exito', '2026-04-10 12:19:47', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '140');
INSERT INTO `Logs` VALUES ('252', '53', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Tomas Elias Valera Torrealba - Privilegio: tecnico', '2026-04-10 12:51:10', '172.27.195.179', 'Mozilla/5.0 (X11; Linux i686; rv:98.0) Gecko/20100101 Firefox/98.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('253', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-10 13:52:07', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('254', '53', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Tomas Elias Valera Torrealba - Privilegio: tecnico', '2026-04-10 14:52:44', '172.27.195.179', 'Mozilla/5.0 (X11; Linux i686; rv:98.0) Gecko/20100101 Firefox/98.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('255', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-10 15:46:43', '172.27.160.160', 'Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('256', '38', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Eladio Antonio Torres Peña - Privilegio: tecnico', '2026-04-10 15:52:46', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('257', '50', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Orangel Davila - Privilegio: tecnico', '2026-04-10 16:04:28', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('258', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-13 08:40:35', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('259', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-13 08:44:20', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('260', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-13 08:54:01', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('261', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-13 09:16:11', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('262', '35', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Cesar Herney Chourio Ruiz - Privilegio: tecnico', '2026-04-13 09:18:47', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('263', '45', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Karen Yelena Vergara Toro - Privilegio: tecnico', '2026-04-13 09:19:50', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('264', '56', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Darsy Coromoto Suarez de Hull - Privilegio: usuario', '2026-04-13 09:40:42', '172.27.195.206', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('265', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-13 10:00:07', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('266', '37', 'CERRAR_TICKET', 'Ticket #CSI2026041338361 cerrado como: Cerrado Exitosamente - Solución: usuario desbloqueado', '2026-04-13 10:06:32', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '149');
INSERT INTO `Logs` VALUES ('267', '7', 'CERRAR_TICKET', 'Ticket #CSI2026041379589 cerrado como: Cerrado Exitosamente - Solución: cerrado con exito', '2026-04-13 10:13:02', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '150');
INSERT INTO `Logs` VALUES ('268', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-13 10:20:10', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('269', '91', 'LOGIN', 'Inicio de sesión exitoso - Usuario: GAVIDIA RIVAS, NEIDA - Privilegio: usuario', '2026-04-13 10:30:01', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('270', '56', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Darsy Coromoto Suarez de Hull - Privilegio: usuario', '2026-04-13 10:48:19', '172.27.195.206', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('271', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-13 10:59:29', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('272', '37', 'CERRAR_TICKET', 'Ticket #CSI2026041355734 cerrado como: Cerrado Exitosamente - Solución: se instalo la conexion con la impresora del pool a la secretaria', '2026-04-13 11:02:40', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '152');
INSERT INTO `Logs` VALUES ('273', '50', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Orangel Davila - Privilegio: tecnico', '2026-04-13 11:57:09', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('274', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-13 13:52:08', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('275', '37', 'CERRAR_TICKET', 'Ticket #CSI2026041351160 cerrado como: Cerrado Exitosamente - Solución: requerimiento procesado', '2026-04-13 13:52:32', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '147');
INSERT INTO `Logs` VALUES ('276', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-13 14:04:28', '172.27.160.160', 'Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('277', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-13 14:20:38', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('278', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-13 14:26:22', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('279', '7', 'CERRAR_TICKET', 'Ticket #CSI2026041391068 cerrado como: Cerrado Exitosamente - Solución: Entregado y  en funcionamiento', '2026-04-13 14:29:59', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, '160');
INSERT INTO `Logs` VALUES ('280', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-13 14:31:55', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('281', '7', 'CERRAR_TICKET', 'Ticket #CSI2026041331129 cerrado como: Cerrado Exitosamente - Solución: Cerrado con exito', '2026-04-13 14:36:15', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, '159');
INSERT INTO `Logs` VALUES ('282', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-13 14:46:38', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('283', '55', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Freddy Alejandro Rincon Rivas - Privilegio: director', '2026-04-13 14:47:45', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('284', '50', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Orangel Davila - Privilegio: tecnico', '2026-04-13 14:50:22', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('285', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-13 15:02:51', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('286', '55', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Freddy Alejandro Rincon Rivas - Privilegio: director', '2026-04-13 15:10:20', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('287', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-13 15:13:12', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('288', '7', 'CERRAR_TICKET', 'Ticket #CSI2026041327233 cerrado como: Cerrado Exitosamente - Solución: Cerrado Exitosamente', '2026-04-13 15:55:30', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, '163');
INSERT INTO `Logs` VALUES ('289', '7', 'CERRAR_TICKET', 'Ticket #CSI2026041326041 cerrado como: Cerrado Exitosamente - Solución: Cerrado  exito y en funcionamiento', '2026-04-13 16:10:41', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, '164');
INSERT INTO `Logs` VALUES ('290', '50', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Orangel Davila - Privilegio: tecnico', '2026-04-13 16:24:01', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('291', '39', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Ernesto Cherminy Guevara Vielma - Privilegio: tecnico', '2026-04-13 16:39:05', '172.27.211.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('292', '91', 'LOGIN', 'Inicio de sesión exitoso - Usuario: GAVIDIA RIVAS, NEIDA - Privilegio: usuario', '2026-04-14 08:39:32', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('293', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-14 08:42:09', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('294', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-14 08:44:34', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('295', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-14 08:46:59', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('296', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-14 08:48:53', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('297', '50', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Orangel Davila - Privilegio: tecnico', '2026-04-14 09:07:40', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('298', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-14 09:09:51', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('299', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-14 09:15:02', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('300', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-14 09:29:52', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('301', '84', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Usuario Prueba - Privilegio: usuario', '2026-04-14 09:45:56', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('302', '35', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Cesar Herney Chourio Ruiz - Privilegio: tecnico', '2026-04-14 09:53:32', '172.27.195.243', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('303', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-14 09:54:01', '172.27.195.243', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('304', '35', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Cesar Herney Chourio Ruiz - Privilegio: tecnico', '2026-04-14 09:55:17', '172.27.195.243', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('305', '50', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Orangel Davila - Privilegio: tecnico', '2026-04-14 10:13:43', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('306', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-14 10:34:50', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('307', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-14 10:42:15', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('308', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-14 11:22:21', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('309', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-14 11:31:31', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('310', '7', 'CERRAR_TICKET', 'Ticket #CSI2026041416047 cerrado como: Cerrado Exitosamente - Solución: Cerrado con exito', '2026-04-14 11:36:34', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, '174');
INSERT INTO `Logs` VALUES ('311', '7', 'CERRAR_TICKET', 'Ticket #CSI2026041412008 cerrado como: Cerrado Exitosamente - Solución: Cerrado con exito', '2026-04-14 11:37:32', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, '173');
INSERT INTO `Logs` VALUES ('312', '45', 'CERRAR_TICKET', 'Ticket #CSI2026041425967 cerrado como: Cerrado Exitosamente - Solución: se ingreso a Magistratura', '2026-04-14 14:37:37', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, '180');
INSERT INTO `Logs` VALUES ('313', '51', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Rafael Augusto Molina Ruiz - Privilegio: tecnico', '2026-04-14 15:03:39', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('314', '46', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Martha Laguado de Albarran - Privilegio: tecnico', '2026-04-14 17:16:25', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('315', '46', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Martha Laguado de Albarran - Privilegio: tecnico', '2026-04-14 18:09:09', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('316', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-15 08:45:05', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('317', '91', 'LOGIN', 'Inicio de sesión exitoso - Usuario: GAVIDIA RIVAS, NEIDA - Privilegio: usuario', '2026-04-15 08:53:49', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('318', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA - Privilegio: usuario', '2026-04-15 08:58:22', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('319', '82', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Jorge Avila - Privilegio: usuario', '2026-04-15 09:00:23', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('320', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-15 09:10:22', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('321', '45', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Karen Yelena Vergara Toro - Privilegio: tecnico', '2026-04-15 09:10:23', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('322', '45', 'CERRAR_TICKET', 'Ticket #CSI2026041513454 cerrado como: Cerrado Exitosamente - Solución: se le realizo cambio de contraseña y se debloqueo el usuario', '2026-04-15 09:24:21', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, '193');
INSERT INTO `Logs` VALUES ('323', '46', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Martha Laguado de Albarran - Privilegio: tecnico', '2026-04-15 09:30:01', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('324', '38', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Eladio Antonio Torres Peña - Privilegio: tecnico', '2026-04-15 09:30:02', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('325', '46', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Martha Laguado de Albarran - Privilegio: tecnico', '2026-04-15 09:37:49', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('326', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-15 09:43:01', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('327', '7', 'CERRAR_TICKET', 'Ticket #CSI2026041545150 cerrado como: Cerrado Exitosamente - Solución: Se informo al coordinador  y mando un funcionario para  solventar el problema', '2026-04-15 09:50:18', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, '191');
INSERT INTO `Logs` VALUES ('328', '38', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Eladio Antonio Torres Peña - Privilegio: tecnico', '2026-04-15 09:59:34', '172.27.203.126', 'Mozilla/5.0 (Windows NT 10.0; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('329', '50', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Orangel Davila - Privilegio: tecnico', '2026-04-15 10:20:25', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('330', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-15 10:42:10', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('331', '50', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Orangel Davila - Privilegio: tecnico', '2026-04-15 10:43:25', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('332', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-15 10:44:35', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('333', '53', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Tomas Elias Valera Torrealba - Privilegio: tecnico', '2026-04-15 10:51:12', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('334', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-15 10:58:15', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('335', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-15 11:25:27', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:52.0) Gecko/20100101 Firefox/52.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('336', '45', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Karen Yelena Vergara Toro - Privilegio: tecnico', '2026-04-15 11:34:49', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('337', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-15 14:28:35', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('338', '45', 'CERRAR_TICKET', 'Ticket #CSI2026041546809 cerrado como: Cerrado Exitosamente - Solución: se ingreso equipo a magistratura', '2026-04-15 14:44:00', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, '205');
INSERT INTO `Logs` VALUES ('339', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-16 08:40:34', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('340', '47', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Mauro Imar Diaz Dugarte - Privilegio: tecnico', '2026-04-16 09:09:54', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('341', '47', 'CERRAR_TICKET', 'Ticket #CSI2026041614793 cerrado como: Cerrado Exitosamente - Solución: trabajando perfectamenta', '2026-04-16 09:12:34', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, '207');
INSERT INTO `Logs` VALUES ('342', '47', 'CERRAR_TICKET', 'Ticket #CSI2026041685660 cerrado como: Cerrado Exitosamente - Solución: funcionando con total normalidad', '2026-04-16 09:14:43', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, '208');
INSERT INTO `Logs` VALUES ('343', '82', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Jorge Avila - Privilegio: bienes', '2026-04-16 09:56:27', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('344', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA DEL PILAR - Privilegio: usuario', '2026-04-16 11:30:39', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('345', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-16 12:19:15', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('346', '67', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Hermelinda C. Leon Avendaño - Privilegio: bienes', '2026-04-16 12:57:59', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('347', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-16 13:45:17', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('348', '37', 'CERRAR_TICKET', 'Ticket #CSI2026041637187 cerrado como: Cerrado Exitosamente - Solución: caso cerrado', '2026-04-16 14:01:49', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '209');
INSERT INTO `Logs` VALUES ('349', '41', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Hector Eduardo Iscala Ramirez - Privilegio: tecnico', '2026-04-16 15:43:15', '172.27.211.16', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('350', '46', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Martha Laguado de Albarran - Privilegio: tecnico', '2026-04-16 15:48:29', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('351', '36', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Dionny Toro - Privilegio: tecnico', '2026-04-16 15:49:39', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:148.0) Gecko/20100101 Firefox/148.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('352', '36', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Dionny Toro - Privilegio: tecnico', '2026-04-16 16:00:53', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:148.0) Gecko/20100101 Firefox/148.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('353', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-17 08:37:40', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('354', '36', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Dionny Toro - Privilegio: tecnico', '2026-04-17 08:53:07', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('355', '95', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Marquez Vargas Susan - Privilegio: tecnico', '2026-04-17 09:20:27', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:140.0) Gecko/20100101 Firefox/140.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('356', '67', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Hermelinda C. Leon Avendaño - Privilegio: bienes', '2026-04-17 09:43:45', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('357', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-17 09:45:31', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('358', '96', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Bienes - Privilegio: bienes', '2026-04-17 09:46:53', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('359', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-17 09:48:03', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('360', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-17 10:00:41', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('361', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA DEL PILAR - Privilegio: usuario', '2026-04-17 10:03:53', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('362', '45', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Karen Yelena Vergara Toro - Privilegio: tecnico', '2026-04-17 10:10:07', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('363', '45', 'CERRAR_TICKET', 'Ticket #CSI2026041720166 cerrado como: Cerrado Exitosamente - Solución: se ingreso el equipo a magistratura', '2026-04-17 10:12:17', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, '220');
INSERT INTO `Logs` VALUES ('364', '45', 'CERRAR_TICKET', 'Ticket #CSI2026041733969 cerrado como: Cerrado Exitosamente - Solución: se restauro el perfil del usuario', '2026-04-17 10:14:16', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, '221');
INSERT INTO `Logs` VALUES ('365', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-17 10:27:42', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('366', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-17 11:08:58', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('367', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-17 11:13:57', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('368', '37', 'CERRAR_TICKET', 'Ticket #CSI2026041723438 cerrado como: Cerrado Exitosamente - Solución: cerrado exitoso.', '2026-04-17 11:14:46', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '219');
INSERT INTO `Logs` VALUES ('369', '38', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Eladio Antonio Torres Peña - Privilegio: tecnico', '2026-04-17 11:42:54', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('370', '53', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Tomas Elias Valera Torrealba - Privilegio: tecnico', '2026-04-17 12:51:04', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/113.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('371', '38', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Eladio Antonio Torres Peña - Privilegio: tecnico', '2026-04-17 14:03:52', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('372', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-17 14:18:46', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('373', '35', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Cesar Herney Chourio Ruiz - Privilegio: tecnico', '2026-04-17 15:37:21', '172.27.195.243', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('374', '55', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Freddy Alejandro Rincon Rivas - Privilegio: director', '2026-04-17 15:46:07', '172.27.195.189', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('375', '46', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Martha Laguado de Albarran - Privilegio: tecnico', '2026-04-17 16:30:32', '172.27.211.23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('376', '46', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Martha Laguado de Albarran - Privilegio: tecnico', '2026-04-17 16:31:44', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('377', '46', 'CERRAR_TICKET', 'Ticket #CSI2026041640630 cerrado como: Cerrado Exitosamente - Solución: IMPRESORA INSTALADA', '2026-04-17 16:34:54', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, '211');
INSERT INTO `Logs` VALUES ('378', '46', 'CERRAR_TICKET', 'Ticket #CSI2026041695367 cerrado como: Cerrado Exitosamente - Solución: USUARIO DESBLOQUEADO', '2026-04-17 16:37:21', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, '216');
INSERT INTO `Logs` VALUES ('379', '36', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Dionny Toro - Privilegio: tecnico', '2026-04-17 16:39:43', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('380', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA DEL PILAR - Privilegio: usuario', '2026-04-20 08:24:16', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('381', '56', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Darsy Coromoto Suarez de Hull - Privilegio: usuario', '2026-04-20 08:36:13', '172.27.195.206', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('382', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-20 08:53:58', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('383', '95', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Marquez Vargas Susan - Privilegio: tecnico', '2026-04-20 09:12:05', '172.27.195.213', 'Mozilla/5.0 (Windows NT 10.0; rv:140.0) Gecko/20100101 Firefox/140.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('384', '51', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Rafael Augusto Molina Ruiz - Privilegio: tecnico', '2026-04-20 09:43:34', '172.27.195.87', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('385', '45', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Karen Yelena Vergara Toro - Privilegio: tecnico', '2026-04-20 09:47:04', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('386', '45', 'CERRAR_TICKET', 'Ticket #CSI2026042021532 cerrado como: Cerrado Exitosamente - Solución: restablecimiento contraseña y se ingreso el equipo a magistratura', '2026-04-20 09:59:52', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, '230');
INSERT INTO `Logs` VALUES ('387', '67', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Hermelinda C. Leon Avendaño - Privilegio: bienes', '2026-04-20 10:39:26', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('388', '91', 'LOGIN', 'Inicio de sesión exitoso - Usuario: GAVIDIA RIVAS, NEIDA - Privilegio: usuario', '2026-04-20 10:49:52', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('389', '53', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Tomas Elias Valera Torrealba - Privilegio: tecnico', '2026-04-20 11:10:23', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/113.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('390', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-20 11:17:06', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('391', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-20 11:32:41', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('392', '7', 'CERRAR_TICKET', 'Ticket #CSI2026042071030 cerrado como: Cerrado Exitosamente - Solución: Reprogramado por  llegada d e  gandola', '2026-04-20 11:34:40', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '229');
INSERT INTO `Logs` VALUES ('393', '38', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Eladio Antonio Torres Peña - Privilegio: tecnico', '2026-04-20 11:39:20', '172.27.203.64', 'Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('394', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-20 11:55:22', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('395', '53', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Tomas Elias Valera Torrealba - Privilegio: tecnico', '2026-04-20 13:15:31', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/113.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('396', '67', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Hermelinda C. Leon Avendaño - Privilegio: bienes', '2026-04-20 13:48:20', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('397', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-20 14:05:19', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('398', '37', 'CERRAR_TICKET', 'Ticket #CSI2026041720252 cerrado como: Cerrado Exitosamente - Solución: cerrado exitoso', '2026-04-20 14:05:47', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, '228');
INSERT INTO `Logs` VALUES ('399', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-20 14:45:04', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('400', '50', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Orangel Davila - Privilegio: tecnico', '2026-04-20 14:49:11', '172.27.195.141', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', NULL, NULL);
INSERT INTO `Logs` VALUES ('401', '91', 'LOGIN', 'Inicio de sesión exitoso - Usuario: GAVIDIA RIVAS, NEIDA - Privilegio: usuario', '2026-04-20 14:57:01', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('402', '95', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Marquez Vargas Susan - Privilegio: tecnico', '2026-04-20 15:11:29', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('403', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-20 15:17:01', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('404', '37', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Edgar Jesus Torrealba Uzcategui - Privilegio: tecnico', '2026-04-20 15:49:18', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('405', '94', 'LOGIN', 'Inicio de sesión exitoso - Usuario: SANGUINETTI ALARCON, ADA PIERINA DEL PILAR - Privilegio: usuario', '2026-04-21 08:21:53', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('406', '45', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Karen Yelena Vergara Toro - Privilegio: tecnico', '2026-04-21 08:51:26', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('407', '38', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Eladio Antonio Torres Peña - Privilegio: tecnico', '2026-04-21 08:57:56', '172.27.203.64', 'Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('408', '45', 'CERRAR_TICKET', 'Ticket #CSI2026042140573 cerrado como: Cerrado Exitosamente - Solución: se ingreso el equipo a magistratura', '2026-04-21 09:11:59', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:147.0) Gecko/20100101 Firefox/147.0', NULL, '241');
INSERT INTO `Logs` VALUES ('409', '7', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Pablo Zambrano - Privilegio: admin', '2026-04-21 09:48:09', '172.27.195.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('410', '35', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Cesar Herney Chourio Ruiz - Privilegio: tecnico', '2026-04-21 09:52:34', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('411', '51', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Rafael Augusto Molina Ruiz - Privilegio: tecnico', '2026-04-21 09:53:16', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('412', '91', 'LOGIN', 'Inicio de sesión exitoso - Usuario: GAVIDIA RIVAS, NEIDA - Privilegio: usuario', '2026-04-21 09:59:42', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; rv:146.0) Gecko/20100101 Firefox/146.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('413', '67', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Hermelinda C. Leon Avendaño - Privilegio: bienes', '2026-04-21 10:45:26', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('414', '34', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Milana Maria Medina Ramirez - Privilegio: admin', '2026-04-21 10:54:22', '172.27.160.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', NULL, NULL);
INSERT INTO `Logs` VALUES ('415', '53', 'CERRAR_TICKET', 'Ticket #CSI2026042044520 cerrado como: Cerrado Exitosamente - Solución: SE INSTALA HERRAMIENTA ÁBBYY SCANER, SE ACTUALIZA DRIVERS HP 52000', '2026-04-21 11:03:39', '172.27.160.160', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/113.0', NULL, '235');
INSERT INTO `Logs` VALUES ('416', '38', 'LOGIN', 'Inicio de sesión exitoso - Usuario: Eladio Antonio Torres Peña - Privilegio: tecnico', '2026-04-21 11:05:15', '172.27.203.64', 'Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0', NULL, NULL);

-- --------------------------------------------------
-- Estructura de la tabla: Servicios
-- --------------------------------------------------
DROP TABLE IF EXISTS `Servicios`;
CREATE TABLE `Servicios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `area_id` int(11) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `area_servicio` (`area_id`,`nombre`),
  KEY `idx_servicios_area` (`area_id`),
  KEY `idx_area_activo` (`area_id`,`activo`),
  CONSTRAINT `Servicios_ibfk_1` FOREIGN KEY (`area_id`) REFERENCES `AreasSoporte` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Datos de la tabla: Servicios
INSERT INTO `Servicios` VALUES ('1', '1', 'Servicio de Videoconferencia', 'Configuración y soporte para videoconferencias', '1');
INSERT INTO `Servicios` VALUES ('2', '1', 'Apoyo informático en eventos', 'Soporte técnico durante eventos especiales', '1');
INSERT INTO `Servicios` VALUES ('3', '1', 'Apoyo en servicios audiovisuales', 'Asistencia con equipos audiovisuales', '1');
INSERT INTO `Servicios` VALUES ('4', '1', 'Otros requerimientos', 'Otros servicios de apoyo logístico', '1');
INSERT INTO `Servicios` VALUES ('5', '2', 'Configuración, Verificación y Ejecución de respaldo en servidor', 'Gestión de backups de servidores', '1');
INSERT INTO `Servicios` VALUES ('6', '2', 'Diagnosticar, Resolver, Notificar falla o error en servidor', 'Diagnóstico y solución de problemas en servidores', '1');
INSERT INTO `Servicios` VALUES ('7', '2', 'Instalación de software en servidores', 'Instalación de aplicaciones en servidores', '1');
INSERT INTO `Servicios` VALUES ('8', '2', 'Actualización . Mantenimiento de Directorio Activo', 'Mantenimiento de Active Directory', '1');
INSERT INTO `Servicios` VALUES ('9', '2', 'Mantenimiento y Actualización de Servidores', 'Mantenimiento general de servidores', '1');
INSERT INTO `Servicios` VALUES ('10', '2', 'Otro requerimiento asociado a servidores', 'Otros servicios relacionados con servidores', '1');
INSERT INTO `Servicios` VALUES ('11', '3', 'Ejecución de Actividades de la ODI', 'Actividades de la Oficina de Desarrollo Informático', '1');
INSERT INTO `Servicios` VALUES ('12', '3', 'Elaborar Informes Técnicos', 'Elaboración de informes técnicos', '1');
INSERT INTO `Servicios` VALUES ('13', '3', 'Generar reportes de Gestión', 'Generación de reportes de gestión', '1');
INSERT INTO `Servicios` VALUES ('14', '3', 'Proyectos Regionales', 'Soporte a proyectos regionales', '1');
INSERT INTO `Servicios` VALUES ('15', '4', 'Configuración de central telefónica', 'Configuración de PBX y centrales telefónicas', '1');
INSERT INTO `Servicios` VALUES ('16', '4', 'Instalación de cableado telefónico', 'Instalación de infraestructura telefónica', '1');
INSERT INTO `Servicios` VALUES ('17', '4', 'Instalación nueva extensión', 'Instalación de nuevas extensiones telefónicas', '1');
INSERT INTO `Servicios` VALUES ('18', '4', 'Reubicación de teléfono', 'Reubicación de equipos telefónicos', '1');
INSERT INTO `Servicios` VALUES ('19', '4', 'Otro requerimiento asociado a telefónia', 'Otros servicios de telefonía', '1');
INSERT INTO `Servicios` VALUES ('20', '5', 'Instalación / Configuración de ambiente de red', 'Configuración de ambientes de red', '1');
INSERT INTO `Servicios` VALUES ('21', '5', 'Reubicación punto de red', 'Reubicación de puntos de red', '1');
INSERT INTO `Servicios` VALUES ('22', '5', 'Requerimientos vinculados la cámara de seguridad', 'Soporte a cámaras de seguridad', '1');
INSERT INTO `Servicios` VALUES ('23', '5', 'Swicht, Router, Patch panel', 'Mantenimiento de equipos de red', '1');
INSERT INTO `Servicios` VALUES ('24', '5', 'Otros requerimientos vinculados a Red', 'Otros servicios de red', '1');
INSERT INTO `Servicios` VALUES ('25', '6', 'Sistemas administrativos y Judiciales (Instalación, Configuración)', 'Instalación de sistemas administrativos y judiciales', '1');
INSERT INTO `Servicios` VALUES ('26', '6', 'Automatización de procesos administrativos internos', 'Automatización de procesos', '1');
INSERT INTO `Servicios` VALUES ('27', '6', 'Sistema JURIS2000 (Acceso, Instalación y configuración)', 'Soporte al sistema JURIS2000', '1');
INSERT INTO `Servicios` VALUES ('28', '6', 'Soporte Control de Asistencia-Gisa', 'Soporte al sistema de control de asistencia', '1');
INSERT INTO `Servicios` VALUES ('29', '6', 'Sistema Independencia (Acceso, Instalación y configuración)', 'Soporte al sistema Independencia', '1');
INSERT INTO `Servicios` VALUES ('30', '6', 'Instalación de aplicaciones informáticas', 'Instalación de aplicaciones generales', '1');
INSERT INTO `Servicios` VALUES ('31', '6', 'Otros requerimientos vinculados a Sistemas', 'Otros servicios de sistemas', '1');
INSERT INTO `Servicios` VALUES ('32', '7', 'Antivirus (Instalación, Actualización, Ejecutar Análisis)', 'Gestión de antivirus', '1');
INSERT INTO `Servicios` VALUES ('33', '7', 'Adiestramiento en software de ofimática', 'Capacitación en ofimática', '1');
INSERT INTO `Servicios` VALUES ('34', '7', 'Configuración acceso Internet', 'Configuración de acceso a Internet', '1');
INSERT INTO `Servicios` VALUES ('35', '7', 'Configuración de carpeta compartida en la RED', 'Configuración de carpetas compartidas', '1');
INSERT INTO `Servicios` VALUES ('36', '7', 'Instalación y/o Configuración de impresora', 'Configuración de impresoras', '1');
INSERT INTO `Servicios` VALUES ('37', '7', 'Instalación, Diagnostico y/o reparación de computador (hardware, software)', 'Reparación de computadoras', '1');
INSERT INTO `Servicios` VALUES ('38', '7', 'Restauración del perfil de usuario', 'Restauración de perfiles de usuario', '1');
INSERT INTO `Servicios` VALUES ('39', '7', 'Cuentas de usuarios MAGISTRATURA (Crear, Deshabilitar, Desbloquear)', 'Gestión de cuentas de magistratura', '1');
INSERT INTO `Servicios` VALUES ('40', '7', 'Cuentas de EDITORES TSJ (Solicitud, Deshabilitar, Desbloquear)', 'Gestión de cuentas de editores', '1');
INSERT INTO `Servicios` VALUES ('41', '7', 'Movimientos de equipos informáticos (reubicación, asignación, reparación, desincorporación)', 'Gestión de equipos informáticos', '1');
INSERT INTO `Servicios` VALUES ('42', '7', 'Préstamo de activos informático', 'Préstamo de equipos', '1');
INSERT INTO `Servicios` VALUES ('43', '7', 'Realizar respaldo', 'Realización de backups', '1');
INSERT INTO `Servicios` VALUES ('44', '7', 'Recuperación de información', 'Recuperación de datos', '1');
INSERT INTO `Servicios` VALUES ('45', '7', 'Otro requerimiento asociado a Soporte', 'Otros servicios de soporte', '1');
INSERT INTO `Servicios` VALUES ('46', '8', 'Diagnostico/reemplazo cartuchos de impresión', 'Gestión de cartuchos de impresión', '1');
INSERT INTO `Servicios` VALUES ('47', '8', 'Diagnostico/reemplazo toner de impresión', 'Gestión de toners', '1');
INSERT INTO `Servicios` VALUES ('48', '8', 'Mantenimiento de Impresora', 'Mantenimiento de impresoras', '1');
INSERT INTO `Servicios` VALUES ('49', '8', 'Mantenimiento de Fotocopiadora', 'Mantenimiento de fotocopiadoras', '1');
INSERT INTO `Servicios` VALUES ('50', '8', 'Reparación de Impresora', 'Reparación de impresoras', '1');
INSERT INTO `Servicios` VALUES ('51', '8', 'Reparación de Fotocopiadora', 'Reparación de fotocopiadoras', '1');
INSERT INTO `Servicios` VALUES ('52', '8', 'Reparación de Equipos Electro Mecánicos', 'Reparación de equipos electromecánicos', '1');
INSERT INTO `Servicios` VALUES ('53', '8', 'Atascos de Papel', 'Resolución de atascos de papel', '1');
INSERT INTO `Servicios` VALUES ('54', '8', 'Otros Requerimientos', 'Otros servicios de taller', '1');
INSERT INTO `Servicios` VALUES ('55', '8', 'Recarga de Cartuchos de Impresora', '', '1');
INSERT INTO `Servicios` VALUES ('56', '9', 'Incidencias', 'Incidencias en recorrido', '1');

-- --------------------------------------------------
-- Estructura de la tabla: TicketAdjuntos
-- --------------------------------------------------
DROP TABLE IF EXISTS `TicketAdjuntos`;
CREATE TABLE `TicketAdjuntos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `nombre_archivo` varchar(255) NOT NULL,
  `tipo_archivo` varchar(100) DEFAULT NULL,
  `tamano_bytes` int(11) DEFAULT NULL,
  `ruta_archivo` varchar(500) NOT NULL,
  `fecha_subida` timestamp NOT NULL DEFAULT current_timestamp(),
  `subido_por` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `subido_por` (`subido_por`),
  CONSTRAINT `TicketAdjuntos_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `Tickets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `TicketAdjuntos_ibfk_2` FOREIGN KEY (`subido_por`) REFERENCES `Usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Datos de la tabla: TicketAdjuntos
INSERT INTO `TicketAdjuntos` VALUES ('5', '57', 'informe 117 JSP  (copia).docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '535862', 'tickets/2026/03/69c432d6daced_57_informe_117_JSP___copia_.docx', '2026-03-25 15:09:10', '53');
INSERT INTO `TicketAdjuntos` VALUES ('6', '106', 'INFORME TECNICO MINI PC TRB 3EO MUN 070426.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '914462', 'tickets/2026/04/69d566eece2ac_106_INFORME_TECNICO_MINI_PC_TRB_3EO_MUN_070426.docx', '2026-04-07 16:19:58', '38');
INSERT INTO `TicketAdjuntos` VALUES ('7', '136', 'IMG_20260410_091619608.jpg', 'image/jpeg', '3523815', 'tickets/2026/04/69d9104fe11cb_136_IMG_20260410_091619608.jpg', '2026-04-10 10:59:27', '94');
INSERT INTO `TicketAdjuntos` VALUES ('8', '183', '1776203125989.jpg', 'image/jpeg', '3110245', 'tickets/2026/04/69deb6aa33788_183_1776203125989.jpg', '2026-04-14 17:50:34', '46');
INSERT INTO `TicketAdjuntos` VALUES ('9', '183', '1776203126020.jpg', 'image/jpeg', '3042723', 'tickets/2026/04/69deb6aa347b5_183_1776203126020.jpg', '2026-04-14 17:50:34', '46');
INSERT INTO `TicketAdjuntos` VALUES ('10', '183', '1776202609621.jpg', 'image/jpeg', '3261953', 'tickets/2026/04/69deb6aa355dc_183_1776202609621.jpg', '2026-04-14 17:50:34', '46');
INSERT INTO `TicketAdjuntos` VALUES ('11', '184', '1776203126020.jpg', 'image/jpeg', '3042723', 'tickets/2026/04/69deb7f168afb_184_1776203126020.jpg', '2026-04-14 17:56:01', '46');
INSERT INTO `TicketAdjuntos` VALUES ('12', '184', '1776203125948.jpg', 'image/jpeg', '2414214', 'tickets/2026/04/69deb7f169950_184_1776203125948.jpg', '2026-04-14 17:56:01', '46');
INSERT INTO `TicketAdjuntos` VALUES ('13', '184', '1776202806532.jpg', 'image/jpeg', '3849923', 'tickets/2026/04/69deb7f16ba1c_184_1776202806532.jpg', '2026-04-14 17:56:01', '46');
INSERT INTO `TicketAdjuntos` VALUES ('14', '185', 'LABORAL (3).jpg', 'image/jpeg', '2782998', 'tickets/2026/04/69debb81cd071_185_LABORAL__3_.jpg', '2026-04-14 18:11:13', '46');
INSERT INTO `TicketAdjuntos` VALUES ('15', '185', 'LABORAL (2).jpg', 'image/jpeg', '3526530', 'tickets/2026/04/69debb81ce01f_185_LABORAL__2_.jpg', '2026-04-14 18:11:13', '46');
INSERT INTO `TicketAdjuntos` VALUES ('16', '185', 'LABORAL.jpg', 'image/jpeg', '3083892', 'tickets/2026/04/69debb81cede8_185_LABORAL.jpg', '2026-04-14 18:11:13', '46');
INSERT INTO `TicketAdjuntos` VALUES ('17', '186', 'CONTROL 3 (2).jpg', 'image/jpeg', '3011320', 'tickets/2026/04/69debbefc5d2b_186_CONTROL_3__2_.jpg', '2026-04-14 18:13:03', '46');
INSERT INTO `TicketAdjuntos` VALUES ('18', '186', 'CONTROL 3.jpg', 'image/jpeg', '2377414', 'tickets/2026/04/69debbefc6c88_186_CONTROL_3.jpg', '2026-04-14 18:13:03', '46');
INSERT INTO `TicketAdjuntos` VALUES ('19', '187', 'TPM 1.jpg', 'image/jpeg', '2989086', 'tickets/2026/04/69debc51aaa4b_187_TPM_1.jpg', '2026-04-14 18:14:41', '46');
INSERT INTO `TicketAdjuntos` VALUES ('20', '188', 'JUICIO 3.jpg', 'image/jpeg', '3111860', 'tickets/2026/04/69debccdc989e_188_JUICIO_3.jpg', '2026-04-14 18:16:45', '46');
INSERT INTO `TicketAdjuntos` VALUES ('21', '188', 'JUICIO 3 (2).jpg', 'image/jpeg', '2836810', 'tickets/2026/04/69debccdcd421_188_JUICIO_3__2_.jpg', '2026-04-14 18:16:45', '46');
INSERT INTO `TicketAdjuntos` VALUES ('22', '188', 'JUICIO 3 (3).jpg', 'image/jpeg', '2724378', 'tickets/2026/04/69debccdce5e6_188_JUICIO_3__3_.jpg', '2026-04-14 18:16:45', '46');
INSERT INTO `TicketAdjuntos` VALUES ('23', '192', 'CAPTURE.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '89518', 'tickets/2026/04/69df8c91b979e_192_CAPTURE.docx', '2026-04-15 09:03:13', '82');

-- --------------------------------------------------
-- Estructura de la tabla: TicketEvaluaciones
-- --------------------------------------------------
DROP TABLE IF EXISTS `TicketEvaluaciones`;
CREATE TABLE `TicketEvaluaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `calificacion` tinyint(4) NOT NULL,
  `comentario` text DEFAULT NULL,
  `fecha_evaluacion` datetime NOT NULL DEFAULT current_timestamp(),
  `tecnico_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_evaluacion` (`ticket_id`,`usuario_id`),
  KEY `idx_tecnico` (`tecnico_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Datos de la tabla: TicketEvaluaciones
INSERT INTO `TicketEvaluaciones` VALUES ('1', '104', '53', '5', 'PRUEBA DE EVALUACION DE SERVICIO', '2026-04-08 14:46:20', '53');
INSERT INTO `TicketEvaluaciones` VALUES ('2', '125', '7', '5', 'quedo  operativo', '2026-04-09 12:40:22', '80');
INSERT INTO `TicketEvaluaciones` VALUES ('3', '219', '94', '5', '', '2026-04-20 14:11:28', '37');
INSERT INTO `TicketEvaluaciones` VALUES ('4', '169', '94', '5', '', '2026-04-20 14:11:53', '37');
INSERT INTO `TicketEvaluaciones` VALUES ('5', '157', '94', '5', '', '2026-04-20 14:12:40', '50');
INSERT INTO `TicketEvaluaciones` VALUES ('6', '156', '94', '5', '', '2026-04-20 14:13:11', '50');
INSERT INTO `TicketEvaluaciones` VALUES ('7', '155', '94', '5', '', '2026-04-20 14:13:25', '50');
INSERT INTO `TicketEvaluaciones` VALUES ('8', '154', '94', '5', '', '2026-04-20 14:13:54', '50');
INSERT INTO `TicketEvaluaciones` VALUES ('9', '144', '94', '5', '', '2026-04-20 14:14:46', '95');
INSERT INTO `TicketEvaluaciones` VALUES ('10', '143', '94', '5', '', '2026-04-20 14:19:04', '50');
INSERT INTO `TicketEvaluaciones` VALUES ('11', '136', '94', '5', '', '2026-04-20 14:19:30', '38');
INSERT INTO `TicketEvaluaciones` VALUES ('12', '127', '94', '5', '', '2026-04-20 14:20:23', '50');
INSERT INTO `TicketEvaluaciones` VALUES ('13', '126', '94', '5', '', '2026-04-20 14:20:49', '50');
INSERT INTO `TicketEvaluaciones` VALUES ('14', '122', '94', '5', '', '2026-04-20 14:21:10', '80');
INSERT INTO `TicketEvaluaciones` VALUES ('15', '121', '94', '5', '', '2026-04-20 14:21:44', '80');
INSERT INTO `TicketEvaluaciones` VALUES ('16', '118', '94', '5', '', '2026-04-20 14:22:41', '37');
INSERT INTO `TicketEvaluaciones` VALUES ('17', '103', '94', '5', '', '2026-04-20 14:23:00', '50');
INSERT INTO `TicketEvaluaciones` VALUES ('18', '91', '94', '5', '', '2026-04-20 14:23:24', '38');
INSERT INTO `TicketEvaluaciones` VALUES ('19', '88', '94', '5', '', '2026-04-20 14:23:42', '50');
INSERT INTO `TicketEvaluaciones` VALUES ('20', '78', '94', '5', '', '2026-04-20 14:23:55', '80');
INSERT INTO `TicketEvaluaciones` VALUES ('21', '71', '94', '5', '', '2026-04-20 14:24:11', '37');

-- --------------------------------------------------
-- Estructura de la tabla: Tickets
-- --------------------------------------------------
DROP TABLE IF EXISTS `Tickets`;
CREATE TABLE `Tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_ticket` varchar(20) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `dependencia_id` int(11) NOT NULL,
  `lugar_area` varchar(150) NOT NULL,
  `area_id` int(11) NOT NULL,
  `servicio_id` int(11) NOT NULL,
  `asunto` varchar(255) NOT NULL,
  `descripcion` text NOT NULL,
  `numero_bien` varchar(15) DEFAULT NULL,
  `serial` varchar(50) DEFAULT NULL,
  `prioridad` enum('baja','media','alta','urgente') DEFAULT 'media',
  `estado` enum('Nuevo','Asignado','En Proceso','Cerrado Exitosamente','Cerrado No Exitoso') DEFAULT 'Nuevo',
  `tecnico_asignado` int(11) DEFAULT NULL,
  `compartido_bienes` tinyint(1) DEFAULT 0,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_cierre` timestamp NULL DEFAULT NULL,
  `solucion` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_ticket` (`numero_ticket`),
  KEY `dependencia_id` (`dependencia_id`),
  KEY `area_id` (`area_id`),
  KEY `servicio_id` (`servicio_id`),
  KEY `idx_tickets_usuario` (`usuario_id`),
  KEY `idx_tickets_estado` (`estado`),
  KEY `idx_tickets_fecha` (`fecha_creacion`),
  KEY `idx_tickets_tecnico` (`tecnico_asignado`),
  CONSTRAINT `Tickets_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  CONSTRAINT `Tickets_ibfk_2` FOREIGN KEY (`dependencia_id`) REFERENCES `Dependencias` (`id`),
  CONSTRAINT `Tickets_ibfk_3` FOREIGN KEY (`area_id`) REFERENCES `AreasSoporte` (`id`),
  CONSTRAINT `Tickets_ibfk_4` FOREIGN KEY (`servicio_id`) REFERENCES `Servicios` (`id`),
  CONSTRAINT `Tickets_ibfk_5` FOREIGN KEY (`tecnico_asignado`) REFERENCES `Usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=247 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Datos de la tabla: Tickets
INSERT INTO `Tickets` VALUES ('28', 'CSI2026021190661', '53', '1', 'Area Bienes Publicos', '7', '35', 'conexion', 'el punto de red no funciona', NULL, NULL, 'media', 'Cerrado Exitosamente', '53', '0', '2026-02-11 11:30:17', '2026-02-11 11:33:55', 'se cambia el patch cord a otro punto de red');
INSERT INTO `Tickets` VALUES ('29', 'CSI2026021218907', '34', '177', 'SALA DE AUDIENCIA', '7', '41', 'CAMBIO DE EQUIPOS', 'EQUIPO DE LA COORIDNACION JUDICIAL A LA SALA DE JUICIO

CONFIGURAR EL PERFIL DEL TECNICO AUDIOVISUAL, CONTEMPLAR RESPALDO DE DATOS Y COLOCAR QUEMADORA', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-02-12 10:17:46', '2026-03-27 15:11:29', 'se creo el perfil');
INSERT INTO `Tickets` VALUES ('30', 'CSI2026021260002', '34', '24', 'OATI MERIDA', '7', '37', 'INSTALACION DE TARJETA DE VIDEO', 'A LOS FINES RECUPERACION DE CABLE VGA PARA SER USADO EN EL AREA DE FASDEM', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-02-12 12:55:04', '2026-03-27 15:10:45', 'sin comentario');
INSERT INTO `Tickets` VALUES ('31', 'CSI2026021259809', '34', '24', 'TELEMATICA', '1', '1', 'VIDEOCONFERENCIA NACIONAL SEGURIDAD-DEM', 'VIDEOCONFERENCIA SEGURIDAD-DEM 
12/2/2026 A LAS 2:PM
PARTICIPANTES 1 PERSONA (ASDRUBAL VELASQUEZ)', NULL, NULL, 'media', 'Cerrado Exitosamente', '7', '0', '2026-02-12 13:50:13', '2026-03-24 11:36:34', 'se  atendio la video conferencia');
INSERT INTO `Tickets` VALUES ('32', 'CSI2026021213516', '34', '177', 'COORDINACION JUDICIAL', '7', '41', 'INSTALACION DE NUEVO EQUIPO', 'INSTALACION DE NUEVO EQUIPO DOTACION 2026. PASE DE RESPALDOS', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-02-12 15:09:47', '2026-03-26 15:48:55', 'Cerrado Exitosamente la  instalacion');
INSERT INTO `Tickets` VALUES ('33', 'CSI2026021236506', '34', '177', 'DESPACHO JUEZ SUPERIOR', '7', '37', 'REPERACION PC SECRETARIA JUEZ SUPERIOR', 'PC VIT SERIAL A000836441', NULL, NULL, 'media', 'Cerrado Exitosamente', '52', '0', '2026-02-12 15:13:05', '2026-04-09 12:48:21', 'Cerrado  con exito');
INSERT INTO `Tickets` VALUES ('35', 'CSI2026022631241', '53', '1', 'Juzgado Superior Primero', '7', '35', 'Carpeta compratida CJCJPIASI', 'no tine la carpeta compartida con el juez', NULL, NULL, 'media', 'Cerrado Exitosamente', '53', '0', '2026-02-26 10:32:24', '2026-02-26 10:39:17', 'instalacion de carpeta compartida CJCJPIASI');
INSERT INTO `Tickets` VALUES ('36', 'CSI2026031132351', '34', '173', 'POOL DE ASISTENTES', '7', '37', 'REPARACION DE CPU', 'NRO BIEN 8656

DIAGNOSTICO REALIZADO POR PERSONAL DE BIENES PUBLICOS. PLAN DE RECUPERACION TECNOLOGICA', NULL, NULL, 'media', 'Cerrado Exitosamente', '53', '0', '2026-03-11 16:07:40', '2026-03-16 09:48:57', 'Se reemplaza la correa SATA');
INSERT INTO `Tickets` VALUES ('38', 'CSI2026031282519', '38', '1', 'sala audiencia', '7', '45', 'Copiado de grabación', 'Copiado de video grabación de teléfono de la ocii a pendriver del tribunal', NULL, NULL, 'baja', 'Cerrado Exitosamente', '38', '0', '2026-03-12 12:11:50', '2026-03-12 12:14:18', 'Procesada la solicitud');
INSERT INTO `Tickets` VALUES ('39', 'CSI2026031281564', '34', '172', 'secretaria', '7', '37', 'PC SE APAGA SOLO', 'PC SE APAGA SOLO 

INFORMACION RECIBIDA POR DIAGNOSTICO REALIZADO EN INVENTARIO REALIZADO POR BIENES PÚBLICOS MORAIMA RANGEL Y MARIA CASTILLO', NULL, NULL, 'media', 'Cerrado Exitosamente', '53', '0', '2026-03-12 12:14:38', '2026-03-13 10:10:54', 'Se realiza soplado interno, se le coloca pasta térmica al procesador, se hace un diagnostico con la herramienta victoria al disco duro encontrándose que los sectores se encuentran en buenas condiciones, se le hace mantenimiento a la memoria ram y se actualiza el antivirus.');
INSERT INTO `Tickets` VALUES ('40', 'CSI2026031258933', '34', '172', 'SECRETARIA', '7', '37', 'PC SE APAGA SOLO', 'PC SE APAGA SOLO

MARCA ARTECK SIN SERIAL 

DIAGNOSTICO REALIZADO EN INVENTARIO DE BINES PUBLICOS MORAIMA RANGEL Y MARIA CASTILLO', NULL, NULL, 'media', 'Cerrado Exitosamente', '53', '0', '2026-03-12 12:20:09', '2026-03-12 13:52:13', 'se sustituyo el cable sata');
INSERT INTO `Tickets` VALUES ('41', 'CSI2026031227599', '34', '202', 'POOL DE ASISTENTES', '7', '39', 'FALLA DE ACCESO PC USUARIO HELLEN ALBARRAN', 'FALLA DE ACCESO PC USUARIO HELEN ALBARRAN', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-03-12 12:22:54', '2026-03-16 11:06:38', 'solucionado');
INSERT INTO `Tickets` VALUES ('42', 'CSI2026031266634', '34', '201', 'POOL DE ASISTENTES', '7', '37', 'PC NO ENCIENDE Y FALLA EN SISTEMA OPERATIVO', 'PC NO ENCIENDE Y FALLA EN SISTEMA OPERATIVO', NULL, NULL, 'media', 'Cerrado Exitosamente', '45', '0', '2026-03-12 12:33:54', '2026-04-07 08:54:00', 'se instalo nuevamente sistema operativo');
INSERT INTO `Tickets` VALUES ('43', 'CSI2026031211404', '34', '163', 'POOL DE ASISTENTES', '7', '41', 'EQUIPO NO ENCIENDE', 'EQUIPO NO ENCIENDE', NULL, NULL, 'media', 'Cerrado Exitosamente', '45', '0', '2026-03-12 13:13:04', '2026-04-07 08:52:11', 'se reparo fuente de poder');
INSERT INTO `Tickets` VALUES ('45', 'CSI2026031231549', '34', '24', 'COMEDOR', '8', '52', 'REPARACION DE MICROHONDAS', 'REPARACION DE MICROHONDAS AREA DE COMEDOR', NULL, NULL, 'media', 'Cerrado Exitosamente', '86', '0', '2026-03-12 13:35:47', '2026-03-27 15:16:33', 'quedo  Operativo esta  en el comedor');
INSERT INTO `Tickets` VALUES ('46', 'CSI2026031211566', '34', '24', 'BIENES PUBLICOS', '6', '31', 'SISTEMA INTRADAR ACTUALIZACION', 'Limitar la modificación del campo Número de Bien (NRO de bien) dentro del sistema Intradar, asegurando que solo los usuarios con el rol de Coordinador de Área tengan permisos de escritura sobre este dato.


Detalles de la modificación:

Validación de Rol: El sistema debe verificar el perfil del usuario activo.

Si el usuario NO es Coordinador: El campo "NRO de bien" debe aparecer en modo "Solo lectura" NO PUEDE SER MODIFICADO.

Si el usuario ES Coordinador: El campo debe estar habilitado para edición.

El resto de  campos asociados al BIEN  puede seguir siendo editable por los perfiles (BIENES TRANSCRIPTOR), la restricción aplica exclusivamente al número de identificación del bien.', NULL, NULL, 'media', 'Cerrado Exitosamente', '44', '0', '2026-03-12 13:51:49', '2026-04-07 13:43:39', 'RESUELTO EL DIA 06/04/2026 A LAS 7.30 AM');
INSERT INTO `Tickets` VALUES ('48', 'CSI2026031329530', '34', '24', 'CJP MERIDA SERVIDOR', '1', '4', 'ELABORACION DE INFORME', 'Sirva la presente para saludar además de solicitar se sirvan a generar:

Informe técnico de Adecuación Tecnológica para la implantación sistema judicial JURIS2000 en:

- Circuito de Violencia contra la Mujer   extension El Vigia
- Circuito de Violencia contra la Mujer sede Merida


 El objetivo es certificar que ambos espacios cuenten con las condiciones de infraestructura, climatización y conectividad necesarias para el despliegue del sistema judicial.

Considerar:

1. Diagnóstico de la infraestructura tecnológica área se servidores (equipamiento  especificaciones técnicas y adecuacion)
2. Diagnóstico de la Infraestructura tecnológica área PC clientes (especificaciones técnicas de los clientes 
3. Antecedentes 
4. Memoria fotográfica de los espacios
5. Conclusiones y recomendaciones 

Esto debe ser remitido a la coordinación a los fines de revisar y enviar a nivel central a través de los canales regulares 

Responsable de dichos informes 

CJP Vigía: Victor Cedeño , Marta Laguado

CJP Mérida: Norbedy Rojas , Cesar Chourio', NULL, NULL, 'alta', 'Cerrado Exitosamente', '35', '0', '2026-03-13 13:42:49', '2026-04-08 10:44:16', 'Informe entregado a Ing. Milana Medina');
INSERT INTO `Tickets` VALUES ('49', 'CSI2026031651107', '38', '1', 'alguacilazgo', '7', '45', 'No enciende pc', 'Computador encendido pero no da video', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-03-16 11:05:02', '2026-03-16 11:07:01', 'solucionado, monitor bloqueado por bajon de luz');
INSERT INTO `Tickets` VALUES ('51', 'CSI2026032472246', '84', '162', 'en  despacho  no funciona  la  impresora', '7', '36', 'No esta  configurada  la  Impresora', 'En la  MAquina  de la entrada No esta  configurada  la  Impresora', NULL, NULL, 'media', 'Cerrado Exitosamente', '85', '0', '2026-03-24 10:22:48', '2026-03-24 10:47:19', 'EL usuario puso  la  dependencia  mal');
INSERT INTO `Tickets` VALUES ('55', 'CSI2026032527982', '53', '24', 'TRIBUNAL CUARTO DE MUNICIPIO ORDINARIO Y EJECUTOR DE MEDIDAS DE LOS MUNICIPIOS LIBERTADOR Y SANTOS MARQUINA DE LA CIRCUNSCRIPCION JUDICIAL', '7', '37', 'equipo cpu no enciende', 'equipo CPU N°BP 006183, no enciende', NULL, NULL, 'media', 'Cerrado Exitosamente', '53', '0', '2026-03-25 11:06:08', '2026-03-25 11:44:26', 'Mantenimiento Físico Interno: Se realizó limpieza profunda mediante soplado interno para extraer el polvo y residuos acumulados en los componentes (ventiladores, disipadores, placa base, etc.). Mantenimiento de Fuente de Poder,Mantenimiento del Sistema de Refrigeración Se aplicó pasta térmica en el procesador.

Mantenimiento de Software:

   · Se realizó la reinstalación completa del sistema operativo.

   · Se instalaron aplicaciones requeridas y la suite ofimática.

   · Se actualizó el software antivirus a su última versión disponible.');
INSERT INTO `Tickets` VALUES ('56', 'CSI2026032588718', '53', '170', 'pool de abogados asistentes', '8', '54', 'Monitor', 'monitor no da imagen', NULL, NULL, 'media', 'Cerrado Exitosamente', '53', '0', '2026-03-25 11:52:41', '2026-04-10 10:58:40', 'EL FUNCIONARIO RAFAEL MOLINA  DEL TALLER OATI, ME INDICA QUE EL MONITOR TIENE PANTALLA PARTIDA Y PLACA DEFECTUOSA POR TAL MOTIVO SE SUGIERE LA DESINCORPORACION DEL MISMO');
INSERT INTO `Tickets` VALUES ('57', 'CSI2026032532170', '53', '170', 'pool de asistente', '7', '45', 'sin magistratura ni carpetas comparidas', 'el equipo es un bien personal segun el CBP-277.', NULL, NULL, 'media', 'Cerrado Exitosamente', '53', '0', '2026-03-25 15:07:01', '2026-03-25 15:09:10', 'se ingresa a la red magistratura y se le coloca el acceso a las carpetas compartidas correspondientes al Juzgado.');
INSERT INTO `Tickets` VALUES ('58', 'CSI2026032668445', '84', '24', 'Servicios  Judiciales', '7', '39', 'Raquel Solicita  Cuante MAgistratura', 'EL sistema  esta  dando error al entrar', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-03-26 15:41:14', '2026-03-27 12:48:58', 'REINICIO DE CABLE');
INSERT INTO `Tickets` VALUES ('59', 'CSI2026032681056', '38', '24', 'nomina', '7', '37', 'Actualizacion de sistema operativo', 'equipo de Anyi Castillo', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-03-26 15:46:32', '2026-03-27 16:21:06', 'Proceso realizado exitosamente');
INSERT INTO `Tickets` VALUES ('60', 'CSI2026032632643', '47', '175', 'Almacen', '8', '54', 'Plan de  recuperacion de  Bienes', 'Se  revizaron  varios   equipos  electronicos', NULL, NULL, 'media', 'Cerrado Exitosamente', '47', '0', '2026-03-26 16:07:32', '2026-03-27 15:18:46', 'se  revisaron varios  monitores y  todos  tienen la pantalla  dañada');
INSERT INTO `Tickets` VALUES ('61', 'CSI2026032618128', '38', '24', 'Nomina', '7', '37', 'Actualizacion de sistema operativo', 'Equipo de computacion de Carlin Lozada', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-03-26 16:15:52', '2026-03-26 16:18:11', 'Actualización realizada exitosamete');
INSERT INTO `Tickets` VALUES ('62', 'CSI2026032662075', '38', '24', 'Nomina', '7', '37', 'Actualizacion de sistema operativo', 'Equipo de computacion de Liliana Duran', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-03-26 16:16:23', '2026-03-26 16:17:23', 'Actualizacion realizada exitosamete');
INSERT INTO `Tickets` VALUES ('63', 'CSI2026032662653', '38', '24', 'Fasdem', '7', '37', 'Actualizacion de sistema operativo', 'Actualización requerida al equipo de computacion de Marianela Balza', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-03-26 16:19:33', '2026-03-26 16:19:52', 'Actualizacion realizada exitosamete');
INSERT INTO `Tickets` VALUES ('66', 'CSI2026032785740', '37', '163', 'pool de secretarios', '7', '37', 'falla en conexion de red y sistema', 'presentaba falla en la conexion de red y lentitud en el sistema operativo.', NULL, NULL, 'media', 'Cerrado Exitosamente', '37', '0', '2026-03-27 10:41:50', '2026-03-27 14:54:41', 'se instalo sistema operativo con todas sus herramientas.');
INSERT INTO `Tickets` VALUES ('67', 'CSI2026032733168', '37', '177', 'Coordinación Judicial', '7', '37', 'Respaldo de infomación', 'Revisión del equipo y respaldo', NULL, NULL, 'media', 'Cerrado No Exitoso', '37', '0', '2026-03-27 10:46:32', '2026-03-27 11:16:46', 'se reviso el equipo el cual presenta sectores dañados en el disco duro, por tal motivo no se realizo el respaldo y se recomienda al tribunal el cambio de dicho disco duro para el buen funcionamiento del equipo (CPU)');
INSERT INTO `Tickets` VALUES ('68', 'CSI2026032748837', '34', '183', 'Pool de asistentes', '6', '28', 'No genera reporte Gisa', 'No genere reporte Gisa. El usuario es JOSE LUIS MARQUEZ', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-03-27 10:56:46', '2026-03-27 12:48:17', 'EL USUARIO QUE ESTABA CONSULTANDO ESTABA BLOQUEADO');
INSERT INTO `Tickets` VALUES ('69', 'CSI2026032798780', '37', '163', 'despacho del juez', '7', '37', 'falla al reconocer el ssd', 'sistema operativo no iniciaba por falla al reconocer la ssd.', NULL, NULL, 'media', 'Cerrado Exitosamente', '37', '0', '2026-03-27 11:30:48', '2026-03-27 11:32:27', 'se acudio al deswpacho para revision de la falla, la cual fue resuelta exitosamente');
INSERT INTO `Tickets` VALUES ('71', 'CSI2026032724801', '94', '177', 'Pool de Superior', '7', '37', 'No enciende el equipo informático', 'No enciende la computadora', NULL, NULL, 'media', 'Cerrado Exitosamente', '37', '0', '2026-03-27 12:22:50', '2026-03-27 15:46:32', 'trabajo éxito');
INSERT INTO `Tickets` VALUES ('74', 'CSI2026032728368', '92', '205', 'Pool de  asistentes', '7', '37', 'NO prende la  maquima de Lisbeth', 'Despues  que  fallo la luz  no prendio la pc', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-03-27 12:26:40', '2026-03-27 12:47:01', 'SIN COMENTARIOS');
INSERT INTO `Tickets` VALUES ('75', 'CSI2026032775197', '91', '205', 'Pool de Asistente', '8', '52', 'Regulador', 'Regulador ubicado en el area del Pool de Asistentes, presenta problemas (no enciende). No de Bien 8648, color negro.', NULL, NULL, 'media', 'Cerrado Exitosamente', '80', '0', '2026-03-27 12:38:32', '2026-03-27 15:15:15', 'Se  entrego,  se le  hizo mantenimnto y quedo  funcionando  bien');
INSERT INTO `Tickets` VALUES ('76', 'CSI2026032718485', '38', '24', 'sala telematica', '1', '2', 'aTENCION Y APOYO A INSTALACION DE EQUIPOS DEL SENIAT', 'aTENCION Y APOYO A INSTALACION DE EQUIPOS DEL SENIAT PARA PROCESO DE IMPUESTOS SOBRE LA RENTA', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-03-27 16:22:16', '2026-03-27 16:22:42', 'ATENCION REALIZADA');
INSERT INTO `Tickets` VALUES ('77', 'CSI2026032795057', '38', '205', 'JUEZ DE JUICIO', '7', '45', 'ASESORIA TECNICA A LA JUEZ', 'ASESORIA TECNICA A LA JUEZ CON RESPECTOA A EQUIPO DE COMPUTACION PERSONAL', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-03-27 16:24:04', '2026-03-27 16:24:17', 'ATENCION EFECTIVA');
INSERT INTO `Tickets` VALUES ('78', 'CSI2026040673232', '94', '177', 'Pool de Secretarios', '8', '52', 'Regulador de Voltaje defectuoso', 'El regulador de voltaje de la computadora asignada a la Coordinadora Judicial, constantemente hace clicks y se desconoce la causa, si se trata de fluctuación de voltage o algún componente interno que esté defectuoso. Importante revisar porque pone en riesgo el equipo que se supone debe proteger', NULL, NULL, 'media', 'Cerrado Exitosamente', '80', '0', '2026-04-06 09:06:22', '2026-04-08 09:26:37', 'AL  asistir el regulador  estaba  funcionando.  no se  reslizo nada');
INSERT INTO `Tickets` VALUES ('79', 'CSI2026040615710', '37', '205', 'pool de secretarios', '7', '37', 'revision de nueva placa madre', 'instalacion de nueva placa madre.', NULL, NULL, 'media', 'Cerrado Exitosamente', '37', '0', '2026-04-06 09:40:41', '2026-04-06 10:07:33', 'se reviso la tarjeta madre , se instalo sistema operativo y sus herramientas de trabajo');
INSERT INTO `Tickets` VALUES ('80', 'CSI2026040634613', '91', '205', 'ARCHIVO DEL CIRCUITO', '8', '54', 'Revisión CPU', 'REVISIÓN DE CPU, UBICADO EN EL ARCHIVO DE ESTE CIRCUITO JUDICIAL DE PROTECCIÓN, SEDE MÉRIDA, NO. BIEN 14, MARCA LENOVO. MODELO 9645. PRESENTA FALLAS NO ARRANCA EL SISTEMA OPERATIVO.', NULL, NULL, 'media', 'Cerrado No Exitoso', '37', '0', '2026-04-06 10:10:18', '2026-04-06 15:22:22', 'se recomienda cambiar el disco duro, ya que el del equipo se encuentra dañado.');
INSERT INTO `Tickets` VALUES ('81', 'CSI2026040646563', '50', '24', 'cesta tickets', '7', '45', 'reconfiguracion de ghisa', 'tenia problemas para entrar al ghisa', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-06 10:10:54', '2026-04-06 10:12:10', 'se reconfiguro el ghisa');
INSERT INTO `Tickets` VALUES ('82', 'CSI2026040659506', '53', '37', 'SECRETARIA', '7', '45', 'IMPRESORA', 'INSTALACION DE IMPRESORA EN EQUIPO DE COMPUTACION DE SECRETARIA', NULL, NULL, 'media', 'Cerrado Exitosamente', '53', '0', '2026-04-06 12:00:51', '2026-04-06 12:04:11', 'SE INSTALA ACCESO A LA IMPRESORA QUE ESTA EN EL DESPACHO DEL JUEZ');
INSERT INTO `Tickets` VALUES ('83', 'CSI2026040698981', '53', '37', 'pool de asistente', '7', '45', 'INSTALACION IMPRESORA Y PDF', 'NO TIENEN ACCESO A LA IMPRESORA QUE SE ENCUENTRA EN EL DESPACHO DEL JUEZ', NULL, NULL, 'media', 'Cerrado Exitosamente', '53', '0', '2026-04-06 12:06:13', '2026-04-06 12:15:28', 'se instala acceso a impresora del despacho y de instala la herramienta AdbeRdr910_es_ES para solucionar el PDF');
INSERT INTO `Tickets` VALUES ('85', 'CSI2026040690951', '53', '171', 'pool de abogados asistentes', '7', '36', 'IMPRESORA', 'configuracion de impresora', NULL, NULL, 'media', 'Cerrado Exitosamente', '53', '0', '2026-04-06 12:36:28', '2026-04-06 12:37:58', 'se configuro impresora con el IP 172.27.195.46');
INSERT INTO `Tickets` VALUES ('86', 'CSI2026040664873', '53', '171', 'pool de asistente', '7', '45', 'HORA Y FECHA', 'DESCONFIGURADO LA FECHA Y LA HORA', NULL, NULL, 'media', 'Cerrado Exitosamente', '53', '0', '2026-04-06 12:39:25', '2026-04-06 12:40:23', 'SE CONFIGURA Y ACTUALIZA LA HORA Y FECHA');
INSERT INTO `Tickets` VALUES ('87', 'CSI2026040676371', '53', '200', 'pool de asistente', '7', '44', 'DOCUMENTOS', 'NO DESCARGA DOCUMENTOS', NULL, NULL, 'media', 'Cerrado Exitosamente', '53', '0', '2026-04-06 12:42:31', '2026-04-06 12:44:04', 'SE REINSTALA EL EXPLORADOR MOZILLA FIREFOX');
INSERT INTO `Tickets` VALUES ('88', 'CSI2026040691065', '94', '177', 'Pool de Superior', '7', '35', 'Acceso a la carpeta de técnico audiovisual', 'El abogado relator no puede acceder a la carpeta de técnico audiovisual para desgrabar una Audiencia de Superior. Y ya que la referida carpeta tiene acceso restringido, se requiere una configuración especializada.', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-06 13:00:58', '2026-04-07 15:58:26', 'se creo un acceso directo a la carpeta');
INSERT INTO `Tickets` VALUES ('89', 'CSI2026040687255', '53', '1', 'pool de asistente', '7', '45', 'editor de sentencia', 'no hay acceso al editor de sentencias', NULL, NULL, 'media', 'Cerrado Exitosamente', '53', '0', '2026-04-06 14:32:28', '2026-04-06 14:33:54', 'se instala el acceso al editor de sentencia');
INSERT INTO `Tickets` VALUES ('90', 'CSI2026040662463', '50', '24', 'primer piso agrario', '7', '45', 'se apaga el pc de repende', 'usuario describe que el pc se apaga, cambie los enchufe para probar si eran ellos hay que hacerle seguimiento', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-06 16:26:18', '2026-04-07 15:59:41', 'cambio de enchufes');
INSERT INTO `Tickets` VALUES ('91', 'CSI2026040795306', '94', '177', 'Coordinacion Judicial', '8', '53', 'ATASCO IMPRESORA', 'Buenos días. La impresora titila pero no imprime. Tenemos esa dificultad.', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-07 08:38:48', '2026-04-07 09:14:03', 'Solucion realizada');
INSERT INTO `Tickets` VALUES ('92', 'CSI2026040780139', '38', '24', 'Area de nomina', '7', '45', 'Revision de pc', 'Revisión de pc del area de nomina el cual presenta lentitud', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-07 08:52:27', '2026-04-07 15:38:47', 'Se realiza analisis con Karpesky antivirus encontrando virus en el mismo, se reemplaza en mcaffe del pc por total 360 antivirus y su ultima actualizacion');
INSERT INTO `Tickets` VALUES ('93', 'CSI2026040748939', '38', '173', 'equipos en general', '7', '36', 'Error al imprimir', 'Error al intentar imprimir', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-07 08:54:09', '2026-04-07 08:54:46', 'Se reconfigura la impresora en los pc clientes');
INSERT INTO `Tickets` VALUES ('94', 'CSI2026040726607', '38', '24', 'Bienes publicos', '7', '45', 'Equipo de enciende', 'Equipo de computacion no enciende pantalla', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-07 08:56:49', '2026-04-07 08:57:07', 'Solucion efectiva');
INSERT INTO `Tickets` VALUES ('95', 'CSI2026040731737', '45', '1', 'pool de asistentes', '7', '35', 'fallas carpetas', 'el equipo presenta fallas al abrir carpetas compartidas', NULL, NULL, 'media', 'Cerrado Exitosamente', '45', '0', '2026-04-07 09:01:59', '2026-04-07 09:03:00', 'se creo conexion con carpeta compartida');
INSERT INTO `Tickets` VALUES ('96', 'CSI2026040783424', '45', '24', 'bienes nacionales', '7', '37', 'sistema operativo', 'el equipo presenta fallas en el arranque del sistema operativo', NULL, NULL, 'alta', 'Cerrado Exitosamente', '45', '0', '2026-04-07 09:06:06', '2026-04-07 09:06:50', 'se reparo el sistema operativo');
INSERT INTO `Tickets` VALUES ('97', 'CSI2026040727761', '45', '163', 'pool de asistentes', '7', '37', 'fallas video', 'el equipo no da video, conector dañado', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-07 09:13:47', '2026-04-07 16:00:53', 'taller le soldo el puerto de video');
INSERT INTO `Tickets` VALUES ('98', 'CSI2026040712382', '45', '163', 'pool de asistentes', '7', '37', 'fallas en el video', 'el equipo no d video', NULL, NULL, 'media', 'Cerrado Exitosamente', '45', '0', '2026-04-07 09:23:28', '2026-04-07 09:24:22', 'se realizaron pruebas se paso a taller para cambio de conector');
INSERT INTO `Tickets` VALUES ('99', 'CSI2026040728513', '91', '205', 'SECRETARIA', '6', '31', 'MOUSE NO FUNCIONA', 'EL MOUSE UBICADO EN EL EQUIPO DE LA SECRETARIA ALEJANDRA CHÁVEZ, NO FUNCIONA, PRESENTA PROBLEMAS Y NO QUIERE RECONOCERLO EL PC.', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-07 13:31:46', '2026-04-07 16:11:21', 'conector flojo');
INSERT INTO `Tickets` VALUES ('100', 'CSI2026040763994', '44', '24', 'DAR', '6', '28', 'REPARACION S.O CAPTAHUELLA DAR', 'REPARACION S.O CAPTAHUELLA DAR DEBIDO A FALLAS ELECTRICAS.', NULL, NULL, 'urgente', 'Cerrado Exitosamente', '37', '0', '2026-04-07 13:43:14', '2026-04-07 14:47:06', 'equipo operativo');
INSERT INTO `Tickets` VALUES ('101', 'CSI2026040787605', '53', '172', 'pool de asistente', '7', '37', 'NO GUARDA LOS DOCUMENTOS', 'EL EQUIPO NO GUARDA LOS DOCUMENTOS Y ESTA MUY LENTA', NULL, NULL, 'media', 'Cerrado Exitosamente', '53', '0', '2026-04-07 13:47:36', '2026-04-10 10:55:52', 'SE REINSTALA SISTEMA OPERATIVO XP CON SUS APLICACIONES Y HERRAMIENTAS NECESARIAS PARA EL FUNCIONAMIENTO DEL MISMO');
INSERT INTO `Tickets` VALUES ('102', 'CSI2026040797335', '53', '24', 'Area Bienes Publicos', '7', '41', 'CAMBIO DE EQUPO (CPU)', 'SUSTITUCION DEL EQUIPO CPU UBICADO EN EL AREA DE BIENES PUBLICOS, FUNCIONARIO DOUGLAS GUTIERREZ.', NULL, NULL, 'media', 'Cerrado Exitosamente', '53', '0', '2026-04-07 13:52:59', '2026-04-07 14:07:23', 'SE REEMPLAZA CPU IBM N°BP 7807 POR CPU IBM N°BP 03-28-10500 EN EL AREA DE BIENES PUBLICOS');
INSERT INTO `Tickets` VALUES ('103', 'CSI2026040778919', '94', '177', 'Pool de Superior', '8', '52', 'No enciende el equipo informático', 'Buenas tardes. Se desconoce qué podría ser. El regulador funciona.', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-07 13:57:40', '2026-04-07 16:05:04', 'ajuste de memoria');
INSERT INTO `Tickets` VALUES ('104', 'CSI2026040777320', '53', '24', 'TALLER OATI MERIDA', '7', '45', 'INSTALACION CPU', 'INSTALACION DE EQUIPO DE COMPUTACION CPU', NULL, NULL, 'media', 'Cerrado Exitosamente', '53', '0', '2026-04-07 14:10:01', '2026-04-07 14:21:59', 'SE TRASLADA EQUIPO CPU N°BP 03-28-10480 AL AREA DE TALLER OATI');
INSERT INTO `Tickets` VALUES ('105', 'CSI2026040796054', '38', '24', 'Area de nomina', '7', '45', 'Equipo de computacion se visualiza mal en pantalla', 'Equipo de computacion se visualiza mal en pantalla', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-07 15:33:45', '2026-04-07 15:36:18', 'Se cambia cable vga, por el equipo mini pc, a este ultimo se le coloca su cable hdmi, quedando operativa los dos equipos de computacion');
INSERT INTO `Tickets` VALUES ('106', 'CSI2026040795741', '38', '201', 'Despacho de juez', '7', '45', 'Equipo de computacion no enciende', 'Equipo de computación no enciende con normalidad', NULL, NULL, 'alta', 'Cerrado No Exitoso', '38', '0', '2026-04-07 15:34:45', '2026-04-07 16:19:58', 'a la espera de remplazo del ssd');
INSERT INTO `Tickets` VALUES ('107', 'CSI2026040758875', '50', '201', 'pool de asistentes', '7', '35', 'carpeta compartida', 'sin acceso a carpeta compartida', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-07 16:10:47', '2026-04-07 16:13:34', 'se le dio permiso al usuario');
INSERT INTO `Tickets` VALUES ('108', 'CSI2026040792025', '50', '163', 'archivo del tribunal', '6', '26', 'archivo de inventario', 'el archivo de excel que se usa para llevar el control de los casos presenta error', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-07 16:16:29', '2026-04-09 12:28:57', 'Entregado');
INSERT INTO `Tickets` VALUES ('109', 'CSI2026040851088', '80', '24', 'Servicios  Judiciales', '8', '55', 'Recarga  de  Cartuchos', 'S e recargo el cartucho con 100 gramos de  tones', NULL, NULL, 'media', 'Cerrado Exitosamente', '80', '0', '2026-04-08 09:27:43', '2026-04-08 09:28:40', 'Ya  se  hizo la  recarga 7 de  marzo 2026  se  le  entrego a la  Jede  de  Servicios  Judiciales');
INSERT INTO `Tickets` VALUES ('110', 'CSI2026040829490', '37', '171', 'Dr Mori Despacho', '7', '37', 'Controlador de impresora', 'La Impresora no conecta', NULL, NULL, 'media', 'Cerrado Exitosamente', '51', '0', '2026-04-08 11:18:21', '2026-04-08 11:23:16', 'Reparado etc etc etc etc');
INSERT INTO `Tickets` VALUES ('111', 'CSI2026040869273', '35', '163', 'JUez  de  Despacho Control 1', '7', '37', 'El equipo no arranca', 'Erro  común en equipos  nuevos  donde  no reconoce el disco duro', NULL, NULL, 'media', 'Cerrado Exitosamente', '35', '0', '2026-04-08 11:41:36', '2026-04-08 11:42:17', 'Quedo Operativo');
INSERT INTO `Tickets` VALUES ('112', 'CSI2026040836154', '37', '171', 'pool secretarias', '7', '36', 'equipo no imprimia', 'no tenia conexión con la impresora', NULL, NULL, 'media', 'Cerrado Exitosamente', '37', '0', '2026-04-08 11:43:39', '2026-04-08 11:44:38', 'se verifico que la impresora estuviera instalada con sus respectivos controladores');
INSERT INTO `Tickets` VALUES ('113', 'CSI2026040854668', '45', '24', 'servicios judiciales', '7', '33', 'archivos pdf', 'fallas al crear archivos pdf', NULL, NULL, 'media', 'Cerrado Exitosamente', '45', '0', '2026-04-08 13:41:46', '2026-04-08 13:43:38', 'se crearon archivos en pdf');
INSERT INTO `Tickets` VALUES ('114', 'CSI2026040835321', '45', '24', 'telematica', '1', '3', 'telematica direcion con caracas', 'instalación de equipos para conexión via googlemeet reunión de directores', NULL, NULL, 'alta', 'Cerrado Exitosamente', '45', '0', '2026-04-08 13:45:56', '2026-04-08 13:46:58', 'se instalo y conecto correctamente');
INSERT INTO `Tickets` VALUES ('115', 'CSI2026040821052', '45', '168', 'acceso edificio hermes', '7', '45', 'falla en pc', 'actualización de hora y fecha en equipos de entrada al edificio hermes', NULL, NULL, 'media', 'Cerrado Exitosamente', '45', '0', '2026-04-08 13:50:54', '2026-04-08 13:51:34', 'se actualizo fecha y hora a equipos');
INSERT INTO `Tickets` VALUES ('116', 'CSI2026040866346', '45', '163', 'pool de asistentes', '7', '33', 'libro de excel', 'soporte para ajustar margenes en cuadro de excell', NULL, NULL, 'alta', 'Cerrado Exitosamente', '45', '0', '2026-04-08 15:22:49', '2026-04-08 15:23:31', 'se configuro margenes y se imprimio');
INSERT INTO `Tickets` VALUES ('117', 'CSI2026040818384', '56', '167', 'ORAPC', '1', '3', 'Solicitud de Sala Telemática lunes 20 de abril, Hora: 9:00 am', 'Solicitud de Sala Telemática con apoyo de laptop y televisor para el lunes 20 de Abril, para Taller de Auto-formación sobre "Violencia basada en Género. Enfoques y Perspectivas" el cual será dictado por el Tribunal de Violencia contra la Mujer al personal de la ORAPC Libertador. Hora: 9:00 am a 12:30 pm.', NULL, NULL, 'media', 'Cerrado Exitosamente', '45', '0', '2026-04-08 15:32:59', '2026-04-09 10:46:36', 'sala reservada');
INSERT INTO `Tickets` VALUES ('118', 'CSI2026040946219', '94', '177', 'Pool de Superior', '7', '37', 'Una computadora no arranca', 'No carga el sistema operativo de la computadora', NULL, NULL, 'media', 'Cerrado Exitosamente', '37', '0', '2026-04-09 09:42:30', '2026-04-09 11:45:07', 'equipo operativo');
INSERT INTO `Tickets` VALUES ('119', 'CSI2026040938188', '45', '24', 'nomina', '7', '38', 'fallas en el sistema', 'al entrar a windows genera error de usuario o contraseña', NULL, NULL, 'media', 'Cerrado Exitosamente', '45', '0', '2026-04-09 10:13:26', '2026-04-09 10:15:16', 'activacion de usuario');
INSERT INTO `Tickets` VALUES ('120', 'CSI2026040957845', '53', '37', 'POOL DE ABOGADOS', '7', '37', 'PANTALLA AZUL', 'EL EQUIPO AL ENCENDER DA PANTALLA AZUL', NULL, NULL, 'media', 'Cerrado Exitosamente', '53', '0', '2026-04-09 11:07:52', '2026-04-10 10:52:10', 'SE REINSTALA SISTEMA OPERATIVO W10 64BITS CON SUS APLICACIONES Y HERRAMIENTAS NECESARIAS PARA EL BUE FUNCIONAMIENTO DEL MISMO');
INSERT INTO `Tickets` VALUES ('121', 'CSI2026040945790', '94', '177', 'Coordinacion Judicial', '8', '46', 'CAMBIO DE CARTUCHO', 'Buenos días. Requerimos por favor, el cambio del cartucho de la impresora de la Coordinación. Contamos con el material que va a reemplazar.', NULL, NULL, 'media', 'Cerrado Exitosamente', '80', '0', '2026-04-09 11:28:55', '2026-04-09 12:32:06', 'CErrado  con exito');
INSERT INTO `Tickets` VALUES ('122', 'CSI2026040973714', '94', '177', 'Pool de Secretarios', '8', '52', 'FALLA DE REGULADOR', 'Buenos días. El regulador titila y no permite que el equipo encienda.', NULL, NULL, 'media', 'Cerrado Exitosamente', '80', '0', '2026-04-09 11:38:08', '2026-04-09 12:27:50', 'Entregado  y en funcionamiento');
INSERT INTO `Tickets` VALUES ('123', 'CSI2026040953296', '45', '163', 'pool de asistentes', '8', '54', 'fallas en la tarjeta principal', 'el cpu presenta fallas en la tarjeta principal', NULL, NULL, 'alta', 'Cerrado Exitosamente', '40', '0', '2026-04-09 11:53:59', '2026-04-10 11:43:48', 'En funcionamiento');
INSERT INTO `Tickets` VALUES ('124', 'CSI2026040957979', '38', '171', 'JUEZ', '7', '45', 'EQUIPO CON LENTITUD AL USAR OFFICE', 'EQUIPO CON LENTITUD AL USAR OFFICE', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-09 11:56:28', '2026-04-09 11:58:56', 'Se reinstala office en su version del 2013');
INSERT INTO `Tickets` VALUES ('125', 'CSI2026040918015', '7', '202', 'Despacho Juez', '8', '52', 'Reparacion de  Regulador', 'APAgaba  y prende  no mandadno el voltaje', NULL, NULL, 'media', 'Cerrado Exitosamente', '80', '0', '2026-04-09 12:15:11', '2026-04-09 12:31:27', 'Cerrado  con exito');
INSERT INTO `Tickets` VALUES ('126', 'CSI2026040920594', '94', '177', 'Pool de Secretarios', '6', '30', 'Instalación de programa de convertir word a pdf', 'Buenas tardes. Solicitud destinada para una Asistente de Tribunal', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-09 15:56:55', '2026-04-09 16:12:47', 'instalacion de equipo a la auxiliar de asistente de coordinacion y creacion de nombre en magistratura');
INSERT INTO `Tickets` VALUES ('127', 'CSI2026040917525', '94', '177', 'Coordinacion Judicial', '7', '41', 'Reubicación de equipo informático.', 'Buenas tardes. El movimiento sería del despacho del Tribunal Segundo de Primera Instancia de Sustanciación, Mediación y Ejecución del Trabajo de la Circunscripción Judicial del estado Bolivariano de Mérida, a la Coordinación Judicial de esta misma adscripción', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-09 16:00:02', '2026-04-09 16:15:15', 'instalacion de pc nueva a la doctora carmen y pasar el respectivo respaldo de usuario');
INSERT INTO `Tickets` VALUES ('128', 'CSI2026040915249', '50', '24', 'primer piso agrario', '7', '38', 'carpetas compartidas', 'no tiene permisos para accesar a carpetas compartidas', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-09 16:18:41', '2026-04-09 16:19:35', 'no resuelto hacerse el pendejo');
INSERT INTO `Tickets` VALUES ('129', 'CSI2026041065187', '60', '24', 'DAR AREA FASDEM', '6', '30', 'INSTALACION DE APLICACION PARA MODIFICAR PDF', 'instalación de aplicación para modificación de PDF ATENCIÓN ELADIO TORRES', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-10 09:24:50', '2026-04-10 09:29:43', 'Caso atendido');
INSERT INTO `Tickets` VALUES ('130', 'CSI2026041032119', '38', '177', 'Coordinacion judicial', '6', '25', 'cREACIÓN DE CUENTA DE EDITOR Y INTERNET', 'SOLICITUD DE CREACIÓN DE CUENTA DE EDITOR DE SENTENCIAS Y DE ACCESO A INTERNET DE BRENDA VALERO', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-10 10:14:33', '2026-04-10 10:17:29', 'Solucitudes atendidas y enviadas la dem central');
INSERT INTO `Tickets` VALUES ('131', 'CSI2026041024277', '38', '163', 'pc pool de asistente', '7', '45', 'Incorporacion de equipo a magistrarura', 'Incorporación de equipo a magistrarura, en apoyo al oati Gerardo Gamez', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-10 10:19:36', '2026-04-10 10:21:22', 'Caso aTendido satisfactoriamente');
INSERT INTO `Tickets` VALUES ('132', 'CSI2026041069476', '38', '24', 'OATI', '7', '34', 'Solicitud de restablecimiento de clave', 'Solicitud de restablecimiento de clave de acceso a internet de Jean paul Toro', NULL, NULL, 'baja', 'Cerrado Exitosamente', '38', '0', '2026-04-10 10:38:15', '2026-04-10 10:39:01', 'Solicitud remitida a seguridad informatica de la odi');
INSERT INTO `Tickets` VALUES ('133', 'CSI2026041075095', '38', '24', 'Informatica', '6', '31', 'REVISION DIARIA DE RESPALDOS', 'Revisión diaria de respaldos de servidores de documentos, perfiles y juris 2000', NULL, NULL, 'alta', 'Cerrado Exitosamente', '38', '0', '2026-04-10 10:40:47', '2026-04-10 10:48:12', 'Respaldo de juris lopnna se ejecuta a 10.46am de 10-04-26 para cumplir con error del dia anterior
Respaldo de perfiles dar, no se coloca a realizar en vista que genera lentitud en el acceso a las carpetas por parte de los usuarios durante la jornada laboral');
INSERT INTO `Tickets` VALUES ('134', 'CSI2026041053083', '38', '24', 'Nomina', '6', '30', 'Instalacion de editor de archivos pdf', 'Instalacion de editor de archivos pdf en equipo de computacion de Liliana Duran', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-10 10:50:35', '2026-04-10 10:51:25', 'Se instala abby finereader en su version 10');
INSERT INTO `Tickets` VALUES ('135', 'CSI2026041026647', '45', '205', 'secretaria', '7', '45', 'falla hora y fecha', 'fallas al cargar magistratura por falla de hora y fecha', NULL, NULL, 'alta', 'Cerrado Exitosamente', '45', '0', '2026-04-10 10:53:03', '2026-04-10 10:53:43', 'se configuro la fecha y la hora');
INSERT INTO `Tickets` VALUES ('136', 'CSI2026041065378', '94', '177', 'Pool de Secretarios', '7', '40', 'Ratificación de solicitud de clave y usuario para publicar sentencias', 'Buenos días. Mediante la presente ratificamos solicitud realizada mediante correo electrónico. Allí se solicitó usuario y clave de windows, así como también acceso y clave para publicar sentencias en la página del TSJ. Sin embargo, YA TIENE USUARIO Y CLAVE DE WINDOWS, se le otorgó posteriormente a la solicitud. Por lo que hace falta el del TSJ y usuario y clave de internet. Gracias de antemano', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-10 10:59:27', '2026-04-10 11:04:45', 'Solicitud enviada a la den y tsj en ccs');
INSERT INTO `Tickets` VALUES ('137', 'CSI2026041050575', '35', '24', 'DAR', '6', '31', 'Registro fotografico de las actividades realizadas por OATI', 'Se hace el registro fotográfico y posterior enlace con Servicios Judiciales para su control e informe', NULL, NULL, 'alta', 'Cerrado Exitosamente', '35', '0', '2026-04-10 11:05:46', '2026-04-10 13:53:40', 'entregado con exito');
INSERT INTO `Tickets` VALUES ('139', 'CSI2026041013407', '7', '163', 'pool de asistentes', '5', '20', 'Punto de  Red no funciona', 'El Punto de  RED no funciona', NULL, NULL, 'media', 'Cerrado Exitosamente', '40', '0', '2026-04-10 11:45:46', '2026-04-10 14:24:23', 'Cerrado con  exito');
INSERT INTO `Tickets` VALUES ('140', 'CSI2026041079723', '7', '24', 'Archivo Regional', '8', '55', 'Se  recargo cartucho de impresora 125 canon', 'Se  recargo cartucho de impresora 125 canon se  le  coloco  40 gramos', NULL, NULL, 'media', 'Cerrado Exitosamente', '80', '0', '2026-04-10 12:18:29', '2026-04-10 12:19:47', 'Cerrado con exito');
INSERT INTO `Tickets` VALUES ('141', 'CSI2026041077191', '7', '163', 'Despacho de Juez', '7', '37', 'Error de DIsco  Duro', 'Falla de  arranque', NULL, NULL, 'media', 'Cerrado Exitosamente', '40', '0', '2026-04-10 14:11:37', '2026-04-10 14:24:04', 'cerrado con exito');
INSERT INTO `Tickets` VALUES ('142', 'CSI2026041097636', '7', '24', 'Despacho', '8', '53', 'Se atasco papel en Impresora', 'Atasco de  PAPEL', NULL, NULL, 'media', 'Cerrado Exitosamente', '51', '0', '2026-04-10 15:25:45', '2026-04-10 15:26:00', 'Cerrado con exito');
INSERT INTO `Tickets` VALUES ('143', 'CSI2026041031800', '94', '177', 'Pool de Superior', '6', '30', 'Instalación de navegador', 'Buenas tardes. Esta fue realizada por Orangel en el equipo informático de una Secretaria de Tribunales.', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-10 16:00:37', '2026-04-10 16:06:00', 'instalacion de explorador chronium por que mozila no le dejaba enviar correos');
INSERT INTO `Tickets` VALUES ('144', 'CSI2026041333920', '94', '177', 'Coordinación Judicial', '7', '36', 'Soporte al funcionamiento de la impresora de la Coordinación', 'Buenos días. La impresora titila pero no procede.', NULL, NULL, 'media', 'Cerrado Exitosamente', '95', '0', '2026-04-13 08:43:48', '2026-04-17 09:29:20', 'exitoso');
INSERT INTO `Tickets` VALUES ('145', 'CSI2026041310429', '45', '24', 'servicios Judiciales', '7', '39', 'usuarios bloqueados', 'desbloqueo de usuarios', NULL, NULL, 'media', 'Cerrado Exitosamente', '45', '0', '2026-04-13 09:23:10', '2026-04-13 09:24:03', 'se desbloquearon usuarios');
INSERT INTO `Tickets` VALUES ('146', 'CSI2026041383606', '45', '24', 'bienes nacionales', '7', '35', 'fallas en la carpetas compartidas', 'conexión con las carpetas compartidas', NULL, NULL, 'media', 'Cerrado Exitosamente', '45', '0', '2026-04-13 09:44:16', '2026-04-13 09:44:52', 'se configurararon las carpetas bienes nacionales');
INSERT INTO `Tickets` VALUES ('147', 'CSI2026041351160', '56', '167', 'ORAPC', '1', '4', 'Solicitud de corneta pequeña', 'Solicitud de corneta pequeña para autoformación en la Oficina de la ORAPC (Edificio Hermes, primer piso), para el día lunes 13 de abril, 2:00 a 4:00 pm', NULL, NULL, 'media', 'Cerrado Exitosamente', '37', '0', '2026-04-13 09:45:43', '2026-04-13 13:52:32', 'requerimiento procesado');
INSERT INTO `Tickets` VALUES ('148', 'CSI2026041338571', '45', '24', 'paticipacion ciudadana', '1', '3', 'instalacion de equipos', 'se requiere instalación de equipos para telemática', NULL, NULL, 'media', 'Cerrado Exitosamente', '45', '0', '2026-04-13 09:59:05', '2026-04-13 11:21:08', 'instalación de sala telemática');
INSERT INTO `Tickets` VALUES ('149', 'CSI2026041338361', '37', '1', 'despacho dra Jeanette Sterlicchi', '7', '39', 'bloqueo de usuario', 'usuario bloqueado de la dra.Jeanette Sterlicchi', NULL, NULL, 'media', 'Cerrado Exitosamente', '37', '0', '2026-04-13 10:06:03', '2026-04-13 10:06:32', 'usuario desbloqueado');
INSERT INTO `Tickets` VALUES ('150', 'CSI2026041379589', '7', '177', 'coordinacion', '8', '54', 'reparacion de cartucho', 'hp 145 toner repaeacion', NULL, NULL, 'media', 'Cerrado Exitosamente', '51', '0', '2026-04-13 10:12:35', '2026-04-13 10:13:02', 'cerrado con exito');
INSERT INTO `Tickets` VALUES ('151', 'CSI2026041362366', '91', '205', 'URDD', '7', '45', 'REPARACION DE TECLADO', 'BUENOS DÍAS FAVOR REALIZAR LA REVISIÓN DEL TECLADO UBICADO EN EL ÁREA DE LA URDD, POR CUANTO EL MISMO NO FUNCIONA. NO BIEN 6680. ASÍ MISMO LA REPARACIÓN DE UN MOUSE NO BIEN 23-0686.', NULL, NULL, 'media', 'Cerrado Exitosamente', '42', '0', '2026-04-13 10:41:00', '2026-04-13 15:51:37', 'Cerrado exitosamente y funcionando');
INSERT INTO `Tickets` VALUES ('152', 'CSI2026041355734', '37', '172', 'pc secretaria del tribunal', '7', '36', 'no imprime el equipo', 'pc del pool de secretario no tiene el controlador de instalacion de la impresora', NULL, NULL, 'media', 'Cerrado Exitosamente', '37', '0', '2026-04-13 11:01:57', '2026-04-13 11:02:40', 'se instalo la conexion con la impresora del pool a la secretaria');
INSERT INTO `Tickets` VALUES ('153', 'CSI2026041347957', '56', '167', 'Oficina ORAPC, primer piso', '4', '19', 'Solicitud de revisión Linea Telefónica', 'En virtud de la Circular N° 004; solicito muy respetuosamente la revisión de la linea telefónica en la oficina de la ORAPC  y así  contar con una extensión de la central telefónica. Gracias', NULL, NULL, 'media', 'Cerrado Exitosamente', '51', '0', '2026-04-13 11:03:38', '2026-04-14 11:38:24', 'Cerrado con exito quedo funcionando  bien el telefono');
INSERT INTO `Tickets` VALUES ('154', 'CSI2026041336900', '94', '177', 'Coordinación Judicial', '7', '35', 'No acceso a carpeta compartida', 'Buenos días. Hubo dificultad en el acceso a la carpeta todos en la computadora de la Coordinadora Judicial. Fue atendido por el técnico Orangel. Gracias.', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-13 11:50:29', '2026-04-13 11:59:04', 'CABLE DE RED DESCONECTADOM SE AJUSTO Y SE RESTAURO LA CONEXION');
INSERT INTO `Tickets` VALUES ('155', 'CSI2026041312853', '94', '177', 'Tribunal Segundo de 1era Instancia de Sustanciación, Mediación y Ejecución del Trabajo de la Circunscripción Judicial del estado Bolivariano de Mérida', '6', '25', 'Acceso a Intranet', 'Buenos días. Hubo el requerimiento del acceso a la página de INTRANET en la computadora de la Jueza del Tribunal referido. 

Esto fue atendido por el técnico Orangel. Gracias.', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-13 11:52:43', '2026-04-13 12:01:15', 'PC FUERA DE MAGISTRATURA, SE SACO Y SE VOLVIO A METER A MAGISTRATURA, REINICIO DE CONTRASEÑA Y CREACION DE ACCESOS DIRECTOS DE PAGINAS');
INSERT INTO `Tickets` VALUES ('156', 'CSI2026041353978', '94', '177', 'Tribunal Primero de 1era Instancia de Juicio del Trabajo de la Circunscripción Judicial del estado Bolivariano de Mérida', '7', '33', 'Asesoría informática', 'Buenas tardes. La abogada relatora del Tribunal referido consultó al técnico sobre sus dudas del manejo de algunos programas informáticos, esencialmente de oficina.

Esto lo atendió el técnico Orangel. Gracias.', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-13 11:57:18', '2026-04-13 12:03:11', 'ASESORIA TECNICA DRA YANETPIDIO INFORMACION SOBRE COMO INSTALAR DISPOSITIVO BLOOTOO EN PC PARA DESCARGAR INFORMACION DE CELULAR QUE ESCANEA DOCUMENTOS PARA TRANSCRIBIR');
INSERT INTO `Tickets` VALUES ('157', 'CSI2026041331181', '94', '177', 'Pool de Secretarios', '7', '35', 'Sin carpeta compartida', 'Buenas tardes. Se presenta el problema en el computador de una Asistente de Tribunales del Pool de Secretarios.', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-13 14:05:52', '2026-04-13 14:51:11', 'se ajusto el conector de red');
INSERT INTO `Tickets` VALUES ('158', 'CSI2026041364521', '45', '24', 'bienes nacionales', '7', '45', 'fallas en el video', 'el monitor cambia de colores', NULL, NULL, 'media', 'Cerrado Exitosamente', '45', '0', '2026-04-13 14:26:45', '2026-04-13 14:30:10', 'revision de cables y monitor para verificar fallas');
INSERT INTO `Tickets` VALUES ('159', 'CSI2026041331129', '45', '177', 'coordinacion', '7', '36', 'instalacion de impresora', 'instalación y configuración de impresora en pc de coordinación', NULL, NULL, 'alta', 'Cerrado Exitosamente', '95', '0', '2026-04-13 14:28:32', '2026-04-13 14:36:15', 'Cerrado con exito');
INSERT INTO `Tickets` VALUES ('160', 'CSI2026041391068', '7', '205', 'recepcion', '8', '54', 'Mantenimiento Teclado y Raton', 'Mantenimiento Teclado y Raton', NULL, NULL, 'media', 'Cerrado Exitosamente', '42', '0', '2026-04-13 14:29:31', '2026-04-13 14:29:59', 'Entregado y  en funcionamiento');
INSERT INTO `Tickets` VALUES ('162', 'CSI2026041337586', '55', '169', 'rectoria', '1', '1', 'Evento de formacion', 'Se  solicita  Lapto, Cornetas,  Verificacion de  Red  y Personal que opere el equipo los dias 22 de  abril, 29 de Abril, 13  de Mayo, 22 de MAyo, 19 de Junio, 1  de julio, 8 de Julio, 15 de Julio, 22 de Julio, 29 de Julio y  5  de  Agosto.', NULL, NULL, 'media', 'En Proceso', '35', '1', '2026-04-13 15:13:02', NULL, NULL);
INSERT INTO `Tickets` VALUES ('163', 'CSI2026041327233', '7', '208', 'Servicios Penitenciarios 3er piso', '8', '55', 'Recarga  y Mantenimiento de Cartuchos', 'Recarga  y Mantenimiento de Cartuchos HP 107 con  toner de Servicios Penitenciarios', NULL, NULL, 'media', 'Cerrado Exitosamente', '42', '0', '2026-04-13 15:54:56', '2026-04-13 15:55:30', 'Cerrado Exitosamente');
INSERT INTO `Tickets` VALUES ('164', 'CSI2026041326041', '7', '170', 'Abogados', '7', '35', 'Problemas de  conexion de la PC a  la red  MAgistratura', 'Problemas de  conexión de la PC a  la red  MAgistratura  y restablecimiento de  contraseña al usuario', NULL, NULL, 'media', 'Cerrado Exitosamente', '40', '0', '2026-04-13 16:09:54', '2026-04-13 16:10:41', 'Cerrado  exito y en funcionamiento');
INSERT INTO `Tickets` VALUES ('165', 'CSI2026041367601', '50', '202', 'primer piso del hermes', '7', '41', 'reubicacion de pc', 'se cambio de lugar el pc', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-13 16:26:49', '2026-04-13 16:30:31', 'SE REUBICO DE LUGAR PC SEGUN PETICION');
INSERT INTO `Tickets` VALUES ('166', 'CSI2026041374079', '50', '202', 'PRIMER PISO DEL HERMES', '7', '33', 'CONVERTIR ARCHIVO', 'SE INSTRUYO AL USUARIO COMO CONVERTIR PDF A WORD', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-13 16:28:51', '2026-04-13 16:29:43', 'SE REUBICO PC SEGUN PETICION');
INSERT INTO `Tickets` VALUES ('167', 'CSI2026041354587', '39', '165', 'Pool de asistente', '7', '36', 'Instalación de equipo', 'Instalación de equipo completo CPU, Monitor, Teclado. mouse,', NULL, NULL, 'media', 'Cerrado Exitosamente', '39', '0', '2026-04-13 16:47:40', '2026-04-13 17:05:58', 'instalación completada queda operativo todo');
INSERT INTO `Tickets` VALUES ('168', 'CSI2026041496205', '91', '205', 'ARCHIVO DEL CIRCUITO', '6', '31', 'NO ENCIENDE EL EQUIPO PC', 'Buenos días favor realizar la revisión de los dos (2) equipos de computación ubicados en el área del Archivo de este Circuito Judicial de Protección, por cuanto los mismos no encienden.', NULL, NULL, 'media', 'Cerrado Exitosamente', '45', '0', '2026-04-14 08:42:35', '2026-04-14 09:38:58', 'se reviso conexion a magistratura y se encendieron los equipos');
INSERT INTO `Tickets` VALUES ('169', 'CSI2026041480441', '94', '177', 'Pool de secretarios', '7', '39', 'Bloqueo usuario Windows', 'Buenos días. No se puede acceder a la cuenta de la Secretaria del Tribunal Primero Superior del Trabajo, parece bloqueada. Gracias de antemano.', NULL, NULL, 'media', 'Cerrado Exitosamente', '37', '0', '2026-04-14 08:51:15', '2026-04-14 09:17:14', 'usuario desbloqueado');
INSERT INTO `Tickets` VALUES ('170', 'CSI2026041454427', '91', '205', 'Recarga de Tóner', '8', '55', 'Recarga de Tóner', 'Buenos días el día de hoy se requiere la recarga de Tóner de la impresora ubicada en el Pool de Impresiones. Es importante mencionar que el Tóner es suministrado por esta Coordinación para la recarga del mismo.', NULL, NULL, 'media', 'Cerrado Exitosamente', '42', '0', '2026-04-14 09:10:20', '2026-04-15 14:35:08', 'Cerrado con exito');
INSERT INTO `Tickets` VALUES ('171', 'CSI2026041466832', '50', '24', 'recepcion', '7', '45', 'carpetas compartidas', 'sin acceso a carpetas compartidas', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-14 10:16:33', '2026-04-14 10:17:42', 'se ajusto el conector de red y se renovo direccion ip');
INSERT INTO `Tickets` VALUES ('172', 'CSI2026041449394', '45', '24', 'cesta ticket', '7', '45', 'fallas en gisa cjp', 'no se puede cargar el reporte de gisa dl cjp', NULL, NULL, 'alta', 'Cerrado Exitosamente', '45', '0', '2026-04-14 10:47:34', '2026-04-14 10:48:33', 'se reiniciaron los servidores y cargaron exitosamente data del cjp');
INSERT INTO `Tickets` VALUES ('173', 'CSI2026041412008', '7', '170', 'Pool de Asistentes', '6', '30', 'Activacion de Windows y  Instalacion de Word', 'Activación de Windows y  Instalación de Word', NULL, NULL, 'media', 'Cerrado Exitosamente', '40', '0', '2026-04-14 11:33:18', '2026-04-14 11:37:32', 'Cerrado con exito');
INSERT INTO `Tickets` VALUES ('174', 'CSI2026041416047', '7', '170', 'Poool de Asistentes', '7', '36', 'Instalacion de Impresora', 'Instalacion de Impresora en el tribunal HP 1320', NULL, NULL, 'media', 'Cerrado Exitosamente', '40', '0', '2026-04-14 11:34:33', '2026-04-14 11:36:34', 'Cerrado con exito');
INSERT INTO `Tickets` VALUES ('175', 'CSI2026041418452', '35', '24', 'Penal Adolecentes', '7', '36', 'Secretaria de despacho de Juez de Juicio no puede imprimir', 'Secretaria de despacho de Juez de Juicio no puede imprimir', NULL, NULL, 'media', 'Cerrado Exitosamente', '35', '0', '2026-04-14 11:48:08', '2026-04-17 10:30:03', 'Cerrado con exito');
INSERT INTO `Tickets` VALUES ('176', 'CSI2026041495963', '35', '24', 'Penal Adolecentes', '7', '34', 'No tiene acceso a inventario principal de archivo', 'No tiene acceso a inventario principal de archivo', NULL, NULL, 'media', 'Cerrado Exitosamente', '35', '0', '2026-04-14 11:49:13', '2026-04-17 10:29:57', 'Cerrado con exito');
INSERT INTO `Tickets` VALUES ('177', 'CSI2026041415571', '35', '24', 'Tribunal Superior Segundo', '7', '34', 'Sin acceso a internet', 'Pc del Juez rector sin acceso a internet ni paginas institucionales', NULL, NULL, 'media', 'Cerrado Exitosamente', '35', '0', '2026-04-14 11:51:01', '2026-04-17 10:29:47', 'Cerrado con exito');
INSERT INTO `Tickets` VALUES ('178', 'CSI2026041496334', '35', '24', 'Penal Adolecentes', '7', '37', 'La computadora no arranca', 'Pc del despacho del Juez de control no inicia', NULL, NULL, 'media', 'Cerrado Exitosamente', '35', '0', '2026-04-14 11:53:07', '2026-04-17 10:28:55', 'Cerrado con exito');
INSERT INTO `Tickets` VALUES ('179', 'CSI2026041415909', '35', '24', 'Redacciones de Memorandum', '1', '4', 'presentacion de Memorandum', 'Sirva la presente para la realización de memorándum', NULL, NULL, 'media', 'Cerrado Exitosamente', '35', '0', '2026-04-14 11:59:32', '2026-04-17 10:28:49', 'Cerrado con exito');
INSERT INTO `Tickets` VALUES ('180', 'CSI2026041425967', '45', '1', 'oficina juez', '7', '38', 'error de magistratura', 'al ingresar a magistratura indica usuario bloqueado', NULL, NULL, 'alta', 'Cerrado Exitosamente', '45', '0', '2026-04-14 14:36:52', '2026-04-14 14:37:37', 'se ingreso a Magistratura');
INSERT INTO `Tickets` VALUES ('181', 'CSI2026041468461', '46', '165', 'POOL DE RELATORES', '7', '36', 'INSTALACION DE IMPRESORA', 'ACCESO E INSTALACIÓN A LA IMPRESORA DEL POOL DE ASISTENTES', NULL, NULL, 'media', 'Cerrado Exitosamente', '46', '0', '2026-04-14 17:22:30', '2026-04-14 17:24:06', 'IMPRESORA INSTALADA EXITOSAMENTE');
INSERT INTO `Tickets` VALUES ('182', 'CSI2026041463304', '46', '165', 'DESPACHO DE CONTROL 3', '7', '36', 'INSTALACION DE IMPRESORA', 'INSTALACION Y CONFIGURACION DE IMPRESORA DEL DESPACHO DE CONTROL 3, LA CUAL ES COMPARTIDA A TRAVES DE LA RED PARA EL PERSONAL DE ESTE TRIBUNAL', NULL, NULL, 'alta', 'Cerrado Exitosamente', '46', '0', '2026-04-14 17:28:56', '2026-04-14 18:21:50', 'SE INSTALO CORRECTAMENTE');
INSERT INTO `Tickets` VALUES ('183', 'CSI2026041424524', '46', '176', 'TRIBUNAL DE PRIMERA INSTANCIA', '7', '37', 'REPARACION DE EQUIPO', 'EQUIPO RECUPERADO A TRAVÉS DEL PLAN DE DIAGNOSTICO PARA LA RECUPERACIÓN Y MANTENIMIENTO DE BIENES PÚBLICOS 2026, AL CUAL SE LE CAMBIO LA FUENTE DE PODER, SE LE INSTALO UN DISCO DURO OBTENIDO MEDIANTE AUTOGESTIÓN POR EL JUEZ DEL TRIBUNAL, SE ADJUNTA OFICIO DE SOLICITUD E INFORME TÉCNICO', NULL, NULL, 'alta', 'Cerrado Exitosamente', '46', '0', '2026-04-14 17:50:34', '2026-04-14 18:21:31', 'SE ENTREGO EL EQUIPO AL TRIBUNAL');
INSERT INTO `Tickets` VALUES ('184', 'CSI2026041424412', '46', '176', 'TRIBUNAL DE PRIMERA INSTANCIA', '7', '45', 'ELABORACION DE INFORME TECNICO', 'ELABORACIÓN DE INFORME TÉCNICO EN EL CUAL SE SUGIERE LA DESINCORPORACIÓN DE 2 CPU LOS CUALES TIENEN LA TARJETA MADRE QUEMADA Y NO PUEDEN SER RECUPERADOS. SE ADJUNTA INFORME TÉCNICO.', NULL, NULL, 'media', 'Cerrado Exitosamente', '46', '0', '2026-04-14 17:56:01', '2026-04-14 18:23:42', 'SE ENTREGARON LOS EQUIPOS AL TRIBUNAL');
INSERT INTO `Tickets` VALUES ('185', 'CSI2026041581106', '46', '178', 'LABORAL VIGIA', '7', '37', 'REPARACION DE EQUIPO', 'EQUIPO RECUPERADO A TRAVÉS DEL PLAN DE DIAGNOSTICO PARA LA RECUPERACIÓN Y MANTENIMIENTO DE BIENES PÚBLICOS 2026, AL CUAL SE LE CAMBIO LA FUENTE DE PODER, CAPACITORES,DISCO DURO, SE ADJUNTA OFICIO DE SOLICITUD E INFORME TÉCNICO', NULL, NULL, 'media', 'Cerrado Exitosamente', '46', '0', '2026-04-14 18:11:13', '2026-04-14 18:23:26', 'SE INSTALO EXITOSAMENTE');
INSERT INTO `Tickets` VALUES ('186', 'CSI2026041533307', '46', '165', 'DESPACHO DE CONTROL 3', '7', '37', 'INSTALACION DE EQUIPO', 'MANTENIMIENTO GENERAL, FORMATEO E INSTALACION DE SISTEMA OPERATIVO WINDOWS 10 PRO x64.', NULL, NULL, 'media', 'Cerrado Exitosamente', '46', '0', '2026-04-14 18:13:03', '2026-04-14 18:23:10', 'SE INSTALO EXITOSAMENTE');
INSERT INTO `Tickets` VALUES ('187', 'CSI2026041585506', '46', '165', 'POOL DE TPM', '7', '37', 'INSTALACION DE EQUIPO', 'MANTENIMIENTO GENERAL, FORMATEO E INSTALACIÓN DE SISTEMA OPERATIVO WINDOWS 10 PRO x86', NULL, NULL, 'media', 'Cerrado Exitosamente', '46', '0', '2026-04-14 18:14:41', '2026-04-14 18:22:47', 'SE INSTALO EXITOSAMENTE');
INSERT INTO `Tickets` VALUES ('188', 'CSI2026041530402', '46', '165', 'POOL DE JUICIO', '7', '36', 'INSTALACION DE EQUIPO', 'MANTENIMIENTO GENERAL, FORMATEO E INSTALACION DE SISTEMA OPERATIVO WINDOWS 10 PRO x86, ELABORACION DE INFORME TECNICO RESPECTO A DAÑOS EN EL DISCO DURO EN EL CUAL SE RECOMENDO EL REEMPLAZO, A SU VEZ SE REALIZO CAMBIO DE CAPACITORES A LA TARJETA MADRE.', NULL, NULL, 'media', 'Cerrado Exitosamente', '46', '0', '2026-04-14 18:16:45', '2026-04-14 18:22:35', 'SE INSTALO EXITOSAMENTE');
INSERT INTO `Tickets` VALUES ('189', 'CSI2026041517290', '46', '165', 'POOL DE ASISTENTES', '5', '20', 'RECONEXION DE VPN', 'RECONEXION DE VPN', NULL, NULL, 'alta', 'Cerrado Exitosamente', '46', '0', '2026-04-14 18:17:51', '2026-04-14 18:20:32', 'SE RECONECTO EXITOSAMENTE');
INSERT INTO `Tickets` VALUES ('190', 'CSI2026041557398', '46', '165', 'POOL DE ASISTENTES DE COORDINACION', '7', '36', 'INSTALACION DE IMPRESORAS', 'INSTALACIÓN DE IMPRESORA DE COORDINACIÓN JUDICIAL Y INSTALACIÓN DE ACCESOS DIRECTOS A LA CARPETA COMPARTIDA DE COORDINACION', NULL, NULL, 'media', 'Cerrado Exitosamente', '46', '0', '2026-04-14 18:20:14', '2026-04-14 18:22:10', 'SE REALIZO EXITOSAMENTE');
INSERT INTO `Tickets` VALUES ('191', 'CSI2026041545150', '91', '205', 'Despacho Jueza Luz Marina Pacheco', '8', '54', 'Revisión lampara de iluminación', 'Buenos días, favor realizar la revisión de la lampara de iluminación, ubicada en el Despacho de la Jueza Luz Marina Pacheco Avendaño, por cuanto presenta fallas, la luz esta intermitente, lo cual genera incomodidad visual.', NULL, NULL, 'media', 'Cerrado Exitosamente', '7', '0', '2026-04-15 08:55:52', '2026-04-15 09:50:18', 'Se informo al coordinador  y mando un funcionario para  solventar el problema');
INSERT INTO `Tickets` VALUES ('192', 'CSI2026041597201', '82', '24', 'AREA DE BIENES PUBLICOS', '5', '24', 'SIN ACCESO A CARPETA COMPARTIDA BIENES REGION', 'SIN ACCESO A LA CARPETA COMPARTIDA BIENES PUBLICOS REGION EN EL PC USUARIO JAVILA', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-15 09:03:13', '2026-04-17 11:45:27', 'actividad realizada');
INSERT INTO `Tickets` VALUES ('193', 'CSI2026041513454', '45', '1', 'despacho Juez', '7', '39', 'cambio de contraseña', 'la Juez solicita cambio de contraseña', NULL, NULL, 'media', 'Cerrado Exitosamente', '45', '0', '2026-04-15 09:23:30', '2026-04-15 09:24:21', 'se le realizo cambio de contraseña y se debloqueo el usuario');
INSERT INTO `Tickets` VALUES ('194', 'CSI2026041533153', '38', '162', 'Cesta Ticket', '6', '30', 'Falla en captahuella', 'Falla en captahuella, lentitud al iniciar', NULL, NULL, 'urgente', 'Cerrado Exitosamente', '38', '0', '2026-04-15 09:31:19', '2026-04-15 09:32:10', 'Se reemplaza disco duro por cuanto tenia sectores malos');
INSERT INTO `Tickets` VALUES ('195', 'CSI2026041529371', '38', '162', 'Tribunal municipal 2', '7', '45', 'Recuperacion de informacion en equipo', 'Recuperacion de informacion en equipo despues de formateo', NULL, NULL, 'alta', 'Cerrado No Exitoso', '38', '0', '2026-04-15 09:33:27', '2026-04-15 09:41:38', 'No se logra recuperar informacion del usuario
Se determina que en discos solidos con tegnologia trim no deja rastros de informacion antigua despues de formateo');
INSERT INTO `Tickets` VALUES ('196', 'CSI2026041576221', '38', '162', 'varios', '7', '39', 'Desbloqueo de cuentas de usuarios', 'Desbloqueo de cuentas de usuarios', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-15 09:42:35', '2026-04-15 09:43:19', 'Desbloqueo de cuentas de varios usuarios en el transcurso de la mañana');
INSERT INTO `Tickets` VALUES ('197', 'CSI2026041536072', '38', '24', 'BIenes publicos', '7', '35', 'Imposibilidad de ingresar a carpera de bines publicos regionales', 'Imposibilidad de ingresar a carpera de bines publicos regionales varios usuarios de bienes publicos de la dar', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-15 10:00:51', '2026-04-15 10:01:28', 'Se habilita el ingreso a dicha carpeta, el personal solicitado');
INSERT INTO `Tickets` VALUES ('198', 'CSI2026041578145', '50', '201', 'tercer piso del hermes', '7', '37', 'bateria', 'solicita cambio de bateria para pc de secretario', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-15 10:23:24', '2026-04-15 10:30:37', 'se le cambio la bateria del la tarjeta madre a peticion del usuario, ellos compraron la bateria');
INSERT INTO `Tickets` VALUES ('199', 'CSI2026041513706', '50', '201', '3ro de municipio 2do piso del hermes', '7', '39', 'usuario bloqueado', 'el usuario esta bloqueado ya es el segundo dia que amanece asi', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-15 10:25:54', '2026-04-15 10:29:38', 'se desbloqueo el usuario de archivo y se le creo nueva clave de acceso');
INSERT INTO `Tickets` VALUES ('200', 'CSI2026041518190', '50', '201', '3ro de municipio 2do piso del hermes', '7', '32', 'asesoria tecnica', 'el usuario pidio asesoria en la utilizacion del antivirus', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-15 10:27:40', '2026-04-15 10:28:43', 'se adiestro al usuario en el uso del antivirus');
INSERT INTO `Tickets` VALUES ('201', 'CSI2026041558625', '50', '200', '2do de municipio 2do piso del hermes', '7', '40', 'usuario bloqueado', 'usuario manifiesta no poder entrar a su cuenta por estar bloqueado', NULL, NULL, 'media', 'Cerrado Exitosamente', '50', '0', '2026-04-15 10:40:57', '2026-04-15 10:44:10', 'se desbloque usuario y se le asigno nueva clave');
INSERT INTO `Tickets` VALUES ('202', 'CSI2026041578880', '7', '205', 'URD', '8', '53', 'ATasco de  PApel', 'Impresora 2015', NULL, NULL, 'media', 'Cerrado Exitosamente', '42', '0', '2026-04-15 14:30:34', '2026-04-15 14:34:05', 'Cerrado con exito');
INSERT INTO `Tickets` VALUES ('203', 'CSI2026041560483', '7', '205', 'Pool  de Impresion', '8', '55', 'Recarga  de  cartucho HP 4003', 'Recarga y  mantenimiento  de  cartucho HP 4003', NULL, NULL, 'media', 'Cerrado Exitosamente', '42', '0', '2026-04-15 14:31:37', '2026-04-15 14:33:52', 'Cerrado con exito');
INSERT INTO `Tickets` VALUES ('204', 'CSI2026041567665', '7', '208', 'Recepcion 3er piso', '8', '48', 'Mantenimiento de  Impresora HP 106', 'Mantenimiento de  Impresora HP 106', NULL, NULL, 'media', 'Cerrado Exitosamente', '42', '0', '2026-04-15 14:32:50', '2026-04-15 14:33:34', 'Cerrado con exito');
INSERT INTO `Tickets` VALUES ('205', 'CSI2026041546809', '45', '24', 'FASDEM', '7', '45', 'EQUIPO FUERA DE MAGISTRATURA', 'El equipo no funcionan las carpetas compartidas', NULL, NULL, 'media', 'Cerrado Exitosamente', '45', '0', '2026-04-15 14:42:00', '2026-04-15 14:44:00', 'se ingreso equipo a magistratura');
INSERT INTO `Tickets` VALUES ('206', 'CSI2026041521805', '7', '163', 'Pool de Secretarios', '8', '48', 'Mantenimiento de  Cartucho HP 13A', 'Mantenimiento de  Cartucho HP 13A', NULL, NULL, 'media', 'Cerrado Exitosamente', '42', '0', '2026-04-15 14:58:59', '2026-04-15 14:59:30', 'Cerrado con exito');
INSERT INTO `Tickets` VALUES ('207', 'CSI2026041614793', '47', '170', 'secretario', '8', '48', 'mantenimiento impresora', 'se le realizo mantenimiento genereal', NULL, NULL, 'alta', 'Cerrado Exitosamente', '47', '0', '2026-04-16 09:12:05', '2026-04-16 09:12:34', 'trabajando perfectamenta');
INSERT INTO `Tickets` VALUES ('208', 'CSI2026041685660', '47', '170', 'secretario', '8', '54', 'reparacio de cartucho', 'se realizo cambio de cartucho, ya que el cartucho anterior estaba presentando falla', NULL, NULL, 'media', 'Cerrado Exitosamente', '47', '0', '2026-04-16 09:14:19', '2026-04-16 09:14:43', 'funcionando con total normalidad');
INSERT INTO `Tickets` VALUES ('209', 'CSI2026041637187', '82', '24', 'AREA DE BIENES PUBLICOS', '5', '24', 'SIN ACCESO A CARPETA COMPARTIDA TODOS-POOL DE IMPRESION', 'SIN ACCESO A CARPETA COMPARTIDA TODOS-POOL DE IMPRESION - BIENES PUBLICOS EN PC USUARIO JAVILA', NULL, NULL, 'media', 'Cerrado Exitosamente', '37', '0', '2026-04-16 09:57:49', '2026-04-16 14:01:49', 'caso cerrado');
INSERT INTO `Tickets` VALUES ('210', 'CSI2026041617863', '36', '176', 'poll asistente', '7', '37', 'Equipo no arranca', 'El PC había perdido la ruta de arranque, se volvió a configurar y quedo operativo de nuevo, se verifico con varios reinicio', NULL, NULL, 'media', 'Cerrado Exitosamente', '36', '0', '2026-04-13 10:12:00', '2026-04-16 16:01:27', 'configuración e Bios');
INSERT INTO `Tickets` VALUES ('211', 'CSI2026041640630', '46', '165', 'POOL DE ASISTENTES DE COORDINACION', '7', '36', 'INSTALACION DE IMPRESORA', 'INSTALACIÓN DE IMPRESORA DE COORDINACIÓN JUDICIAL Y INSTALACIÓN DE ACCESOS DIRECTOS A LA CARPETA COMPARTIDA DE COORDINACIÓN.', NULL, NULL, 'media', 'Cerrado Exitosamente', '46', '0', '2026-04-15 15:30:00', '2026-04-17 16:34:54', 'IMPRESORA INSTALADA');
INSERT INTO `Tickets` VALUES ('212', 'CSI2026041653541', '41', '162', 'pool de asistentes', '7', '45', 'problema de disco', 'disco no se recose por fleje', NULL, NULL, 'media', 'Cerrado Exitosamente', '41', '0', '2026-04-16 16:03:00', '2026-04-16 16:11:34', 'atendido');
INSERT INTO `Tickets` VALUES ('213', 'CSI2026041625465', '36', '176', 'pool asistente', '7', '36', 'Instalacion impresora', 'INstalacion impresora epson l3210', NULL, NULL, 'media', 'Cerrado Exitosamente', '36', '0', '2026-04-13 11:30:00', '2026-04-16 16:05:19', 'instalación por red de impresora');
INSERT INTO `Tickets` VALUES ('214', 'CSI2026041674140', '36', '194', 'Secretaria', '5', '24', 'perdida de conexion', 'el equipo no tenia conexion con la red', NULL, NULL, 'media', 'Cerrado Exitosamente', '36', '0', '2026-04-14 09:00:00', '2026-04-16 16:15:32', 'colocacion de un rj45 al cable de red');
INSERT INTO `Tickets` VALUES ('215', 'CSI2026041694779', '41', '165', 'pool de asistentes', '5', '24', 'sin servicio de red', 'cable desconectado en el equipo', NULL, NULL, 'media', 'Cerrado Exitosamente', '41', '0', '2026-04-16 16:18:00', '2026-04-16 16:21:06', 'atendido');
INSERT INTO `Tickets` VALUES ('216', 'CSI2026041695367', '46', '188', 'OFICINA DE LA TRABAJADORA SOCIAL', '7', '39', 'CAMBIO DE CONTRASEÑA', 'SE REALIZO EL CAMBIO DE CONTRASEÑA A LA LIC. YUNIS ARAGON, TRABAJADORA SOCIAL.', NULL, NULL, 'alta', 'Cerrado Exitosamente', '46', '0', '2026-04-14 09:10:00', '2026-04-17 16:37:21', 'USUARIO DESBLOQUEADO');
INSERT INTO `Tickets` VALUES ('217', 'CSI2026041770822', '95', '203', 'Archivo', '6', '30', 'Falla de sistema operativo', 'Se reparo dicho sistema utilizando la herramienta hirens bootcd', NULL, NULL, 'media', 'Cerrado Exitosamente', '95', '0', '2026-04-17 09:23:41', '2026-04-17 09:34:21', 'exitoso');
INSERT INTO `Tickets` VALUES ('218', 'CSI2026041729228', '95', '203', 'configuracion de impresora', '6', '30', 'Configuracion de impresora', 'Se realizo la configuración a cuatro PC', NULL, NULL, 'media', 'Cerrado Exitosamente', '95', '0', '2026-04-17 09:25:57', '2026-04-17 09:34:05', 'exitoso');
INSERT INTO `Tickets` VALUES ('219', 'CSI2026041723438', '94', '177', 'Pool de Superior y Despacho del Tribunal Primero Superior del Trabajo de la Circunscripción Judicial del estado Bolivariano de Mérida', '7', '35', 'No hay acceso a la carpeta de técnico audiovisual', 'Buenos días. Sucede que dos abogados relatores no pueden acceder a la RED DE AUDIENCIAS, que es la carpeta de técnico audiovisual. Agradecemos de antemano el apoyo.', NULL, NULL, 'media', 'Cerrado Exitosamente', '37', '0', '2026-04-17 10:07:40', '2026-04-17 11:14:46', 'cerrado exitoso.');
INSERT INTO `Tickets` VALUES ('220', 'CSI2026041720166', '45', '201', 'asistentes', '7', '39', 'fallas en magistratura', 'el usuario no podia acceder a su cuenta magistratura', NULL, NULL, 'alta', 'Cerrado Exitosamente', '45', '0', '2026-04-16 10:00:00', '2026-04-17 10:12:17', 'se ingreso el equipo a magistratura');
INSERT INTO `Tickets` VALUES ('221', 'CSI2026041733969', '45', '24', 'fasdem', '7', '38', 'fallas en el equipo', 'no funciona el perfil del usuario', NULL, NULL, 'alta', 'Cerrado Exitosamente', '45', '0', '2026-04-16 13:00:00', '2026-04-17 10:14:16', 'se restauro el perfil del usuario');
INSERT INTO `Tickets` VALUES ('222', 'CSI2026041748332', '38', '162', 'archivo', '7', '45', 'Acceso a carpeta compartida comun', 'Acceso a carpeta compartida comun', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-17 11:43:41', '2026-04-17 11:46:31', 'Se asigna permisologias');
INSERT INTO `Tickets` VALUES ('223', 'CSI2026041792988', '38', '162', 'Juicio 4', '7', '36', 'Instalacion de impresora', 'Instalacion de impresora en despacho de juicio 4', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-17 11:44:26', '2026-04-17 11:44:52', 'Se asigna permisologias');
INSERT INTO `Tickets` VALUES ('224', 'CSI2026041778814', '38', '162', 'Pool de asistentes', '7', '35', 'Sin acceso a carpeta OTP', 'No se visualiza carpeta OTP en equipo de computación', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-17 14:05:08', '2026-04-17 14:08:17', 'Se coloca acceso directo en escritrio del la cuenta de usuario solicitante');
INSERT INTO `Tickets` VALUES ('225', 'CSI2026041799652', '38', '162', 'Ejecución violencia', '7', '35', 'Sin acceso a carpeta documentos de usuario flormara', 'Sin acceso a carpeta documentos de usuario flormara', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-17 14:06:47', '2026-04-17 14:07:42', 'Se crea manualmente la carpeta en servidor de perfiles y se migra informacion de palacio a cjp merida en su servidor correspondiente');
INSERT INTO `Tickets` VALUES ('226', 'CSI2026041781014', '95', '24', 'Infraestructura', '7', '44', 'recuperacion de informacion', 'Recuperar informacion', NULL, NULL, 'media', 'Cerrado Exitosamente', '95', '0', '2026-04-17 14:42:44', '2026-04-17 14:43:03', 'exitoso');
INSERT INTO `Tickets` VALUES ('227', 'CSI2026041775722', '95', '24', 'Secretario', '7', '36', 'Error de impresion', 'Error de impresión', NULL, NULL, 'media', 'Cerrado Exitosamente', '95', '0', '2026-04-17 15:10:28', '2026-04-20 15:12:37', 'No exitoso');
INSERT INTO `Tickets` VALUES ('228', 'CSI2026041720252', '55', '24', 'edificio Hermes', '1', '4', 'Recepción de Alimentos correspondientes Abril', 'INSTALACION DE EQUIPOS DE SONIDO PARA REPRODUCIR MUSICA Y GENERAR UN AMBIENTE LABORAL MAS AMENO. ASI MISMO SE REQUIERE DEL APOYO EN FUERZA DE TRABAJO PARA LA DESCARGA DE LAS RESPECTIVAS BOLSAS.', NULL, NULL, 'media', 'Cerrado Exitosamente', '37', '1', '2026-04-17 15:48:36', '2026-04-20 14:05:47', 'cerrado exitoso');
INSERT INTO `Tickets` VALUES ('229', 'CSI2026042071030', '56', '167', 'Oficina ORAPC, primer piso', '1', '4', 'Suspensión de actividad programada para hoy', 'Por la llegada de la gandola de alimentos, se suspende la actividad pautada para el día de hoy, quedando pendiente la fecha de la reprogramación. Gracias.', NULL, NULL, 'media', 'Cerrado Exitosamente', '95', '0', '2026-04-20 08:40:05', '2026-04-20 11:34:40', 'Reprogramado por  llegada d e  gandola');
INSERT INTO `Tickets` VALUES ('230', 'CSI2026042021532', '45', '205', 'pool de asistentes', '7', '38', 'fallas para ingresar a magistratura', 'no logra entrar a su cuenta magistratura', NULL, NULL, 'alta', 'Cerrado Exitosamente', '45', '0', '2026-04-20 09:59:03', '2026-04-20 09:59:52', 'restablecimiento contraseña y se ingreso el equipo a magistratura');
INSERT INTO `Tickets` VALUES ('231', 'CSI2026042027387', '91', '205', 'Oficina Equipo Multidisciplinario', '4', '19', 'Linea telefónica sin tono.', 'Buenos días, favor realizar la revisión de la línea telefónica ubicada en la oficina del Equipo Multidisciplinario, por cuanto la misma se encuentra sin tono.', NULL, NULL, 'media', 'Cerrado Exitosamente', '37', '0', '2026-04-20 10:51:51', '2026-04-20 11:59:43', 'operativo reinicio de central telefónica');
INSERT INTO `Tickets` VALUES ('232', 'CSI2026042021601', '7', '24', 'Planta Baja', '1', '3', 'Atencion de  Sonido', 'Atención de  sonido  durante la  entrega de  bolsas de alimentos  para  los  Funcionarios del TSJ', NULL, NULL, 'media', 'Cerrado Exitosamente', '95', '1', '2026-04-20 11:36:57', '2026-04-20 15:11:56', 'Exitoso');
INSERT INTO `Tickets` VALUES ('233', 'CSI2026042049371', '38', '162', 'Despacho Juicio 4', '7', '37', 'Cambio de disco solido', 'Cambio de disco solido', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-20 11:41:41', '2026-04-20 11:47:10', 'Se reemplaza disco solido de 960gb patriot serial 00647, por disco solido de 240gb msi serial 008200, se instala sistema operativo con sus aplicaciones basicas y conexion a magistratura, se pasa la informacion del juez al nuevo disco en escritorio de su cuenta de usuario. el disco de 960gb queda en resguardo en la oficina oati del cjp, no se borra informacion del mismo, quedando con toda la informacion dentro del mismo "sistema y cuentas de usuario con su data"');
INSERT INTO `Tickets` VALUES ('234', 'CSI2026042059478', '37', '173', 'secretarios', '7', '36', 'no imprime un equipo', 'falla al imprimir un documento', NULL, NULL, 'media', 'Cerrado Exitosamente', '37', '0', '2026-04-20 11:58:23', '2026-04-20 14:06:57', 'se dio el servicio cerrado con éxito');
INSERT INTO `Tickets` VALUES ('235', 'CSI2026042044520', '53', '24', 'CORTE DE APELACIONES', '7', '36', 'SCANER', 'INSTALACION DE SCANNER', NULL, NULL, 'media', 'Cerrado Exitosamente', '53', '0', '2026-04-20 12:00:00', '2026-04-21 11:03:39', 'SE INSTALA HERRAMIENTA ÁBBYY SCANER, SE ACTUALIZA DRIVERS HP 52000');
INSERT INTO `Tickets` VALUES ('236', 'CSI2026042058602', '50', '24', 'primer piso al lado de agrario', '7', '41', 'pc se apaga', 'el pc se queda sin imagen, pantalla negra', NULL, NULL, 'media', 'En Proceso', '50', '0', '2026-04-20 01:49:00', NULL, NULL);
INSERT INTO `Tickets` VALUES ('237', 'CSI2026042069599', '91', '205', 'ARCHIVO DEL CIRCUITO', '6', '31', 'NO ENCIENDE EL EQUIPO PC', 'Buenas tardes, por favor realizar la revisión de PC, ubicado en el Archivo de este Circuito Judicial de Protección, por cuanto el mismo presente problemas y no enciende.', '03-28-10026', NULL, 'baja', 'En Proceso', '35', '0', '2026-04-20 15:00:34', NULL, NULL);
INSERT INTO `Tickets` VALUES ('238', 'CSI2026042097592', '91', '205', 'Despacho Dra Maria Isabel (Juicio)', '7', '44', 'Equipo bloqueado', 'Buenas tardes, favor realizar la revisión de PC ubicado en el despacho de la Jueza María Isabel Rojas, por cuanto el mismo, se encuentra bloqueado el usuario, y también presenta problemas de configuración de la hora del PC.', NULL, NULL, 'media', 'Cerrado Exitosamente', '37', '0', '2026-04-20 15:03:09', '2026-04-20 15:18:02', 'cambio de hora del sistema, y registro magistratura');
INSERT INTO `Tickets` VALUES ('239', 'CSI2026042144838', '38', '177', 'Servidor', '7', '45', 'Revision de servidor juris recibido', 'Revision de servidor juris recibido despues de llegar de la odi donde fue programado el juris', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-20 13:00:00', '2026-04-21 09:09:08', 'Revision realizada encontrando en buenas condiciones el servidor');
INSERT INTO `Tickets` VALUES ('240', 'CSI2026042197250', '38', '175', 'Servidor', '7', '45', 'Revision de servidor juris recibido', 'Revision de servidor juris recibido despues de llegar de la odi donde fue programado el juris', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-20 15:00:00', '2026-04-21 09:07:56', 'Revision realizada encontrando en buenas condiciones el servidor');
INSERT INTO `Tickets` VALUES ('241', 'CSI2026042140573', '45', '201', 'pool de asistentes', '7', '39', 'fallas para ingresar a magistratura', 'no pueden ingresar con su usuario al equipo', NULL, NULL, 'alta', 'Cerrado Exitosamente', '45', '0', '2026-04-21 09:10:48', '2026-04-21 09:11:59', 'se ingreso el equipo a magistratura');
INSERT INTO `Tickets` VALUES ('242', 'CSI2026042119551', '35', '163', 'Pool asistentes', '7', '37', 'CPU No enciende', 'CPU no enciende', NULL, NULL, 'media', 'Asignado', '40', '0', '2026-04-21 09:56:30', NULL, NULL);
INSERT INTO `Tickets` VALUES ('243', 'CSI2026042197741', '35', '201', 'Despacho', '7', '37', 'Instalacion de equipo de computacion nuevo', 'Instalacion de equipo de computacion nuevo', NULL, NULL, 'media', 'En Proceso', '37', '0', '2026-04-21 09:59:07', NULL, NULL);
INSERT INTO `Tickets` VALUES ('244', 'CSI2026042193893', '35', '205', 'Archivo', '7', '37', 'Equipo no enciende', 'Equipo no enciende', '03-28-10046', NULL, 'media', 'En Proceso', '52', '0', '2026-04-21 10:00:46', NULL, 'Se le  cambio unos  condensadores');
INSERT INTO `Tickets` VALUES ('245', 'CSI2026042198273', '45', '24', 'nomina', '7', '34', 'acceso a sigeffir', 'habilitar acceso a sigeffir', '03-28-10046', NULL, 'baja', 'En Proceso', '95', '0', '2026-04-21 10:13:52', NULL, 'Prueba de Cedula');
INSERT INTO `Tickets` VALUES ('246', 'CSI2026042160287', '38', '162', 'Control 2 Telematica', '1', '1', 'Instalacion y conexion telematico', 'Instalacion y conexion telematico sala 6', NULL, NULL, 'media', 'Cerrado Exitosamente', '38', '0', '2026-04-21 11:07:49', '2026-04-21 11:13:15', 'Instalacion exitosa mas no conexion con destinatario, se realiza via telefonica');

-- --------------------------------------------------
-- Estructura de la tabla: Usuarios
-- --------------------------------------------------
DROP TABLE IF EXISTS `Usuarios`;
CREATE TABLE `Usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `contrasena` varchar(255) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `dependencia_id` int(11) DEFAULT NULL,
  `privilegio` varchar(20) DEFAULT 'usuario',
  `activo` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`),
  KEY `idx_usuarios_dependencia` (`dependencia_id`),
  KEY `idx_privilegio` (`privilegio`),
  CONSTRAINT `Usuarios_ibfk_1` FOREIGN KEY (`dependencia_id`) REFERENCES `Dependencias` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Datos de la tabla: Usuarios
INSERT INTO `Usuarios` VALUES ('7', 'pablo', '$2y$10$nZu2ybHuVdoK5rF/H4iLW.DfxQ27Q1P1TkeTZN0lyolRpycGuuDHu', 'Pablo Zambrano', 'pablojz70@gmail.com', '24', 'admin', '1');
INSERT INTO `Usuarios` VALUES ('34', 'medimilm', '$2y$10$oTteeY/c488mke/fPe84j.XM.s2QvlTZ2ppNoyH/Cx2ox52dgvkL.', 'Milana Maria Medina Ramirez', 'milanamedina@gmail.com', '24', 'admin', '1');
INSERT INTO `Usuarios` VALUES ('35', 'choucesh1', '$2y$10$mt57zG17z5Cj/qLrUPoS1ePrOnQyNswkFyO5z/oDDzPew3iAulHC2', 'Cesar Herney Chourio Ruiz', 'csar.17.6@gmail.com', '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('36', 'dtoro', '$2y$10$MW/KGxxydThHbk7.WaIcXeHy8i0EpcbK7eKfj89Z5PlveGCeGcp7a', 'Dionny Toro', 'dtoro@gmail.com', '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('37', 'torredgj1', '$2y$10$.jdHm9HtUbx83PjmbhVhN.Xmvy5ousU7k4YsNF4KSRZQpQ5Jkoxjy', 'Edgar Jesus Torrealba Uzcategui', 'torredgj1.oati@gmail.com', '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('38', 'torreladio', '$2y$10$trKu1f6YYTvTknWrJQ40QecZLFM7NlubdXBCvDcKD3whnDNCfwyCa', 'Eladio Antonio Torres Peña', 'eladiotorres00@gmail.com', '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('39', 'guevernc', '$2y$10$lfAeDBJnL2QbKDtOcA2OTuvw7YSImBv7Nlb2BVxgyVvWYq7svkqne', 'Ernesto Cherminy Guevara Vielma', 'ernesto@gmail.com', '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('40', 'gamegerar', '$2y$10$CzLJqHDMf8s6YM5Y.u/knu95QilF3stf.8Xxqhe9qOjb7oeI/Xzcu', 'GERARDO GAMEZ MONRIAL', NULL, '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('41', 'iscahece1', '$2y$10$3y5vvSOTQb.lYcDgnvnEFuIBudWMg02q6kl4DkV3qWguJW9IdsAdC', 'Hector Eduardo Iscala Ramirez', 'iscahece1@gmail.com', '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('42', 'rodrivax', '$2y$10$isuMuVugK4wLb2/NmH82NuBp7ognKNbot0oO1B7ljupnyHd71Lb1.', 'Ivan Rodriguez Plaza', 'ivan@gmail.com', '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('43', 'gutijeac', '$2y$10$CzLJqHDMf8s6YM5Y.u/knu95QilF3stf.8Xxqhe9qOjb7oeI/Xzcu', 'Jean Carlos Gutierrez Guzman', NULL, '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('44', 'torojeap', '$2y$10$mDRlSDsSjg0.yQuM3iIwFeYH8nRuL3YfxPjNBru8NcqaxkZkflgYS', 'Jean Paul Toro Rojo', 'oatijptr@gmail.com', '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('45', 'vergkary', '$2y$10$ukEjaS7DLzwlOoUNch7Mqu.XjL0vdII5y2cq3tyR06jvQQqNEgQXm', 'Karen Yelena Vergara Toro', 'KARENYELE@GMAIL.COM', '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('46', 'lagumarx', '$2y$10$2gS44Ts7otB43lN6Yhmiy.xAxEAhatQ2xxj5TMWUUKS0x.okkDt3m', 'Martha Laguado de Albarran', 'iscahece1@gmail.com', '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('47', 'diazmaui', '$2y$10$0zzBwLKdn31/fPv.3Lo9ROg2cLkzYLP7.bYJCCxTq2cj5oxuKFSxW', 'Mauro Imar Diaz Dugarte', 'maurodiaz1985@gmail.com', '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('48', 'penamilj', '$2y$10$YMbdMc64pJw8oz2.PL/P3OZYeyaxh3meWurXUSlZ6O7/4XkXFP5kC', 'MILJAIR JOSUE PEÑA ALAÑA', 'mijair@gmail.com', '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('49', 'rojanorx', '$2y$10$CzLJqHDMf8s6YM5Y.u/knu95QilF3stf.8Xxqhe9qOjb7oeI/Xzcu', 'Norbedy Rojas Lacruz', NULL, '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('50', 'davioran', '$2y$10$..X2MNFFQNh0mA7o4V3tqerKu/FXaBuLsY40787mochHcnu3a0TnC', 'Orangel Davila', 'oradavila@gmail.com', '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('51', 'molirafa1', '$2y$10$FG93BwNaXpoSQab54eQ1Pu9mcakE0cRWquVIpqsFEaV8SWn5.uZEq', 'Rafael Augusto Molina Ruiz', 'molinaraf134@gmail.com', '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('52', 'davisaue1', '$2y$10$JNuMT1bEjb7iyC/o/ayK/.t1i7oSAwKD/aEk1nLqCmQJgq7cEN.Rq', 'Saul Enrique Davila  Piña', 'davisaue1.oati@gmail.com', '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('53', 'valetome', '$2y$10$ysIHuskWXOwfF/xX.Y73oeSKnmGvlWksXIeWmLnPNTCB6J7yCZumS', 'Tomas Elias Valera Torrealba', 'valetome.oati@gmail.com', '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('54', 'cedevicm', '$2y$10$Ti01cRkBSS7KB2ReRD7IsOYm2hX.mxPRtuA1kyMI06NjtmYdwUZnq', 'Victor manuel Cedeño Vega', 'usuario@gmail.com', '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('55', 'rincfrea', '$2y$10$xNayCKD7SGAyBaLWrdcFzelT2lSZJ3eZeJaShF6TOLMV7AbqgS7IG', 'Freddy Alejandro Rincon Rivas', 'rincfrea@correo.local', '24', 'director', '1');
INSERT INTO `Usuarios` VALUES ('56', 'suardarc1', '$2y$10$qviaUS.vTtRMupmgP5l4Ru.hKEh3kuRdJUrBgIBR2CNtaJBKvAKFi', 'Darsy Coromoto Suarez de Hull', 'orapc.merida@gmail.com', '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('57', 'montmarm', '$2y$10$5Mu7Etv3d4YnKEQCO5bdJOBADDAlQAHEK7r.V.J4Sqa.8UxJMjUTG', 'Maria Mercedes Montilla Labrador', 'montmarm@correo.com', '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('58', 'verglilx', '$2y$10$HbQr7xMWQzNdHAaLEZGsyeMCiY1oTSGosUSkCXbrvT.eMj0GB3bAm', 'Lilibeth Vergara Vergara', 'fasdennerida095@gmail.com', '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('59', 'albosabc', '$2y$10$CzLJqHDMf8s6YM5Y.u/knu95QilF3stf.8Xxqhe9qOjb7oeI/Xzcu', 'Sabrina Coromoto Albornoz Quintero', NULL, '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('60', 'riermara', '$2y$10$SgluyPaJhmBcViPCh3RIseNP3aqLJeOPzVVGa5KNcAmivuCfDmg36', 'Marbel Andreina Riera Castillo', 'bienestarsocialmerida@gmail.com', '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('61', 'santjulc1', '$2y$10$CzLJqHDMf8s6YM5Y.u/knu95QilF3stf.8Xxqhe9qOjb7oeI/Xzcu', 'Juliet Coromoto Santiago Santiago', NULL, '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('62', 'ferndanm', '$2y$10$CzLJqHDMf8s6YM5Y.u/knu95QilF3stf.8Xxqhe9qOjb7oeI/Xzcu', 'Danny Marcelo Fernandez', NULL, '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('63', 'liscdory', '$2y$10$CzLJqHDMf8s6YM5Y.u/knu95QilF3stf.8Xxqhe9qOjb7oeI/Xzcu', 'Doris Y. Liscano Carrillo', NULL, '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('64', 'molidouj', '$2y$10$CzLJqHDMf8s6YM5Y.u/knu95QilF3stf.8Xxqhe9qOjb7oeI/Xzcu', 'Douglas Javier Molina', NULL, '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('65', 'vasqaure', '$2y$10$541hgc7ETRr32y2j9LnlUOSKeP5aRZW6jrQNqj7Y1RUzpQZHJa7X6', 'Aura Elena Vasquez Ceballos', 'vasqaure@correo.com', '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('66', 'velaasdx', '$2y$10$JwaWVWMBo1.95DasOEIcseEzB9nMA.AxAQnhfnUzQY3/YozsOIShG', 'Asdrubal Jose Velasquez Patiño', 'velaasdx@correo.com', '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('67', 'Leonherc', '$2y$10$jII658K7C8SwCcQKMXhXwuR6hzMA7r69ljpuBE7SLGlZXTF//UfkO', 'Hermelinda C. Leon Avendaño', 'carmen6512@gmail.com', '24', 'bienes', '1');
INSERT INTO `Usuarios` VALUES ('68', 'chackary', '$2y$10$CzLJqHDMf8s6YM5Y.u/knu95QilF3stf.8Xxqhe9qOjb7oeI/Xzcu', 'Karly Yulianny Chacon Pajaro', NULL, '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('69', 'lduran', '$2y$10$ehiuC2SzuAaRya1UAs53GeEQAyu1R5z6CkGgV9QgnMCQScwZzuVMC', 'Liliana Duran', 'lduran@correo.com', '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('70', 'barrluif', '$2y$10$AduCKb0vZ9EaHdcJ.2MmpOdMZVY8CNjm7icgG2xKwqvT86YBOK4aS', 'Luis Fernando Barrios Romero', 'serviciomedicomerida@gmail.com', '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('71', 'castmaro', '$2y$10$CzLJqHDMf8s6YM5Y.u/knu95QilF3stf.8Xxqhe9qOjb7oeI/Xzcu', 'Maria Ofelia Castillo Ramirez', NULL, '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('72', 'fonsmaya', '$2y$10$CzLJqHDMf8s6YM5Y.u/knu95QilF3stf.8Xxqhe9qOjb7oeI/Xzcu', 'Mayra Alejandra Fonseca Carmona', NULL, '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('73', 'penarafa', '$2y$10$CzLJqHDMf8s6YM5Y.u/knu95QilF3stf.8Xxqhe9qOjb7oeI/Xzcu', 'Rafael Antonio Peña Rodriguez', NULL, '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('74', 'scarrero', '$2y$10$ML31KCR7qMk.YyyhzKJoy.052lzBYM4WXr0YW.jTN.vxRgsHudew2', 'Sandra Carrero', 'scarrero@correo.com', '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('75', 'gonzwuij', '$2y$10$yySHKzUPKYuwFS8i1R.VkOFCuTn4SEPyWawbni99l8IjHY69bolEO', 'Wuilson Jose Gonzalez Fernandez', 'gonzwuij@correo.com', '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('76', 'larapaug', '$2y$10$3E7p.Cdyd4ybH2i6P32Sk.YzohYKGn2XEYEkx.A9BywYbehZhOduW', 'Paula Geraldines Lara Segovia', 'larapaug@gmail.com', '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('77', 'anguyerd', '$2y$10$BlhnDJQpBlK7SU/0TCUGjemHxchIgUlFZk6fhdp.fFDrB6RAQWEKu', 'Yerika Del Carmen Angulo Saavedra', 'anguyerd@gmail.com', '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('78', 'jereyurv', '$2y$10$CzLJqHDMf8s6YM5Y.u/knu95QilF3stf.8Xxqhe9qOjb7oeI/Xzcu', 'Yuraima Vianney Jerez de Torres', NULL, '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('80', 'aponmele', '$2y$10$/5yG8MmpOKeBo8cNXFg99.R/XtedZLzbjmm9EUIe6Q./QLHhYzzqi', 'APONTE  PUENTES, MELWIN ENRIQUE', 'aponmele@gmail.com', '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('81', 'maroa', '$2y$10$.FAfR/QmoGl1UhmbEeYONOSETFm9a3rG5VHgoSaG51PLi9A1wqDeG', 'Mayela Roa', 'mroa@correo.local', '24', 'bienes', '1');
INSERT INTO `Usuarios` VALUES ('82', 'javila', '$2y$10$Gz8jgik6nLoK6WAiuHFAW.2Aaf4VEP8kUSzHWdS19pgg5mnblLdqy', 'Jorge Avila', 'javila@correo.local', '24', 'bienes', '1');
INSERT INTO `Usuarios` VALUES ('83', 'quinstrm', '$2y$10$/bi86wBtffrxGZwmtOTob.LGVGz41Kn2DZayPX/6Wb59rc5RXNA4u', 'Marisela Quintero', 'quinstrm@correo.com', '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('84', 'usuario', '$2y$10$Lfz/hYySD2UNlll9RnrN1.vbq2Oa8GMvFlJAly19GW.WdH.xypVXC', 'Usuario Prueba', 'usuario@correo.local', '162', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('85', 'tecnico', '$2y$10$vyDCAjAFamgE3fXzbgP.xOml/o4T7znaDucmFFO7x/0p4eqbMGJ1O', 'Tecnico Prueba', 'tecnico@correo.local', '166', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('86', 'munoramy', '$2y$10$1IF3pVIphIU9MHAXQtI8w.iz37oA7jEwQCt1ECAwXcefNCB5dsf6q', 'Ramon Muñoz', 'munozramon55@gmail.com', '24', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('87', 'gilyubc', '$2y$10$qNtnb2MYmRJxAtwpyHtXP.Pa1tTcgAN3FWOzoRS3gR0Zc1tWFRc/i', 'Gil Calderon Yubaira', 'yubairagil@gmail.com', '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('88', 'moremarj', '$2y$10$irmMopfjb9Df1yEvQ7UFJOfhwfMcXJHO0CKHJMV58edOLQUfOeKOy', 'Marco Jose Moreno', 'marcojosemoreno@yahoo.es', '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('89', 'moramard', '$2y$10$A59cxA9jAvpnsIfCC3QrsuFkcAidFjY8wzYtECdcOqUfFZNhZQ6Z2', 'Marifrankcis Morales', 'fasdennerida095@gmail.com', '24', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('91', 'gavileyx', '$2y$10$4Wj3DVgsS0RUrKHWujVEbe5R6Ix/XzFxmXoybYXybpjqQae1G5hQy', 'GAVIDIA RIVAS, NEIDA', 'gavileyx@correo.local', '205', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('92', 'contmarx1', '$2y$10$3BvBEpAXLEk5Txc5D.U5Quo4oG09bTc.HDSLiFGLatKFla7ltu9BG', 'CONTRERAS GUERRERO, MARLENI SULAY', 'contmarx1@correo.local', '205', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('93', 'rondirim', '$2y$10$vzXEUWmx6Abg1US3ZQBKIeHe2nB4W1nyfRAum5c8C.p4/HnK/3kWO', 'RONDÓN RANGEL, IRIS MIGDALY', 'rondirim@correo.local', '177', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('94', 'sangadap', '$2y$10$VYiCfOSaKjRO0Vx/C6Rn.ecisY8xMkDpDpjvn.5f8IjH.EOn1jDMe', 'SANGUINETTI ALARCON, ADA PIERINA DEL PILAR', 'sangadap@correo.local', '177', 'usuario', '1');
INSERT INTO `Usuarios` VALUES ('95', 'marqsusa', '$2y$10$81luBuPVp291QG6kFFHe8eYQehN.8OqYdiTea8Jf.58DOe5itxjH2', 'Marquez Vargas Susan', 'susan86marquez@gmail.com', '162', 'tecnico', '1');
INSERT INTO `Usuarios` VALUES ('96', 'bienes', '$2y$10$f7TAwaKN4li4uKASr54LS.gI6SFu32y6IGW2g/Wt3JwRMteBxibDW', 'Bienes', 'bienes@correo.com', '1', 'bienes', '1');

-- --------------------------------------------------
-- Estructura de la tabla: configuraciones
-- --------------------------------------------------
DROP TABLE IF EXISTS `configuraciones`;
CREATE TABLE `configuraciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria` varchar(50) NOT NULL,
  `clave` varchar(100) NOT NULL,
  `valor` text DEFAULT NULL,
  `tipo` varchar(20) DEFAULT 'text',
  `opciones` text DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `orden` int(11) DEFAULT 0,
  `editable` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave` (`clave`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Datos de la tabla: configuraciones
INSERT INTO `configuraciones` VALUES ('1', 'general', 'nombre_sistema', 'Sistema CSI - Soporte Técnico', 'text', NULL, 'Nombre del sistema que aparece en el título', '1', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('2', 'general', 'logo_url', 'logo.png', 'text', NULL, 'Ruta del archivo de logo', '2', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('3', 'general', 'color_principal', '#2c3e50', 'color', NULL, 'Color principal de la interfaz', '3', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('4', 'general', 'color_secundario', '#3498db', 'color', NULL, 'Color secundario para botones', '4', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('5', 'general', 'items_por_pagina', '20', 'number', NULL, 'Número de items por página en listados', '5', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('6', 'general', 'timezone', 'America/Mexico_City', 'select', NULL, 'Zona horaria del sistema', '6', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('7', 'general', 'idioma', 'es', 'select', NULL, 'Idioma del sistema', '7', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('8', 'email', 'notificaciones_activas', '1', 'boolean', NULL, 'Activar/Desactivar notificaciones por email', '1', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('9', 'email', 'smtp_host', 'smtp.gmail.com', 'text', NULL, 'Servidor SMTP', '2', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('10', 'email', 'smtp_port', '587', 'number', NULL, 'Puerto SMTP', '3', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('11', 'email', 'smtp_secure', 'tls', 'select', NULL, 'Tipo de seguridad', '4', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('12', 'email', 'smtp_usuario', '', 'text', NULL, 'Usuario SMTP', '5', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('13', 'email', 'smtp_password', '', 'password', NULL, 'Contraseña SMTP', '6', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('14', 'email', 'email_from', 'notificaciones@sistema-csi.com', 'text', NULL, 'Email remitente', '7', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('15', 'email', 'nombre_from', 'Sistema CSI', 'text', NULL, 'Nombre remitente', '8', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('16', 'email', 'email_reply_to', 'soporte@sistema-csi.com', 'text', NULL, 'Email para respuestas', '9', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('17', 'seguridad', 'max_intentos_login', '5', 'number', NULL, 'Máximo intentos de login antes de bloquear', '1', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('18', 'seguridad', 'tiempo_bloqueo_minutos', '30', 'number', NULL, 'Minutos de bloqueo por intentos fallidos', '2', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('19', 'seguridad', 'sesion_expiracion_horas', '8', 'number', NULL, 'Horas para expirar sesión inactiva', '3', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('20', 'seguridad', 'requerir_contrasena_fuerte', '1', 'boolean', NULL, 'Requerir contraseña fuerte (mínimo 8 caracteres, mayúscula, número)', '4', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('21', 'seguridad', 'bloquear_ip_intentos', '1', 'boolean', NULL, 'Bloquear IP por intentos fallidos', '5', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('22', 'archivos', 'max_tamano_mb', '10', 'number', NULL, 'Tamaño máximo de archivos adjuntos en MB', '1', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('23', 'archivos', 'extensiones_permitidas', 'jpg,jpeg,png,pdf,doc,docx,xls,xlsx', 'text', NULL, 'Extensiones permitidas separadas por coma', '2', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('24', 'archivos', 'ruta_uploads', 'uploads/', 'text', NULL, 'Ruta donde se guardan los archivos', '3', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('25', 'tickets', 'prioridad_defecto', 'media', 'select', NULL, 'Prioridad por defecto para nuevos tickets', '1', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('26', 'tickets', 'dias_cierre_automatico', '30', 'number', NULL, 'Días para cierre automático de tickets inactivos', '2', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('27', 'tickets', 'notificar_usuario_siempre', '1', 'boolean', NULL, 'Notificar siempre al usuario sobre cambios', '3', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('28', 'tickets', 'permitir_reabrir_tickets', '1', 'boolean', NULL, 'Permitir reabrir tickets cerrados', '4', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('29', 'tickets', 'tiempo_max_respuesta_horas', '24', 'number', NULL, 'Tiempo máximo para respuesta inicial en horas', '5', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('30', 'tickets', 'sla_prioridad_alta', '4', 'number', NULL, 'SLA para prioridad alta (horas)', '6', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('31', 'tickets', 'sla_prioridad_media', '8', 'number', NULL, 'SLA para prioridad media (horas)', '7', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');
INSERT INTO `configuraciones` VALUES ('32', 'tickets', 'sla_prioridad_baja', '24', 'number', NULL, 'SLA para prioridad baja (horas)', '8', '1', '2026-01-19 11:03:30', '2026-01-19 11:03:30');

SET FOREIGN_KEY_CHECKS = 1;
